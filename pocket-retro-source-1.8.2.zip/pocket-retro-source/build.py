#!/usr/bin/env python3
"""Build Pocket Retro.

    python3 build.py

Makes two things from the files in retro/:
  pocket-retro.html     the single-file Claude version (artifact)
  site/pocket-retro/    the website: upload everything inside it to your GitHub Pages repository
Needs Python 3 and Pillow (pip install pillow) for the app icons.
"""
import os, subprocess, sys
root=os.path.dirname(os.path.abspath(__file__)); os.chdir(root)
for step in ("retro/build.py","retro/build_site.py"):
    print("==>",step); subprocess.run([sys.executable,step],check=True)
v=[l for l in open("retro/build_site.py") if l.startswith("VERSION=")][0].strip()
print(f"\nDone ({v}).\n  Claude version: pocket-retro.html\n  Website:        site/pocket-retro/  (upload the files inside it)")
