/* Camera (low-res digicam) and CRT screen engines for Pocket Retro. */
(function(G){
"use strict";
function rng(seed){ let s=seed>>>0||1; return ()=>{ s^=s<<13; s^=s>>>17; s^=s<<5; return (s>>>0)/4294967296; }; }

/* Cheap-sensor developer: colour, flash, vignette, highlight clip, noise, fringing, in-camera sharpening. */
function camApply(px,W,H,P,frame){
  const s=new Uint8ClampedArray(px), d=px;
  const rand=rng(W*7919+H+(P.seed>>>0)*31+((frame|0)+1)*104729);
  const grain=P.noise, fl=P.flash?1:0, mono=P.mono;
  const cxp=W/2, cyp=H*0.46, maxd=Math.hypot(cxp,cyp), shift=Math.max(0,Math.round(P.fringe*Math.max(1,W/640)));
  const lk=P.leak||0, lx=W*0.92, ly=H*0.08, lr=W*0.7;
  for(let yy=0; yy<H; yy++){
    for(let xx=0; xx<W; xx++){
      const i=(yy*W+xx)*4;
      const ir=(yy*W+Math.max(0,xx-shift))*4, ib=(yy*W+Math.min(W-1,xx+shift))*4;
      let r=s[ir], g=s[i+1], b=s[ib+2];
      r=r*P.gain[0]+P.tint[0]; g=g*P.gain[1]+P.tint[1]; b=b*P.gain[2]+P.tint[2];
      r=(r-128)*P.con+128+P.lift; g=(g-128)*P.con+128+P.lift; b=(b-128)*P.con+128+P.lift;
      let l=0.299*r+0.587*g+0.114*b;
      if(mono){ r=g=b=l; } else { r=l+(r-l)*P.sat; g=l+(g-l)*P.sat; b=l+(b-l)*P.sat; }
      const dd=Math.hypot(xx-cxp,yy-cyp)/maxd;
      if(fl){ const f=Math.max(0,1-dd*1.25), k=1+0.85*f*f, dk=38*(dd*dd); r=r*k-dk+6*f; g=g*k-dk+6*f; b=b*k-dk+14*f; }
      const v=1-P.vig*dd*dd*(fl?1.6:1); r*=v; g*=v; b*=v;
      if(lk>0){ const q=Math.max(0,1-Math.hypot(xx-lx,yy-ly)/lr), e=lk*q*q; r+=e*150; g+=e*60; b-=e*20; }
      if(r>196) r=196+(r-196)*P.clip; if(g>196) g=196+(g-196)*P.clip; if(b>196) b=196+(b-196)*P.clip;
      l=0.299*r+0.587*g+0.114*b;
      const sh=1.5-Math.min(1,Math.max(0,l/255)), n=(rand()-0.5)*grain*sh, cn=mono?0:grain*0.45*sh;
      d[i]=r+n+(rand()-0.5)*cn; d[i+1]=g+n+(rand()-0.5)*cn*0.6; d[i+2]=b+n+(rand()-0.5)*cn*1.2; d[i+3]=255;
    }
  }
  const amt=P.sharpen;
  if(amt>0){ const base=new Uint8ClampedArray(d);
    for(let yy=1; yy<H-1; yy++) for(let xx=1; xx<W-1; xx++){ const i=(yy*W+xx)*4;
      for(let k=0;k<3;k++){ const bl=(base[i-4+k]+base[i+4+k]+base[i-W*4+k]+base[i+W*4+k]+base[i+k]*4)/8; d[i+k]=base[i+k]+amt*(base[i+k]-bl); } } }
  return px;
}

/* CRT television: barrel curve, scanlines, phosphor pattern, glow, edge shadow. Output is 2x the input. */
function crtApply(px,W,H,K){
  const S=2, W2=W*S, H2=H*S, out=new Uint8ClampedArray(W2*H2*4);
  // glow buffer: 4x downsample + two box blurs
  const f=4, bw=Math.max(1,Math.ceil(W/f)), bh=Math.max(1,Math.ceil(H/f)), bl=new Float32Array(bw*bh*3), cnt=new Float32Array(bw*bh);
  for(let y=0;y<H;y++){ const by=(y/f)|0; for(let x=0;x<W;x++){ const bx=(x/f)|0, j=by*bw+bx, i=(y*W+x)*4; bl[j*3]+=px[i]; bl[j*3+1]+=px[i+1]; bl[j*3+2]+=px[i+2]; cnt[j]++; } }
  for(let j=0;j<bw*bh;j++){ const c=cnt[j]||1; bl[j*3]/=c; bl[j*3+1]/=c; bl[j*3+2]/=c; }
  const tmp=new Float32Array(bl.length);
  for(let pass=0;pass<2;pass++){
    for(let y=0;y<bh;y++) for(let x=0;x<bw;x++){ let r=0,g=0,b=0,n=0; for(let k=-2;k<=2;k++){ const xx=Math.min(bw-1,Math.max(0,x+k)), j=(y*bw+xx)*3; r+=bl[j]; g+=bl[j+1]; b+=bl[j+2]; n++; } const o=(y*bw+x)*3; tmp[o]=r/n; tmp[o+1]=g/n; tmp[o+2]=b/n; }
    for(let y=0;y<bh;y++) for(let x=0;x<bw;x++){ let r=0,g=0,b=0,n=0; for(let k=-2;k<=2;k++){ const yy=Math.min(bh-1,Math.max(0,y+k)), j=(yy*bw+x)*3; r+=tmp[j]; g+=tmp[j+1]; b+=tmp[j+2]; n++; } const o=(y*bw+x)*3; bl[o]=r/n; bl[o+1]=g/n; bl[o+2]=b/n; }
  }
  const k=K.curve*0.16, sc=K.scan, mk=K.mask==="none"?0:K.maskAmt, glow=K.glow, vig=K.vig, grille=K.mask!=="shadow";
  const comp=1+sc*0.45+mk*0.5;
  const samp=(sx,sy,o)=>{ // bilinear sample of the source into o[0..2]
    const x0=Math.max(0,Math.min(W-1,Math.floor(sx))), y0=Math.max(0,Math.min(H-1,Math.floor(sy))), x1=Math.min(W-1,x0+1), y1=Math.min(H-1,y0+1);
    const fx=Math.max(0,Math.min(1,sx-x0)), fy=Math.max(0,Math.min(1,sy-y0));
    for(let c=0;c<3;c++){ const a=px[(y0*W+x0)*4+c], b=px[(y0*W+x1)*4+c], cc=px[(y1*W+x0)*4+c], d=px[(y1*W+x1)*4+c];
      o[c]=(a*(1-fx)+b*fx)*(1-fy)+(cc*(1-fx)+d*fx)*fy; } };
  const o3=[0,0,0];
  for(let oy=0;oy<H2;oy++){
    const v=(oy+0.5)/H2*2-1;
    for(let ox=0;ox<W2;ox++){
      const u=(ox+0.5)/W2*2-1, uu=u*(1+k*v*v), vv=v*(1+k*u*u), oi=(oy*W2+ox)*4;
      if(uu<=-1||uu>=1||vv<=-1||vv>=1){ out[oi]=out[oi+1]=out[oi+2]=6; out[oi+3]=255; continue; }
      const sx=(uu+1)/2*W-0.5, sy=(vv+1)/2*H-0.5;
      samp(sx,sy,o3);
      let r=o3[0], g=o3[1], b=o3[2];
      const lum=(0.299*r+0.587*g+0.114*b)/255;
      const sw=1-sc*0.5*(1-Math.cos(2*Math.PI*(sy+0.5)))*(1-0.45*lum);
      let mr=1,mg=1,mb=1;
      if(mk>0){ const ph=grille ? ox%3 : (ox+((oy>>1)&1)*2)%3; const lo=1-mk;
        if(ph===0){ mg=lo; mb=lo; } else if(ph===1){ mr=lo; mb=lo; } else { mr=lo; mg=lo; }
        if(!grille && (oy%2===1)){ mr*=0.85; mg*=0.85; mb*=0.85; } }
      const gx=Math.min(bw-1,Math.max(0,sx/f)), gy=Math.min(bh-1,Math.max(0,sy/f)), gi=((gy|0)*bw+(gx|0))*3;
      const xs=(uu+1)/2, ys=(vv+1)/2, vg=Math.pow(Math.max(0,16*xs*(1-xs)*ys*(1-ys)),0.3), vf=1-vig+vig*vg;
      r=(r*sw*mr*comp+bl[gi]*glow*0.55)*vf; g=(g*sw*mg*comp+bl[gi+1]*glow*0.55)*vf; b=(b*sw*mb*comp+bl[gi+2]*glow*0.55)*vf;
      out[oi]=r; out[oi+1]=g; out[oi+2]=b; out[oi+3]=255;
    }
  }
  return {buf:out.buffer,W:W2,H:H2};
}
G.CAM={apply:camApply}; G.CRT={apply:crtApply};
})(self);
