# ---- 1.8.0 vertical 9:16 controls ----
SETTINGS=rep(SETTINGS,'border:"none", borderColor:"#000000", borderSize:0.06,','border:"none", borderColor:"#000000", borderSize:0.06, vBg:"blur", vZoom:1, vY:0,')
SETTINGS=rep(SETTINGS,'  {k:"color",id:"bcolor",label:"Border colour",get:()=>P.borderColor,set:v=>P.borderColor=v,pic:1,show:()=>P.border!=="none"},',
"""  {k:"seg",id:"vbg",label:"Background",opts:[["blur","Blurred picture"],["black","Black"],["colour","Colour"]],get:()=>P.vBg,set:v=>{P.vBg=v; buildPanel();},pic:1,show:()=>P.border==="vertical",desc:"What fills the space above and below the picture."},
  {k:"rng",id:"vzoom",label:"Zoom",min:1,max:2.3,step:0.01,fmt:v=>Math.round(v*100)+"%",get:()=>P.vZoom,set:v=>P.vZoom=v,pic:1,show:()=>P.border==="vertical",desc:"Makes the picture bigger in the tall frame. The sides are trimmed."},
  {k:"rng",id:"vy",label:"Move up or down",min:-0.35,max:0.35,step:0.005,fmt:v=>v===0?"0":(v>0?"↑ ":"↓ ")+Math.round(Math.abs(v)*100)+"%",get:()=>P.vY,set:v=>P.vY=v,pic:1,show:()=>P.border==="vertical"},
  {k:"color",id:"bcolor",label:"Border colour",get:()=>P.borderColor,set:v=>P.borderColor=v,pic:1,show:()=>P.border!=="none"&&!(P.border==="vertical"&&P.vBg!=="colour")},""")
