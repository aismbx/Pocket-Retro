# ---- 1.7.0 Tape mode frames ----
SETTINGS=rep(SETTINGS,'logoWhite:false, logoTime:"all",','logoWhite:false, logoTime:"all",\n  frameOn:false, fId:"", fFit:"stretch", fScale:1, fX:0, fY:0, fOpacity:1, fBlend:"normal", fSoft:false,')
import re as _re
_m=_re.search(r'  \{k:"seg",id:"ltime",[^\n]*\n',SETTINGS); assert _m
SETTINGS=SETTINGS[:_m.end()]+"""  {k:"head",label:"Frame"},
  {k:"sw",id:"tfOn",label:"Show a frame",get:()=>P.frameOn,set:v=>{P.frameOn=v; if(v&&!curFrame()&&FRAMES.length) P.fId=FRAMES[FRAMES.length-1].id; buildPanel();},pic:1,desc:"Put one of your own PNG frames around the picture. It's the same frame collection as Camera mode."},
  {k:"frames",id:"tflib",label:"Your frames",show:()=>P.frameOn,desc:"Upload a PNG with a see-through middle. Your frames stay in this browser and go into your backups."},
  {k:"seg",id:"tffit",label:"Fit",opts:[["stretch","Stretch to fill"],["fit","Fit inside"],["fill","Cover (crop)"]],get:()=>P.fFit,set:v=>P.fFit=v,pic:1,show:()=>P.frameOn&&!!curFrame()},
  {k:"rng",id:"tfscale",label:"Size",min:0.3,max:2,step:0.01,fmt:pct,get:()=>P.fScale,set:v=>P.fScale=v,pic:1,show:()=>P.frameOn&&!!curFrame()},
  {k:"rng",id:"tfx",label:"Move left or right",min:-0.5,max:0.5,step:0.005,fmt:v=>v===0?"0":(v<0?"← ":"→ ")+Math.round(Math.abs(v)*100)+"%",get:()=>P.fX,set:v=>P.fX=v,pic:1,show:()=>P.frameOn&&!!curFrame()},
  {k:"rng",id:"tfy",label:"Move up or down",min:-0.5,max:0.5,step:0.005,fmt:v=>v===0?"0":(v>0?"↑ ":"↓ ")+Math.round(Math.abs(v)*100)+"%",get:()=>P.fY,set:v=>P.fY=v,pic:1,show:()=>P.frameOn&&!!curFrame()},
  {k:"rng",id:"tfop",label:"Opacity",min:0.05,max:1,step:0.01,fmt:pct,get:()=>P.fOpacity,set:v=>P.fOpacity=v,pic:1,show:()=>P.frameOn&&!!curFrame()},
  {k:"seg",id:"tfblend",label:"Blend",opts:[["normal","Normal"],["screen","Screen"],["multiply","Multiply"]],get:()=>P.fBlend,set:v=>P.fBlend=v,pic:1,show:()=>P.frameOn&&!!curFrame(),desc:"Screen hides black areas, good for light leaks and glow frames. Multiply hides white areas, good for paper and sketch frames."},
  {k:"sw",id:"tfSoft",label:"Run through the effect",get:()=>P.fSoft,set:v=>P.fSoft=v,pic:1,show:()=>P.frameOn&&!!curFrame(),desc:"Off: crisp, laid on top after the tape look. On: soft and smeared, as if the frame was recorded onto the tape."},
"""+SETTINGS[_m.end():]
GEOM=rep(GEOM,'  if(P.osd!=="none") drawOsd(x,W,H,offsetMs||0);','  if(M==="tape" && P.frameOn && P.fSoft) drawTapeFrame(x,0,0,W,H);\n  if(P.osd!=="none") drawOsd(x,W,H,offsetMs||0);')
