import re,sys
src=open('pocket-ntsc.html').read().split('\n')
L=lambda a,b:'\n'.join(src[a-1:b])
def find(s): 
    for i,l in enumerate(src):
        if l.startswith(s): return i+1
    raise Exception(s)
i_settings=find('/* ---------- effect settings'); i_controls_end=None
i_panel=find('function buildPanel(){')
i_shelves=find('/* tabs + preset shelves */'); i_src=find('/* ---------- source (photo or video) + prep')
i_dims=find('function dims(source)'); i_engine=find('/* ---------- engine calls')
i_border=find('function borderGeom('); i_paint=find('function paint(m, keepBlob)')
i_vcfg=find('async function pickVideoConfig'); i_render=find('async function renderVideo(){')
i_aud=find('/* ---------- VHS sound engine'); i_save=find('/* ---------- save ---------- */')
i_sample=find('/* ---------- sample picture'); i_boot=find('/* ---------- boot')
SETTINGS=L(i_settings,i_panel-1); PANEL=L(i_panel,i_shelves-1); SHELVES=L(i_shelves,i_src-1)
GEOM=L(i_dims,i_engine-1); BORDER=L(i_border,i_paint-1); VCFG=L(i_vcfg,i_render-1)
AUD=L(i_aud,i_save-1); SAMPLE=L(i_sample+1,i_boot-1)
def rep(s,a,b,cnt=1):
    assert s.count(a)==cnt,(a[:80],s.count(a)); return s.replace(a,b)
# ---- settings
SETTINGS=rep(SETTINGS,'let S=presetSettings(PRESETS[0]), P=clone(PDEF), presetId="lp", tab="signal";','let S=presetSettings(PRESETS[0]), P=clone(PDEF), presetId="lp";')
SETTINGS=re.sub(r'try\{ const saved=JSON\.parse\(localStorage\.getItem\("pntsc"\).*?\n.*?\n.*?catch\(e\)\{\}\n','',SETTINGS,count=1,flags=re.S)
SETTINGS=re.sub(r'function remember\(\)\{ try\{ localStorage\.setItem\("pntsc".*?\n','',SETTINGS,count=1)
assert 'getItem("pntsc")' not in SETTINGS and 'setItem("pntsc",' not in SETTINGS, 'leftover'
SETTINGS=rep(SETTINGS,'rating:"none", ratingPos:"tl", ratingOpacity:0.6, ratingSize:0.22, ratingTime:"all"};','rating:"none", ratingPos:"tl", ratingOpacity:0.6, ratingSize:0.22, ratingTime:"all",\n  crt:{on:false,curve:0.5,scan:0.55,mask:"grille",maskAmt:0.35,glow:0.35,vig:0.45,bezel:true}};')
SETTINGS=rep(SETTINGS,'{k:"seg",id:"aspect",','{k:"seg",id:"ccrop",label:"Crop",show:()=>M==="camera",opts:[["sensor","Camera"],["orig","Original"],["4:3","4:3"],["16:9","16:9"],["1:1","1:1"]],get:()=>C.crop,set:v=>C.crop=v,pic:1,desc:"Camera uses the sensor’s own shape. Crops turn to match a portrait or landscape photo."},\n  {k:"seg",show:()=>M==="tape",id:"aspect",')
SETTINGS=rep(SETTINGS,'{k:"seg",id:"lines",','{k:"seg",show:()=>M==="tape",id:"lines",')
SETTINGS=rep(SETTINGS,''' overlay:[''',''' camera:[
  {k:"info"},
  {k:"seg",id:"cflash",label:"Flash",opts:[["off","Off"],["on","On"]],get:()=>C.flash?"on":"off",set:v=>C.flash=v==="on",pic:1,desc:"The harsh on-camera flash: bright centre, dark edges."},
  {k:"rng",id:"cnoise",label:"Sensor noise",min:0,max:100,step:1,fmt:f0,get:()=>C.noise,set:v=>C.noise=v,pic:1},
  {k:"seg",id:"cscale",label:"Export size",opts:[["1","Native"],["2","2×"],["4","4×"]],get:()=>String(C.scale),set:v=>C.scale=+v,pic:1,desc:"Bigger sizes keep the chunky pixels sharp when you share them."},
  {k:"head",label:"Video clips"},
  {k:"sw",id:"cmic",label:"Lo-fi mic sound",get:()=>C.mic,set:v=>C.mic=v,pic:1,desc:"Clips get the thin, compressed sound of an old camera microphone."},
 ],
 stamp:[
  {k:"seg",id:"sstyle",label:"Date stamp",opts:[["none","None"],["orange","Orange LED"],["yellow","Yellow LED"],["white","Digital white"],["red","Red dot matrix"]],get:()=>C.stamp,set:v=>{C.stamp=v; buildPanel();},pic:1},
  {k:"seg",id:"sfmt",label:"Date order",opts:[["yy","'26 10 17"],["dmy","17 10 '26"],["ymd","2026.10.17"],["mdy","10/17/2026"]],get:()=>C.stampFmt,set:v=>C.stampFmt=v,pic:1,show:()=>C.stamp!=="none"},
  {k:"sw",id:"stime",label:"Add the time",get:()=>C.stampTime,set:v=>C.stampTime=v,pic:1,show:()=>C.stamp!=="none"},
  {k:"rng",id:"ssize",label:"Stamp size",min:0.5,max:2.5,step:0.05,fmt:v=>Math.round(v*100)+"%",get:()=>C.stampSize,set:v=>C.stampSize=v,pic:1,show:()=>C.stamp!=="none"},
  {k:"seg",id:"spos",label:"Position",opts:[["br","Bottom right"],["bl","Bottom left"],["tr","Top right"],["tl","Top left"]],get:()=>C.stampPos,set:v=>C.stampPos=v,pic:1,show:()=>C.stamp!=="none"},
  {k:"head",label:"Frame"},
  {k:"seg",id:"sframe",label:"Frame style",opts:[["none","None"],["view","Viewfinder"],["phone","Phone camera"],["info","Shot info"],["custom","Your own"]],get:()=>C.frame,set:v=>{C.frame=v; if(v==="custom"&&!curFrame()&&FRAMES.length) C.cfId=FRAMES[FRAMES.length-1].id; buildPanel();},pic:1,desc:"Viewfinder adds an old camera screen's battery, frame counter and focus marks. Phone camera adds a 2000s phone's status and soft-key bars."},
  {k:"frames",id:"cflib",label:"Your frames",show:()=>C.frame==="custom",desc:"Upload a PNG with a see-through middle, like a photo booth border or a scrapbook frame. Your frames stay in this browser and go into your backups."},
  {k:"seg",id:"cffit",label:"Fit",opts:[["stretch","Stretch to fill"],["fit","Fit inside"],["fill","Cover (crop)"]],get:()=>C.cfFit,set:v=>C.cfFit=v,pic:1,show:()=>C.frame==="custom"&&!!curFrame()},
  {k:"rng",id:"cfscale",label:"Size",min:0.3,max:2,step:0.01,fmt:pct,get:()=>C.cfScale,set:v=>C.cfScale=v,pic:1,show:()=>C.frame==="custom"&&!!curFrame()},
  {k:"rng",id:"cfx",label:"Move left or right",min:-0.5,max:0.5,step:0.005,fmt:v=>v===0?"0":(v<0?"← ":"→ ")+Math.round(Math.abs(v)*100)+"%",get:()=>C.cfX,set:v=>C.cfX=v,pic:1,show:()=>C.frame==="custom"&&!!curFrame()},
  {k:"rng",id:"cfy",label:"Move up or down",min:-0.5,max:0.5,step:0.005,fmt:v=>v===0?"0":(v>0?"↑ ":"↓ ")+Math.round(Math.abs(v)*100)+"%",get:()=>C.cfY,set:v=>C.cfY=v,pic:1,show:()=>C.frame==="custom"&&!!curFrame()},
  {k:"rng",id:"cfop",label:"Opacity",min:0.05,max:1,step:0.01,fmt:pct,get:()=>C.cfOpacity,set:v=>C.cfOpacity=v,pic:1,show:()=>C.frame==="custom"&&!!curFrame()},
  {k:"seg",id:"cfblend",label:"Blend",opts:[["normal","Normal"],["screen","Screen"],["multiply","Multiply"]],get:()=>C.cfBlend,set:v=>C.cfBlend=v,pic:1,show:()=>C.frame==="custom"&&!!curFrame(),desc:"Screen hides black areas, good for light leaks and glow frames. Multiply hides white areas, good for paper and sketch frames."},
 ],
 screen:[
  {k:"sw",id:"crtOn",label:"CRT TV look",get:()=>P.crt.on,set:v=>{P.crt.on=v; buildPanel();},desc:"Shows the picture on an old tube TV. The output doubles in size so the scanlines and phosphor pattern show."},
  {k:"rng",id:"crtCurve",label:"Screen curve",min:0,max:1,step:0.01,fmt:pct,get:()=>P.crt.curve,set:v=>P.crt.curve=v,show:()=>P.crt.on},
  {k:"rng",id:"crtScan",label:"Scanlines",min:0,max:1,step:0.01,fmt:pct,get:()=>P.crt.scan,set:v=>P.crt.scan=v,show:()=>P.crt.on},
  {k:"seg",id:"crtMask",label:"Phosphor pattern",opts:[["grille","Aperture grille"],["shadow","Shadow mask"],["none","None"]],get:()=>P.crt.mask,set:v=>P.crt.mask=v,show:()=>P.crt.on,desc:"Aperture grille is the vertical stripes of a Trinitron. Shadow mask is the dot pattern of most other TVs."},
  {k:"rng",id:"crtMaskAmt",label:"Pattern strength",min:0,max:1,step:0.01,fmt:pct,get:()=>P.crt.maskAmt,set:v=>P.crt.maskAmt=v,show:()=>P.crt.on&&P.crt.mask!=="none"},
  {k:"rng",id:"crtGlow",label:"Glow",min:0,max:1,step:0.01,fmt:pct,get:()=>P.crt.glow,set:v=>P.crt.glow=v,show:()=>P.crt.on},
  {k:"rng",id:"crtVig",label:"Edge shadow",min:0,max:1,step:0.01,fmt:pct,get:()=>P.crt.vig,set:v=>P.crt.vig=v,show:()=>P.crt.on},
  {k:"sw",id:"crtBezel",label:"TV surround",get:()=>P.crt.bezel,set:v=>P.crt.bezel=v,show:()=>P.crt.on,desc:"A dark plastic TV frame with rounded screen corners and a faint glass reflection."},
 ],
 overlay:[''')
# ---- panel
PANEL=rep(PANEL,'''      n.textContent = kind==="video" ? "These controls shape the sound of your video when you render it." : "Sound controls apply to videos. Load a clip with Eject or Rec, then preview the sound here."; panel.appendChild(n); continue; }''',
'''      n.textContent = kind==="video" ? "These controls shape the sound of your video when you render it." : kind==="audio" ? "These controls shape your sound file. Preview it here, then tap Render sound." : "Sound controls apply to videos and sound files. Load one with Eject, then preview the sound here."; panel.appendChild(n); continue; }
    if(c.k==="info"){ const n=document.createElement("div"); n.className="anote"; const T=camType(); n.textContent=`${T.name}: photos at ${T.res.join("×")}, video clips at ${T.vres.join("×")} and ${T.vfps} frames a second. Pick a camera and a look above.`; panel.appendChild(n); continue; }''')
PANEL=rep(PANEL,'''  if(tab==="audio"){''','''  if(tab==="camera"||tab==="stamp"){ reset.textContent="Reset camera settings"; reset.onclick=()=>{ C=Object.assign(cdefaults(),{type:C.type,look:C.look}); buildPanel(); changed(true); }; acts.appendChild(reset); }
  else if(tab==="screen"){ reset.textContent="Reset screen"; reset.onclick=()=>{ P.crt=clone(PDEF.crt); buildPanel(); changed(false); }; acts.appendChild(reset); }
  else if(tab==="audio"){''')
# ---- shelves
SHELVES=rep(SHELVES,'''$("tabs").addEventListener("click",e=>{ const b=e.target.closest("button"); if(!b) return; tab=b.id.slice(4);
  document.querySelectorAll("#tabs button").forEach(x=>x.setAttribute("aria-selected",String(x===b))); buildPanel(); remember(); });
''','')
SHELVES=rep(SHELVES,'''function pick(p,keepSeed){ const seed=S.seed; S=presetSettings(p); if(keepSeed===true && !p.j) S.seed=seed; presetId=p.id; syncTapes(); buildPanel(); changed(P.osd==="play"); }''',
'''function pick(p,keepSeed){ const seed=S.seed; S=presetSettings(p); if(keepSeed===true && !p.j) S.seed=seed; presetId=p.id; lookId=""; syncTapes(); buildLooks(); buildPanel(); changed(P.osd==="play"); }
function chip(name,sub){ const b=document.createElement("button"); b.className="tape"; b.innerHTML="<b></b><small></small>"; b.querySelector("b").textContent=name; b.querySelector("small").textContent=sub; return b; }''')
SHELVES=rep(SHELVES,'''function buildShelves(){
  const a=$("tapes"), m=$("mine"); a.textContent=""; m.textContent="";''','''function buildShelves(){
  const a=$("tapes"), m=$("mine"); a.textContent=""; m.textContent="";
  if(M==="camera"){ $("shelfALabel").textContent="Camera"; $("shelfBLabel").textContent="Look"; $("removeWrap").hidden=true;
    CAMS.forEach(t=>{ const b=chip(t.name,t.sub); b.dataset.cam=t.id; b.onclick=()=>{ C.type=t.id; lookId=""; if(kind==="video"){ V.fps=t.vfps; syncVideoUi(); } syncTapes(); buildLooks(); buildPanel(); changed(true); }; a.appendChild(b); });
    CLOOKS.forEach(l=>{ const b=chip(l.name,l.sub); b.dataset.clook=l.id; b.onclick=()=>{ C.look=l.id; lookId=""; syncTapes(); buildLooks(); changed(true); }; m.appendChild(b); });
    syncTapes(); return; }
  $("shelfALabel").textContent="Tape"; $("shelfBLabel").textContent="Your presets";''')
SHELVES=rep(SHELVES,'''function syncTapes(){ document.querySelectorAll(".tape[data-id]").forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.id===presetId)));''','''function syncTapes(){ document.querySelectorAll(".tape[data-id]").forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.id===presetId)));
  document.querySelectorAll(".tape[data-cam]").forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.cam===C.type)));
  document.querySelectorAll(".tape[data-clook]").forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.clook===C.look)));
  if(M==="camera") return;''')
SHELVES=rep(SHELVES,'''function syncVfd(){ $("vfdTape").textContent=S.vhs.on?(S.vhs.tape==="NONE"?"VHS":S.vhs.tape):"AIR"; $("vfdLines").textContent=P.lines; }''',
'''function syncVfd(){ if(M==="camera"){ const T=camType(); $("vfdTape").textContent=T.label; $("vfdLines").textContent=(kind==="video"?T.vres:T.res)[0]; return; }
  $("vfdTape").textContent=S.vhs.on?(S.vhs.tape==="NONE"?"VHS":S.vhs.tape):"AIR"; $("vfdLines").textContent=P.lines; }''')
SHELVES=rep(SHELVES,'''document.querySelectorAll("#tabs button").forEach(x=>x.setAttribute("aria-selected",String(x.id==="tab-"+tab)));\n''','')
SHELVES=SHELVES.replace('const name=((p?p.name:"pocket-ntsc")','const name=((p?p.name:"pocket-retro")')
# ---- vcfg
VCFG=rep(VCFG,'["avc","avc1.42002a"],','["avc","avc1.42002a"],["avc","avc1.420028"],["avc","avc1.4d0028"],["avc","avc1.640032"],')
# ---- audio engine
AUD=AUD.replace('videoFile','mediaFile')
AUD=rep(AUD,'if(kind!=="video"){ if(note) note.textContent="Load a video first with Eject or Rec. Photos have no sound."; return; }','if(kind!=="video"&&kind!=="audio"){ if(note) note.textContent="Load a video or sound file first with Eject. Photos have no sound."; return; }')
exec(open('retro/build_extra.py').read())
# ---- main
main=open('retro/main.js').read()
fontdata='data:font/ttf;base64,'+__import__('base64').b64encode(open('retro/VCR_OSD_MONO.ttf','rb').read()).decode()
for k,v in [('%%SETTINGS%%',SETTINGS),('%%PANEL%%',PANEL),('%%SHELVES%%',SHELVES),('%%GEOM%%',GEOM),('%%BORDER%%',BORDER),('%%VIDEOCFG%%',VCFG),('%%AUDIOENG%%',AUD),('%%SAMPLE%%',SAMPLE)]:
    assert main.count(k)==1,k; main=main.replace(k,v)
main=rep(main,'''$("divider").style.left=cmpX+"%"; $("cmpBtn").setAttribute("aria-pressed",String(cmpOn)); }''','''$("divider").style.left=cmpX+"%"; $("cmpBtn").setAttribute("aria-pressed",String(cmpOn)); screen.classList.toggle("cmp-on",cmpOn); }''')
# ---- css + head
full=open('pocket-ntsc.html').read()
style=full[full.index('<style>')+7:full.index('</style>')]
head_links=full[:full.index('<style>')].replace('<title>Pocket NTSC</title>','<title>Pocket Retro</title>')
engine=full[full.index('<script id="engine">'):full.index('</script>',full.index('<script id="engine">'))]
engine=engine+'\n'+open('retro/engine_extra.js').read()+'\n</script>'
mux='<script src="https://cdn.jsdelivr.net/npm/mp4-muxer@5.2.1/build/mp4-muxer.js"></script>'
out=head_links+'<style>'+style+open('retro/extra.css').read().replace('%%VCRFONT%%',fontdata)+'</style>\n\n'+open('retro/body.html').read()+'\n'+engine+'\n\n'+mux+'\n'+main
open('pocket-retro.html','w').write(out); print('ok',len(out))
