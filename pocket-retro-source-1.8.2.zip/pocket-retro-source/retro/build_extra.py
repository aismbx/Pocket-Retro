# 1.3.0 additions applied to the slices taken from pocket-ntsc.html (exec'd from build.py)
BORDER='''function borderGeom(W,H){
  const ev=n=>Math.max(2,Math.round(n/2)*2);
  if(P.border==="vertical"){ /* a tall 9:16 frame for phones: the picture across the middle, zoomed in if you like (the sides are trimmed) */
    const Wo=ev(W), Ho=ev(Wo*16/9), z=Math.max(1,P.vZoom||1); let h=ev(H*z*Wo/W), sw=ev(W/z), sh=H;
    if(h>Ho){ sh=Math.max(2,Math.round(H*Ho/h)); h=Ho; }
    const y=Math.max(0,Math.min(Ho-h,Math.round((Ho-h)/2-(P.vY||0)*Ho)));
    return {Wo,Ho,x:0,y,w:Wo,h,sx:(W-sw)>>1,sy:(H-sh)>>1,sw,sh}; }
  if(P.border==="pillar"){ /* a 4:3 picture inside a 16:9 frame: bars left and right; wider pictures are trimmed to 4:3 */
    const sw=W/H>4/3?ev(H*4/3):W, sh=H, Wo=ev(H*16/9); return {Wo,Ho:H,x:(Wo-sw)>>1,y:0,w:sw,h:sh,sx:(W-sw)>>1,sy:0,sw,sh}; }
  if(P.border==="letter"){ /* a widescreen 16:9 band inside a 4:3 frame: bars top and bottom; taller pictures are trimmed to 16:9 */
    const sw=W, sh=W/H<16/9?ev(W*9/16):H, Ho=Math.max(sh,ev(W*3/4)); return {Wo:W,Ho,x:0,y:(Ho-sh)>>1,w:sw,h:sh,sx:0,sy:(H-sh)>>1,sw,sh}; }
  if(P.border==="frame"){ const b=Math.max(1,Math.round(H*P.borderSize)); return {Wo:W+2*b,Ho:H+2*b,x:b,y:b,w:W,h:H,sx:0,sy:0,sw:W,sh:H}; }
  return {Wo:W,Ho:H,x:0,y:0,w:W,h:H,sx:0,sy:0,sw:W,sh:H};
}
const rawCanvas=document.createElement("canvas");
function framed(buf,W,H,dst){ bufToCanvas(buf,W,H,rawCanvas); return frameCanvas(rawCanvas,dst); }'''

SETTINGS=rep(SETTINGS,'crt:{on:false,curve:0.5,scan:0.55,mask:"grille",maskAmt:0.35,glow:0.35,vig:0.45,bezel:true}};',
 'crt:{on:false,curve:0.5,scan:0.55,mask:"grille",maskAmt:0.35,glow:0.35,vig:0.45,bezel:true},\n  cc:{on:false,text:"[ MUSIC PLAYING ]",size:1,pos:"bottom",offset:0.08,align:"center",color:"white",bg:"black",soft:false,from:0,to:0}};')
SETTINGS=rep(SETTINGS,'function adefaults(){ return {on:true, preset:"lp", mix:1, vol:1,','function adefaults(){ return {on:true, preset:"lp", match:true, mix:1, vol:1,')
SETTINGS=rep(SETTINGS,'{k:"seg",id:"border",label:"Border style",opts:[["none","None"],["pillar","Pillarbox 16:9"],["letter","Letterbox 4:3"],["frame","Frame"]],get:()=>P.border,set:v=>{P.border=v; buildPanel();},pic:1,desc:"Bars are added after the effect, like a TV station framing an old 4:3 show for widescreen."},',
 '{k:"seg",id:"border",label:"Border style",opts:[["none","None"],["pillar","Pillarbox 16:9"],["letter","Letterbox 4:3"],["frame","Frame"],["vertical","Vertical 9:16"]],get:()=>P.border,set:v=>{P.border=v; buildPanel();},pic:1,desc:"Pillarbox puts a 4:3 picture in a 16:9 frame with bars at the sides. Letterbox puts a widescreen band in a 4:3 frame with bars above and below. Vertical 9:16 makes a tall picture for TikTok, Reels and Shorts. Pictures are trimmed to fit."},')
SETTINGS=rep(SETTINGS,'  {k:"head",label:"Age rating"},','''  {k:"head",label:"Closed captions"},
  {k:"sw",id:"ccOn",label:"Show captions",get:()=>P.cc.on,set:v=>{P.cc.on=v; buildPanel();},desc:"Text on black boxes in the VCR OSD Mono font, like a TV's caption decoder."},
  {k:"text",id:"ccText",label:"Caption text",get:()=>P.cc.text,set:v=>P.cc.text=v,show:()=>P.cc.on,desc:"Up to 4 lines. Press Return for a new line."},
  {k:"rng",id:"ccSize",label:"Size",min:0.5,max:2.5,step:0.05,fmt:v=>Math.round(v*100)+"%",get:()=>P.cc.size,set:v=>P.cc.size=v,show:()=>P.cc.on},
  {k:"seg",id:"ccPos",label:"Position",opts:[["bottom","Bottom"],["top","Top"]],get:()=>P.cc.pos,set:v=>P.cc.pos=v,show:()=>P.cc.on},
  {k:"rng",id:"ccOff",label:"Distance from the edge",min:0,max:0.45,step:0.005,fmt:v=>Math.round(v*100)+"%",get:()=>P.cc.offset,set:v=>P.cc.offset=v,show:()=>P.cc.on},
  {k:"seg",id:"ccAlign",label:"Alignment",opts:[["left","Left"],["center","Centre"],["right","Right"]],get:()=>P.cc.align,set:v=>P.cc.align=v,show:()=>P.cc.on},
  {k:"seg",id:"ccColor",label:"Text colour",opts:[["white","White"],["yellow","Yellow"],["cyan","Cyan"],["green","Green"],["magenta","Magenta"],["red","Red"],["blue","Blue"]],get:()=>P.cc.color,set:v=>P.cc.color=v,show:()=>P.cc.on,desc:"The seven colours analogue TV captions could use. White is the usual one, then yellow."},
  {k:"seg",id:"ccBg",label:"Background",opts:[["black","Black"],["half","See-through"],["none","None"]],get:()=>P.cc.bg,set:v=>P.cc.bg=v,show:()=>P.cc.on},
  {k:"sw",id:"ccSoft",label:"Run through the effect",get:()=>P.cc.soft,set:v=>P.cc.soft=v,show:()=>P.cc.on,pic:1,desc:"Off: crisp, like captions your TV draws. On: soft and smeared, like captions recorded onto a tape."},
  {k:"rng",id:"ccFrom",label:"In videos, show from",min:0,max:600,step:0.1,fmt:v=>fmtT(v),get:()=>P.cc.from,set:v=>P.cc.from=v,pic:1,show:()=>P.cc.on&&kind==="video"},
  {k:"rng",id:"ccTo",label:"Until (0 = the end)",min:0,max:600,step:0.1,fmt:v=>v>0?fmtT(v):"End",get:()=>P.cc.to,set:v=>P.cc.to=v,pic:1,show:()=>P.cc.on&&kind==="video"},
  {k:"head",label:"Age rating"},''')
SETTINGS=rep(SETTINGS,'  {k:"seg",id:"aPreset",label:"Sound preset",','''  {k:"sw",id:"aMatch",label:"Match sound to the tape preset",get:()=>A.match,set:v=>{A.match=v; if(v){ const p=findPreset(presetId); if(p) matchSound(p); } buildPanel();},aud:1,desc:"Picking a tape preset picks the matching sound, for example the Worn EP tape gets Worn EP sound."},
  {k:"seg",id:"aPreset",label:"Sound preset",''')
SHELVES=rep(SHELVES,'''presetId=p.id; lookId=""; syncTapes(); buildLooks(); buildPanel(); changed(P.osd==="play"); }''','''presetId=p.id; lookId=""; if(A.match) matchSound(p); syncTapes(); buildLooks(); buildPanel(); changed(P.osd==="play"); }
const SOUND_FOR={lp:"lp",sp:"sp",bc:"mono",cam:"cam",ep:"ep",dub:"dub",cable:"off",jvc:"cam",nvm1:"cam",lpntsc:"mono",ecolor:"mono",ebw:"mono",perfect:"sp",bw:"mono"};
function matchSound(p){ let id=SOUND_FOR[p.id]; if(!id){ const Sx=presetSettings(p); id=!Sx.vhs.on?"mono":({SP:"sp",LP:"lp",EP:"ep"})[Sx.vhs.tape]||"lp"; }
  const mix=A.mix, vol=A.vol; A=audioPreset(id); if(id!=="off"){ A.mix=mix; A.vol=vol; } A.match=true; }''')
PANEL=rep(PANEL,'''    } else if(c.k==="sw"){''','''    } else if(c.k==="text"){
      row.innerHTML=`<label for="c-${c.id}"></label><textarea id="c-${c.id}" rows="2" maxlength="160" spellcheck="false"></textarea>`;
      row.querySelector("label").textContent=c.label; const ta=row.querySelector("textarea"); ta.value=c.get();
      let tt=null; ta.addEventListener("input",()=>{ c.set(ta.value.split("\\n").slice(0,4).join("\\n")); clearTimeout(tt); tt=setTimeout(()=>ch(),250); });
    } else if(c.k==="sw"){''')
GEOM=rep(GEOM,'  if(P.rating!=="none") drawRating(x,W,H,offsetMs||0);','  if(P.rating!=="none") drawRating(x,W,H,offsetMs||0);\n  if(P.cc.on && P.cc.soft) drawCaptions(x,0,0,W,H,offsetMs||0);')

GEOM=rep(GEOM,'  const H=P.lines, W=Math.max(16,Math.min(1600,Math.round(H*A/2)*2));','  const H=LIVE_LINES||P.lines, W=Math.max(16,Math.min(1600,Math.round(H*A/2)*2));')

exec(open('retro/build_extra150.py').read())

exec(open('retro/build_extra160.py').read())

exec(open('retro/build_extra170.py').read())

exec(open('retro/build_extra180.py').read())
