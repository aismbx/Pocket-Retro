# ---- 1.6.0 custom frame library control ----
PANEL=rep(PANEL,"""    } else if(c.k==="sw"){""","""    } else if(c.k==="frames"){
      row.innerHTML=`<span class="lbl"></span><div class="framelib" role="group"></div><input type="file" accept="image/png,image/*" class="vh" tabindex="-1" aria-hidden="true" id="inFrame">`;
      row.querySelector(".lbl").textContent=c.label; const lib=row.querySelector(".framelib"), fi=row.querySelector("input"); lib.setAttribute("aria-label",c.label);
      for(const f of FRAMES){ const b=document.createElement("button"); b.type="button"; b.className="fthumb"; b.setAttribute("aria-pressed",String(f.id===curFrameId())); b.setAttribute("aria-label","Use frame "+f.name); b.title=f.name;
        const im=document.createElement("img"); im.src=f.url; im.alt=""; b.appendChild(im); b.onclick=()=>{ setFrameId(f.id); buildPanel(); changed(true); }; lib.appendChild(b); }
      const add=document.createElement("button"); add.type="button"; add.className="fthumb add"; add.id="c-frameAdd"; add.textContent="+ Upload"; add.onclick=()=>fi.click(); lib.appendChild(add);
      fi.onchange=async()=>{ const f=fi.files&&fi.files[0]; fi.value=""; if(f) await addFrameFile(f); };
      const cf=curFrame(); if(cf){ const w=document.createElement("div"); w.className="framerm"; const rm=document.createElement("button"); rm.type="button"; rm.className="link"; rm.id="c-frameRemove"; rm.textContent=`Remove “${cf.name}”`; rm.onclick=()=>removeFrame(cf.id); w.appendChild(rm); row.appendChild(w); }
    } else if(c.k==="sw"){""")
