import os, shutil, json, glob
from PIL import Image, ImageDraw
SP=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT=os.path.join(SP,'site','pocket-retro'); shutil.rmtree(os.path.join(SP,'site'),ignore_errors=True); os.makedirs(OUT)
s=open(os.path.join(SP,'pocket-retro.html')).read()
def rep(a,b):
    global s; assert s.count(a)==1,(a[:70],s.count(a)); s=s.replace(a,b)

VERSION="1.8.2"
# ---------- fonts (self-hosted, flat file names) ----------
fonts=[("VT323","vt323-latin-400-normal.woff2",400,"fontsource-vt323-*"),
       ("Barlow Condensed","barlow-condensed-latin-500-normal.woff2",500,"fontsource-barlow-condensed-*"),
       ("Barlow Condensed","barlow-condensed-latin-600-normal.woff2",600,"fontsource-barlow-condensed-*"),
       ("Barlow Condensed","barlow-condensed-latin-700-normal.woff2",700,"fontsource-barlow-condensed-*"),
       ("Barlow","barlow-latin-400-normal.woff2",400,"fontsource-barlow-5*"),
       ("Barlow","barlow-latin-500-normal.woff2",500,"fontsource-barlow-5*"),
       ("Barlow","barlow-latin-600-normal.woff2",600,"fontsource-barlow-5*")]
ff=""; files=[]
for fam,fn,w,pkg in fonts:
    srcf=os.path.join(SP,"fonts",fn); shutil.copy(srcf,os.path.join(OUT,fn)); files.append(fn)
    ff+=f"@font-face{{font-family:'{fam}';font-style:normal;font-weight:{w};font-display:swap;src:url('{fn}') format('woff2')}}\n"
shutil.copy(os.path.join(SP,'mp4-muxer.js'),os.path.join(OUT,'mp4-muxer.js')); files.append('mp4-muxer.js')
shutil.copy(os.path.join(SP,'retro','VCR_OSD_MONO.ttf'),os.path.join(OUT,'vcr-osd-mono.ttf')); files.append('vcr-osd-mono.ttf')
import re as _re
s=_re.sub(r'url\(data:font/ttf;base64,[A-Za-z0-9+/=]+\)','url(vcr-osd-mono.ttf)',s,count=1)

# ---------- head ----------
rep('''<title>Pocket Retro</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=VT323&family=Barlow+Condensed:wght@500;600;700&family=Barlow:wght@400;500;600&display=swap">
<style>''','''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Pocket Retro</title>
<meta name="description" content="Retro photo, video and sound editor: 2000s digicam and NTSC/VHS looks.">
<meta name="theme-color" content="#1e2024">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Pocket Retro">
<link rel="manifest" href="manifest.webmanifest">
<link rel="icon" type="image/png" sizes="192x192" href="icon-192.png">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<style>
'''+ff+'''*,*::before,*::after{box-sizing:border-box}
:root{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}
body{margin:0;-webkit-text-size-adjust:100%}
img{max-width:100%}
[hidden]{display:none!important}
''')
rep('''<div class="deck">''','''</head>
<body>
<div class="deck">''')
rep('<script src="https://cdn.jsdelivr.net/npm/mp4-muxer@5.2.1/build/mp4-muxer.js"></script>','<script src="mp4-muxer.js"></script>')
assert s.rstrip().endswith('</script>'); s=s.rstrip()+'\n</body>\n</html>\n'

# ---------- saving: the iPhone share sheet, with a download fallback ----------
rep('''async function getDownloads(){ if(window.claude && !downloads){ try{ downloads=await window.claude.use("downloads"); }catch(e){} } return downloads; }''',
'''const MIME={jpg:"image/jpeg",jpeg:"image/jpeg",png:"image/png",mp4:"video/mp4",zip:"application/zip",json:"application/json",wav:"audio/wav"};
function asFile(name,data){ const ext=(name.split(".").pop()||"").toLowerCase(); const type=(name.endsWith(".mp4")&&data.type)?data.type:(MIME[ext]||"application/octet-stream");
  return new File([data instanceof Blob?data:new Blob([data])],name,{type}); }
function fallbackDownload(file){ const u=URL.createObjectURL(file), a=document.createElement("a"); a.href=u; a.download=file.name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(u),60000); }
async function shareFiles(list){
  if(navigator.canShare && navigator.share && navigator.canShare({files:list})){
    try{ await navigator.share({files:list}); return {status:"saved"}; }
    catch(e){ if(e&&e.name==="AbortError") throw {code:"declined"}; }
  }
  for(const f of list) fallbackDownload(f); return {status:"saved"};
}
const SITE_SAVER={ save:async({filename,data})=>shareFiles([asFile(filename,data)]), saveMany:async(items)=>shareFiles(items.map(i=>asFile(i.filename,i.data))) };
async function getDownloads(){ downloads=SITE_SAVER; return downloads; }''')
rep('''$("selSave").onclick=async()=>{ const d=await getDownloads(); if(!d){ $("note").textContent="Saving isn't available here."; return; }''',
'''$("selSave").onclick=async()=>{ const d=await getDownloads(); if(!d){ $("note").textContent="Saving isn't available here."; return; }
  if(d.saveMany){ const items=roll.filter(r=>sel.has(r.id)); try{ await d.saveMany(items.map(it=>({filename:fname(it),data:it.blob}))); $("note").textContent=`Shared ${items.length} item${items.length>1?"s":""}. Tap Save Image or Save Video to put them in Photos.`; }catch(e){ $("note").textContent="Not saved."; } return; }''')
s=s.replace('Saved. On iPhone, tap Save Image in the share sheet to add it to Photos.','Tap Save Image in the share sheet to add it to Photos.')
s=s.replace('Saved. On iPhone, tap Save Video in the share sheet to add it to Photos.','Tap Save Video in the share sheet to add it to Photos.')

# ---------- live viewfinder for Camera mode ----------
rep('''$("bRec").onclick=()=>{ if(rendering) return; $("inCam").value=""; $("inCam").click(); };''','''$("bRec").onclick=()=>{ if(rendering) return; if(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.isSecureContext){ openFinder(); return; } $("inCam").value=""; $("inCam").click(); };
/* live viewfinder: the camera feed, developed through the current mode in real time. Photo or video. */
let fStream=null, fFacing="environment", fRun=false, fMode="photo", fRec=null, fChunks=[], fT0=0, fTick=null;
const fVid=document.createElement("video"); fVid.muted=true; fVid.playsInline=true; fVid.setAttribute("playsinline","");
async function startStream(){
  if(fStream) fStream.getTracks().forEach(t=>t.stop());
  fStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:fFacing,width:{ideal:1920},height:{ideal:1440}},audio:fMode==="video"});
  fVid.srcObject=fStream; await fVid.play().catch(()=>{});
  await new Promise(r=>{ if(fVid.videoWidth) r(); else fVid.onloadedmetadata=()=>r(); setTimeout(r,3000); });
}
function syncFinderUi(){ $("fPhoto").setAttribute("aria-pressed",String(fMode==="photo")); $("fVideo").setAttribute("aria-pressed",String(fMode==="video"));
  $("fShutter").classList.toggle("vid",fMode==="video"); $("fShutter").classList.toggle("recording",!!fRec); $("fShutter").setAttribute("aria-label",fMode==="photo"?"Take photo":fRec?"Stop recording":"Start recording");
  $("fFlip").disabled=!!fRec; $("fPhoto").disabled=!!fRec; $("fVideo").disabled=!!fRec; }
async function openFinder(){
  $("finder").hidden=false; document.body.classList.add("finder-open"); $("fMsg").textContent="Starting the camera…"; syncFinderUi();
  try{ await startStream(); }catch(e){ $("fMsg").textContent="The camera couldn't start. Allow camera access for this site in Settings › Safari › Camera, or use "+(M==="tape"?"Eject":"Library")+"."; return; }
  $("fMsg").textContent = M==="tape" ? "Live Tape preview (lighter than the final render)." : ""; fRun=true; finderLoop();
}
function closeFinder(){ if(fRec){ try{ fRec.onstop=null; fRec.stop(); }catch(e){} fRec=null; clearInterval(fTick); }
  fRun=false; if(fStream){ fStream.getTracks().forEach(t=>t.stop()); fStream=null; } $("finder").hidden=true; document.body.classList.remove("finder-open"); }
async function finderLoop(){
  const cv=$("fCanvas"), x=cv.getContext("2d"), work=document.createElement("canvas"), wx=work.getContext("2d",{willReadFrequently:true});
  let frame=0;
  while(fRun){
    const vw=fVid.videoWidth, vh=fVid.videoHeight; if(!vw){ await sleep(50); continue; }
    let W,H;
    if(M==="camera"){ const T=camType(); [W,H]=T.vres; if(vh>vw) [W,H]=[H,W]; }
    else { H=240; W=Math.round(H*(vw/vh)/2)*2; }
    const Ar=W/H; let cw=vw, ch=vh; if(vw/vh>Ar) cw=vh*Ar; else ch=vw/Ar;
    if(work.width!==W||work.height!==H){ work.width=W; work.height=H; }
    wx.save(); if(fFacing==="user"){ wx.translate(W,0); wx.scale(-1,1); } wx.drawImage(fVid,(vw-cw)/2,(vh-ch)/2,cw,ch,0,0,W,H); wx.restore();
    const data=wx.getImageData(0,0,W,H).data;
    const out = M==="camera" ? await engine("cam",data,W,H,camParams(),frame++) : await engine("ntsc",data,W,H,clone(S),frame++);
    if(!fRun) break;
    if(cv.width!==W||cv.height!==H){ cv.width=W; cv.height=H; }
    x.putImageData(new ImageData(new Uint8ClampedArray(out.buf),W,H),0,0);
    if(M==="camera") drawCamOverlays(x,W,H,0,frame);
    if(fRec){ x.fillStyle="#ff3b30"; x.beginPath(); x.arc(W*0.06,H*0.08,Math.max(3,H*0.025),0,Math.PI*2); x.fill(); }
    await new Promise(r=>requestAnimationFrame(r));
  }
}
function pickRecType(){ if(!window.MediaRecorder) return null; for(const t of ["video/mp4;codecs=avc1","video/mp4","video/webm;codecs=vp9,opus","video/webm"]) { try{ if(MediaRecorder.isTypeSupported(t)) return t; }catch(e){} } return ""; }
$("fShutter").onclick=async()=>{
  const vw=fVid.videoWidth, vh=fVid.videoHeight; if(!vw) return;
  if(fMode==="photo"){
    const c=document.createElement("canvas"); c.width=vw; c.height=vh; const x=c.getContext("2d");
    if(fFacing==="user"){ x.translate(vw,0); x.scale(-1,1); } x.drawImage(fVid,0,0);
    $("finder").classList.add("flash"); setTimeout(()=>$("finder").classList.remove("flash"),180);
    const b=await toBlob(c,"image/jpeg",0.95); closeFinder();
    if(b) takeFile(new File([b],`snap_${Date.now()}.jpg`,{type:"image/jpeg",lastModified:Date.now()}),null,{snap:M==="camera"});
    return;
  }
  if(!fRec){
    const type=pickRecType(); if(type===null){ $("fMsg").textContent="This browser can't record video here. Use "+(M==="tape"?"Eject":"Library")+" to open a clip."; return; }
    fChunks=[]; try{ fRec=type?new MediaRecorder(fStream,{mimeType:type}):new MediaRecorder(fStream); }catch(e){ $("fMsg").textContent="Recording couldn't start on this device."; return; }
    fRec.ondataavailable=e=>{ if(e.data&&e.data.size) fChunks.push(e.data); };
    fRec.onstop=()=>{ const mt=(fRec&&fRec.mimeType)||type||"video/mp4", blob=new Blob(fChunks,{type:mt}); fRec=null; clearInterval(fTick); closeFinder();
      const ext=mt.includes("webm")?"webm":"mp4"; takeFile(new File([blob],`clip_${Date.now()}.${ext}`,{type:mt.split(";")[0],lastModified:Date.now()})); };
    fRec.start(500); fT0=Date.now(); syncFinderUi();
    fTick=setInterval(()=>{ const s=Math.floor((Date.now()-fT0)/1000); $("fMsg").textContent=`● Recording ${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}  Tap the button again to stop.`; },250);
  } else { try{ fRec.stop(); }catch(e){} syncFinderUi(); }
};
$("fFlip").onclick=async()=>{ if(fRec) return; fFacing=fFacing==="environment"?"user":"environment"; try{ await startStream(); }catch(e){ $("fMsg").textContent="That camera couldn't start."; } };
async function setFinderMode(m){ if(fRec||fMode===m) return; fMode=m; syncFinderUi();
  try{ await startStream(); $("fMsg").textContent = m==="video" ? "Video mode. The clip is recorded clean, then the effect is applied when you render." : (M==="tape"?"Live Tape preview (lighter than the final render).":""); }
  catch(e){ fMode="photo"; syncFinderUi(); $("fMsg").textContent="The microphone couldn't start. Allow microphone access for this site in Settings › Safari, then try again."; try{ await startStream(); }catch(e2){} } }
$("fPhoto").onclick=()=>setFinderMode("photo");
$("fVideo").onclick=()=>setFinderMode("video");
$("fClose").onclick=closeFinder;
document.addEventListener("visibilitychange",()=>{ if(document.hidden && fRun) closeFinder(); });''')
rep('''<div class="panel vbox" id="vbox" hidden>''','''<div class="finder" id="finder" hidden role="dialog" aria-label="Camera viewfinder">
    <canvas id="fCanvas" width="320" height="240"></canvas>
    <div class="fmsg" id="fMsg"></div>
    <div class="fbar">
      <button class="fbtn" id="fClose">Close</button>
      <button class="fshut" id="fShutter" aria-label="Take photo"></button>
      <button class="fbtn" id="fFlip">Flip</button>
    </div>
    <div class="fmodes" role="group" aria-label="Camera mode"><button class="fbtn" id="fPhoto" aria-pressed="true">Photo</button><button class="fbtn" id="fVideo" aria-pressed="false">Video</button></div>
  </div>

  <div class="panel vbox" id="vbox" hidden>''')
rep('''.resetbox{padding:12px 14px}''','''.resetbox{padding:12px 14px}
.finder{position:fixed;inset:0;z-index:50;background:#000;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;
  padding:max(16px,env(safe-area-inset-top,0px)) max(16px,env(safe-area-inset-right,0px)) max(20px,env(safe-area-inset-bottom,0px)) max(16px,env(safe-area-inset-left,0px))}
.finder canvas{width:100%;max-height:70vh;object-fit:contain;image-rendering:pixelated;border-radius:8px;background:#111}
.finder.flash canvas{filter:brightness(2.5)}
.fmsg{color:var(--silk);font-size:14px;text-align:center;min-height:1.2em;max-width:34ch}
.fbar{display:flex;align-items:center;justify-content:space-between;width:100%;max-width:420px}
.fbtn{border:0;background:var(--case-3);color:var(--silk);font:600 13px var(--f-silk);letter-spacing:.12em;text-transform:uppercase;border-radius:8px;padding:10px 14px;cursor:pointer}
.fshut{width:76px;height:76px;border-radius:50%;border:5px solid #fff;background:var(--rec);cursor:pointer;box-shadow:0 0 0 3px #000 inset}
.fshut:active{transform:scale(.94)}
.fmodes{display:flex;gap:6px}
.fmodes .fbtn[aria-pressed="true"]{background:var(--vfd);color:#04201b}
.fbtn:disabled{opacity:.4}
.fshut.vid{background:#fff}
.fshut.vid::after{content:"";display:block;width:26px;height:26px;margin:auto;border-radius:50%;background:var(--rec)}
.fshut.recording::after{border-radius:5px;width:24px;height:24px}
body.finder-open{overflow:hidden}''')
s=s.replace('Snap takes a photo or short clip. Library opens one you already have.','Snap opens a live viewfinder for photos and clips. Library opens one you already have.')
s=s.replace('Eject opens photos, videos or sound files. Rec uses the camera.','Eject opens photos, videos or sound files. Rec opens a live camera with a VHS preview.')
s=s.replace('Pocket Retro is an unofficial personal app.','Pocket Retro is an unofficial personal app (version '+VERSION+').')

# ---------- offline support ----------
rep('''/* ================= boot ================= */''','''/* ================= offline support ================= */
if("serviceWorker" in navigator && (location.protocol==="https:"||location.hostname==="localhost")){
  window.addEventListener("load",()=>{ navigator.serviceWorker.register("sw.js",{updateViaCache:"none"}).then(r=>{ r.update().catch(()=>{}); }).catch(()=>{}); });
  /* a new version takes over: reload once so it shows straight away (not while rendering) */
  let reloaded=false, hadController=!!navigator.serviceWorker.controller;
  navigator.serviceWorker.addEventListener("controllerchange",()=>{ if(!hadController){ hadController=true; return; } if(reloaded||rendering) return; reloaded=true; location.reload(); });
}

/* ================= boot ================= */''')
open(os.path.join(OUT,'index.html'),'w').write(s)

# ---------- icons ----------
def design(S):
    im=Image.new("RGB",(S,S),(30,32,36)); d=ImageDraw.Draw(im)
    d.rounded_rectangle([S*0.10,S*0.24,S*0.90,S*0.78],radius=int(S*0.06),fill=(52,56,62))
    d.rectangle([S*0.16,S*0.30,S*0.84,S*0.50],fill=(233,162,59))
    d.rectangle([S*0.16,S*0.50,S*0.84,S*0.54],fill=(115,242,216))
    d.rounded_rectangle([S*0.30,S*0.58,S*0.70,S*0.72],radius=int(S*0.03),fill=(11,21,19))
    for cx in (S*0.40,S*0.60):
        cy=S*0.65; d.ellipse([cx-S*0.05,cy-S*0.05,cx+S*0.05,cy+S*0.05],fill=(214,207,191)); d.ellipse([cx-S*0.02,cy-S*0.02,cx+S*0.02,cy+S*0.02],fill=(11,21,19))
    return im
def icon(size,path,pad=0.0):
    S=size*4; base=design(S)
    if pad>0:
        bg=Image.new("RGB",(S,S),(30,32,36)); inner=int(S*(1-2*pad)); bg.paste(base.resize((inner,inner),Image.LANCZOS),((S-inner)//2,(S-inner)//2)); base=bg
    base.resize((size,size),Image.LANCZOS).save(path)
icon(180,os.path.join(OUT,'apple-touch-icon.png')); icon(192,os.path.join(OUT,'icon-192.png')); icon(512,os.path.join(OUT,'icon-512.png'))
icon(512,os.path.join(OUT,'icon-maskable-512.png'),pad=0.08)
files+=['apple-touch-icon.png','icon-192.png','icon-512.png','icon-maskable-512.png']
json.dump({"name":"Pocket Retro","short_name":"Pocket Retro","description":"Retro photo, video and sound editor.","start_url":"./","scope":"./","display":"standalone",
  "background_color":"#1e2024","theme_color":"#1e2024","orientation":"portrait",
  "icons":[{"src":"icon-192.png","sizes":"192x192","type":"image/png"},{"src":"icon-512.png","sizes":"512x512","type":"image/png"},
           {"src":"icon-maskable-512.png","sizes":"512x512","type":"image/png","purpose":"maskable"}]},open(os.path.join(OUT,'manifest.webmanifest'),'w'),indent=2)
files+=['manifest.webmanifest']
cache=json.dumps(["./","index.html"]+files)
open(os.path.join(OUT,'sw.js'),'w').write(f'''/* Pocket Retro offline cache. Change VERSION when you upload new files so phones pick them up. */
const VERSION="pocket-retro-{VERSION}";
const FILES={cache};
self.addEventListener("install",e=>{{ e.waitUntil(caches.open(VERSION).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting())); }});
self.addEventListener("activate",e=>{{ e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==VERSION).map(k=>caches.delete(k)))).then(()=>self.clients.claim())); }});
self.addEventListener("fetch",e=>{{
  if(e.request.method!=="GET") return;
  const url=new URL(e.request.url); if(url.origin!==location.origin) return;
  // network first for the page itself (so updates show up), cache first for everything else
  if(e.request.mode==="navigate"){{ e.respondWith(fetch(e.request,{{cache:"no-store"}}).then(r=>{{ const c=r.clone(); caches.open(VERSION).then(x=>x.put("index.html",c)); return r; }}).catch(()=>caches.match("index.html"))); return; }}
  e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request)));
}});
''')
open(os.path.join(OUT,'README.md'),'w').write(f'''# Pocket Retro

A personal retro photo, video and sound editor that runs entirely in the browser. Nothing is uploaded: photos, videos and sounds are processed on your device.

- **Camera mode**: 2000s digicam, flip phone, webcam and toy camera looks, date stamps, viewfinder frames, a live low-res viewfinder and short clips.
- **Tape mode**: NTSC/VHS effects (a JavaScript port of the core effect from [ntsc-rs](https://github.com/valadaptive/ntsc-rs) by valadaptive, MIT licence), a CRT TV look, overlays, borders and VHS sound.

## Updating the site
1. Upload the new files to this repository (they replace the old ones).
2. In `sw.js`, change `VERSION` (for example `pocket-retro-1.0.1`) so phones fetch the new version.

## Credits
The Tape effect engine is a port of ntsc-rs. Copyright © valadaptive, MIT licence (full text in the app's Credits section).
''')
print("built", sorted(os.listdir(OUT)))
