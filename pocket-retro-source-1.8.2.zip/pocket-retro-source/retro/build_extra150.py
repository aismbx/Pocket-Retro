# ---- 1.5.0 channel logo ----
SETTINGS=rep(SETTINGS,'rating:"none", ratingPos:"tl", ratingOpacity:0.6, ratingSize:0.22, ratingTime:"all",',
 'rating:"none", ratingPos:"tl", ratingOpacity:0.6, ratingSize:0.22, ratingTime:"all",\n  logoOn:false, logoPos:"tr", logoX:0, logoY:0, logoSize:0.14, logoOpacity:0.55, logoWhite:false, logoTime:"all",')
import re as _re
_m=_re.search(r'  \{k:"seg",id:"rtime",[^\n]*\n',SETTINGS); assert _m
SETTINGS=SETTINGS[:_m.end()]+"""  {k:"head",label:"Channel logo"},
  {k:"logo",id:"logoFile",label:"Logo image",desc:"Upload your own channel logo. A PNG with a see-through background works best. It goes through the effect, so it smears like a real broadcast."},
  {k:"sw",id:"logoOn",label:"Show logo",get:()=>P.logoOn,set:v=>{P.logoOn=v; buildPanel();},pic:1,show:()=>!!LOGO.url},
  {k:"seg",id:"lpos",label:"Corner",opts:[["tl","Top left"],["tr","Top right"],["bl","Bottom left"],["br","Bottom right"]],get:()=>P.logoPos,set:v=>P.logoPos=v,pic:1,show:()=>logoShown()},
  {k:"rng",id:"lx",label:"Move left or right",min:-0.5,max:0.5,step:0.005,fmt:v=>v===0?"0":(v<0?"\\u2190 ":"\\u2192 ")+Math.round(Math.abs(v)*100)+"%",get:()=>P.logoX,set:v=>P.logoX=v,pic:1,show:()=>logoShown()},
  {k:"rng",id:"ly",label:"Move up or down",min:-0.5,max:0.5,step:0.005,fmt:v=>v===0?"0":(v>0?"\\u2191 ":"\\u2193 ")+Math.round(Math.abs(v)*100)+"%",get:()=>P.logoY,set:v=>P.logoY=v,pic:1,show:()=>logoShown(),desc:"Fine-tunes the spot, starting from the corner you picked."},
  {k:"rng",id:"lsize",label:"Size",min:0.04,max:0.6,step:0.01,fmt:pct,get:()=>P.logoSize,set:v=>P.logoSize=v,pic:1,show:()=>logoShown(),desc:"Height of the logo compared with the picture."},
  {k:"rng",id:"lop",label:"Opacity",min:0.1,max:1,step:0.01,fmt:pct,get:()=>P.logoOpacity,set:v=>P.logoOpacity=v,pic:1,show:()=>logoShown()},
  {k:"sw",id:"lwhite",label:"Make it white",get:()=>P.logoWhite,set:v=>P.logoWhite=v,pic:1,show:()=>logoShown(),desc:"Turns the logo into a white shape, the classic see-through look of 2000s channel logos."},
  {k:"seg",id:"ltime",label:"In videos, show it",opts:[["all","The whole time"],["15","First 15 seconds"],["5","First 5 seconds"]],get:()=>P.logoTime,set:v=>P.logoTime=v,pic:1,show:()=>logoShown()},
"""+SETTINGS[_m.end():]

GEOM=rep(GEOM,'  if(P.rating!=="none") drawRating(x,W,H,offsetMs||0);','  if(P.rating!=="none") drawRating(x,W,H,offsetMs||0);\n  if(P.logoOn && LOGO.img) drawLogo(x,W,H,offsetMs||0);')
GEOM=rep(GEOM,'function drawRating(x,W,H,offsetMs){','''/* ---- channel logo: the user's own image, kept in this browser (localStorage "pretro-logo") ---- */
const LOGO={url:null,img:null,white:null};
function loadLogo(url){ LOGO.url=url||null; LOGO.img=null; LOGO.white=null;
  if(url){ const i=new Image(); i.onload=()=>{ prepDirty=true; schedule(); }; i.src=url; LOGO.img=i; } }
try{ loadLogo(localStorage.getItem("pretro-logo")); }catch(e){}
function logoShown(){ return !!LOGO.url && P.logoOn; }
async function setLogo(f){
  try{ const u=URL.createObjectURL(f);
    const im=await new Promise((res,rej)=>{ const i=new Image(); i.onload=()=>res(i); i.onerror=rej; i.src=u; });
    let w=im.naturalWidth||512, h=im.naturalHeight||512; const s=Math.min(1,512/Math.max(w,h)); w=Math.max(1,Math.round(w*s)); h=Math.max(1,Math.round(h*s));
    const cv=document.createElement("canvas"); cv.width=w; cv.height=h; cv.getContext("2d").drawImage(im,0,0,w,h); URL.revokeObjectURL(u);
    const url=cv.toDataURL("image/png");
    try{ localStorage.setItem("pretro-logo",url); }catch(e){ $("note").textContent="The logo is too big to keep after you close the app. Try a smaller PNG."; }
    loadLogo(url); P.logoOn=true; buildPanel(); changed(true);
    if(!$("note").textContent.startsWith("The logo")) $("note").textContent="Logo added. Use the controls below it to place it.";
  }catch(e){ $("note").textContent="That image couldn't be opened. Try a PNG file."; }
}
function clearLogo(){ try{ localStorage.removeItem("pretro-logo"); }catch(e){} loadLogo(null); P.logoOn=false; buildPanel(); changed(true); }
function drawLogo(x,W,H,offsetMs){
  if(kind==="video" && P.logoTime!=="all" && (offsetMs/1000 - V.start) > +P.logoTime) return;
  const im=LOGO.img; if(!im||!im.complete||!im.naturalWidth) return;
  let h=Math.max(2,Math.round(H*P.logoSize)), w=Math.max(2,Math.round(h*im.naturalWidth/im.naturalHeight));
  if(w>W*0.95){ const k=W*0.95/w; w=Math.round(w*k); h=Math.round(h*k); }
  const m=Math.round(H*0.065), mx=Math.round(Math.max(m, W*0.06));
  const px=(P.logoPos[1]==="l"?mx:W-mx-w)+Math.round(P.logoX*W), py=(P.logoPos[0]==="t"?m:H-m-h)-Math.round(P.logoY*H);
  let src=im;
  if(P.logoWhite){ if(!LOGO.white||LOGO.white.src!==im){ const c=document.createElement("canvas"); c.width=im.naturalWidth; c.height=im.naturalHeight;
      const g=c.getContext("2d"); g.drawImage(im,0,0); g.globalCompositeOperation="source-in"; g.fillStyle="#fff"; g.fillRect(0,0,c.width,c.height); LOGO.white={src:im,c}; }
    src=LOGO.white.c; }
  x.save(); x.globalAlpha=P.logoOpacity; x.imageSmoothingEnabled=true; x.drawImage(src,px,py,w,h); x.restore();
}
function drawRating(x,W,H,offsetMs){''')

PANEL=rep(PANEL,'''    } else if(c.k==="sw"){''','''    } else if(c.k==="logo"){
      row.innerHTML=`<span class="lbl"></span><div class="logorow"><span class="logothumb"></span><button class="pbtn" type="button" id="c-logoPick"></button><button class="link" type="button" id="c-logoRemove">Remove</button><input type="file" accept="image/png,image/*" class="vh" tabindex="-1" aria-hidden="true" id="inLogo"></div>`;
      row.querySelector(".lbl").textContent=c.label; const th=row.querySelector(".logothumb"), pb=row.querySelector("#c-logoPick"), rm=row.querySelector("#c-logoRemove"), fi=row.querySelector("input");
      if(LOGO.url){ const im=document.createElement("img"); im.src=LOGO.url; im.alt="Your channel logo"; th.appendChild(im); } else th.textContent="None";
      pb.textContent=LOGO.url?"Replace":"Choose image"; rm.hidden=!LOGO.url;
      pb.onclick=()=>fi.click(); fi.onchange=async()=>{ const f=fi.files&&fi.files[0]; fi.value=""; if(f) await setLogo(f); };
      rm.onclick=()=>clearLogo();
    } else if(c.k==="sw"){''')
