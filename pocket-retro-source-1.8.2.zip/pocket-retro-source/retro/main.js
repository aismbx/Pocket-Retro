<script>
(function(){
"use strict";
const $=id=>document.getElementById(id);
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

/* ================= Camera mode settings ================= */
const CAMS=[
  {id:"vga",  name:"0.3MP VGA",  sub:"2003 digicam",  res:[640,480],  vres:[320,240], vfps:15, sharpen:0.9, fringe:1, vig:0.28, noise:1,   jpeg:[0.42,0.62], hi:6000, label:"VGA"},
  {id:"flip", name:"Flip phone", sub:"Camera phone",  res:[352,288],  vres:[176,144], vfps:15, sharpen:0.4, fringe:1, vig:0.35, noise:1.5, jpeg:[0.30,0.50], soft:true, tint:[-4,10,-6], sat:0.85, con:0.92, hi:3400, label:"CIF"},
  {id:"cyber",name:"Cyber 1.3MP",sub:"2005 compact",  res:[1280,960], vres:[640,480], vfps:30, sharpen:1.25,fringe:2, vig:0.18, noise:0.7, jpeg:[0.60,0.75], sat:1.25, con:1.12, tint:[4,0,6], hi:9000, label:"1.3M"},
  {id:"web",  name:"Webcam",     sub:"USB, 2004",     res:[320,240],  vres:[320,240], vfps:12, sharpen:0.3, fringe:1, vig:0.40, noise:1.8, jpeg:[0.35,0.55], soft:true, tint:[-6,0,12], sat:0.7, con:0.82, lift:20, hi:4000, label:"QVGA"},
  {id:"toy",  name:"Toy camera", sub:"Kids' digicam", res:[640,480],  vres:[320,240], vfps:12, sharpen:0.2, fringe:2, vig:0.60, noise:1.2, jpeg:[0.35,0.55], soft:true, sat:1.4, con:1.15, leak:0.6, hi:3000, label:"VGA"},
];
const CLOOKS=[
  {id:"day",  name:"Daylight",  sub:"Neutral",    gain:[1.00,1.03,0.97], con:1.12, sat:1.18, lift:4,  tint:[0,4,-2], clip:1.5},
  {id:"gold", name:"Golden '04",sub:"Warm",       gain:[1.10,1.00,0.82], con:1.05, sat:1.10, lift:14, tint:[10,2,-8], clip:1.4},
  {id:"blue", name:"Blue Hour", sub:"Cool",       gain:[0.88,0.98,1.14], con:1.10, sat:0.95, lift:10, tint:[6,-4,14], clip:1.3},
  {id:"faded",name:"Faded",     sub:"Washed out", gain:[0.98,1.06,0.94], con:0.88, sat:0.80, lift:18, tint:[-2,8,0], clip:1.2},
  {id:"party",name:"Party",     sub:"Punchy",     gain:[1.08,0.94,1.04], con:1.22, sat:1.30, lift:0,  tint:[12,-6,8], clip:1.8},
  {id:"mono", name:"Mono",      sub:"Black and white", gain:[1,1,1],   con:1.30, sat:0,    lift:6,  tint:[0,0,0],   clip:1.6},
];
function cdefaults(){ return {type:"vga", look:"day", flash:false, noise:45, mic:true, scale:1, seed:0,
  stamp:"none", stampFmt:"yy", stampTime:false, stampPos:"br", stampSize:1, frame:"none", crop:"sensor",
  cfId:"", cfFit:"stretch", cfScale:1, cfX:0, cfY:0, cfOpacity:1, cfBlend:"normal"}; }
let C=cdefaults();
const camType=()=>CAMS.find(c=>c.id===C.type)||CAMS[0];
function camParams(){ const T=camType(), L=CLOOKS.find(l=>l.id===C.look)||CLOOKS[0], tt=T.tint||[0,0,0];
  return {gain:L.gain, tint:[L.tint[0]+tt[0],L.tint[1]+tt[1],L.tint[2]+tt[2]], con:L.con*(T.con||1), sat:L.sat*(T.sat||1), lift:L.lift+(T.lift||0), clip:L.clip,
    noise:C.noise/100*38*T.noise, sharpen:T.sharpen, fringe:T.fringe, vig:T.vig, flash:C.flash, leak:T.leak||0, seed:C.seed, mono:L.sat===0}; }
function micParams(){ const T=camType(); return {on:true, preset:"mic", mix:1, vol:1, hiss:0.35, hum:0, humHz:60, drive:0.45, comp:0.85, wow:0, flutter:T.id==="toy"?0.2:0,
  width:0, drift:0, dropouts:0, clicks:0, lowCut:T.id==="cyber"?150:300, highCut:T.hi, warmth:0}; }

let M="tape", LIVE_LINES=0, liveOn=false;
const TABS={tape:[["signal","Signal"],["vhs","VHS"],["picture","Picture"],["overlay","Overlay"],["screen","Screen"],["audio","Audio"]],
            camera:[["camera","Camera"],["stamp","Stamp"],["picture","Picture"]]};
let tabT="signal", tabC="camera", lookId="";

%%SETTINGS%%

/* ================= persisted state ================= */
function remember(){ try{ localStorage.setItem("pretro",JSON.stringify({M,S,P,A,C,preset:presetId,tabT,tabC,lookId})); }catch(e){} histCommit(); }
/* ================= undo / redo ================= */
let hist=[], hIdx=-1, hTimer=null, hApplying=false;
const snapNow=()=>JSON.stringify({M,S,P,A,C,presetId});
function histCommit(now){ if(hApplying) return; clearTimeout(hTimer); const go=()=>{ const s=snapNow(); if(hist[hIdx]===s) return;
  hist=hist.slice(0,hIdx+1); hist.push(s); if(hist.length>100) hist.shift(); hIdx=hist.length-1; syncHist(); };
  if(now) go(); else hTimer=setTimeout(go,450); }
function syncHist(){ const u=document.getElementById("undoBtn"), r=document.getElementById("redoBtn"); if(!u) return; u.disabled=hIdx<=0; r.disabled=hIdx>=hist.length-1; }
function histApply(i){
  if(i<0||i>=hist.length||rendering) return; histCommit(true); if(i>=hist.length) i=hist.length-1;
  hIdx=i; const d=JSON.parse(hist[i]); hApplying=true;
  S=merge(defaults(),d.S); P=Object.assign(clone(PDEF),d.P); P.crt=Object.assign(clone(PDEF.crt),d.P.crt||{}); P.cc=Object.assign(clone(PDEF.cc),d.P.cc||{}); A=Object.assign(adefaults(),d.A); C=Object.assign(cdefaults(),d.C); presetId=d.presetId;
  if(d.M!==M) setMode(d.M,true); else { buildShelves(); buildPanel(); syncVfd(); setSaveLabel(); prepDirty=true; schedule(); }
  hApplying=false; try{ localStorage.setItem("pretro",JSON.stringify({M,S,P,A,C,preset:presetId,tabT,tabC,lookId})); }catch(e){} syncHist();
}
try{ const sv=JSON.parse(localStorage.getItem("pretro")||"null");
  if(sv){ if(sv.S) S=merge(defaults(),sv.S); if(sv.P){ P=Object.assign(clone(PDEF),sv.P); P.crt=Object.assign(clone(PDEF.crt),sv.P.crt||{}); P.cc=Object.assign(clone(PDEF.cc),sv.P.cc||{}); }
    if(sv.A) A=Object.assign(adefaults(),sv.A); if(sv.C) C=Object.assign(cdefaults(),sv.C);
    presetId=sv.preset||""; tabT=sv.tabT||"signal"; tabC=sv.tabC||"camera"; lookId=sv.lookId||""; M=sv.M==="camera"?"camera":"tape"; } }catch(e){}
let tab=M==="tape"?tabT:tabC;

%%PANEL%%

%%SHELVES%%

/* ================= source + prep ================= */
let src=null, kind="image", video=null, mediaFile=null, srcTime=Date.now(), lastBlob=null, isSample=true;
const view=$("view");
function loadImage(blob){ return new Promise((res,rej)=>{ const u=URL.createObjectURL(blob), im=new Image(); im.onload=()=>{res(im);}; im.onerror=()=>{URL.revokeObjectURL(u);rej(new Error("load"));}; im.src=u; }); }
let osdFontReady=false;
async function fontReady(){ if(osdFontReady||!document.fonts) return; try{ await Promise.race([Promise.all([document.fonts.load('40px "VT323"'),document.fonts.load('40px "VCR OSD Mono"')]), new Promise(r=>setTimeout(r,1500))]); }catch(e){} osdFontReady=true; }

%%GEOM%%

/* camera-mode geometry: the camera's own sensor size, turned to match the photo */
function camGeom(source){
  const [sw0,sh0]=dims(source), rotated=P.rot===90||P.rot===270, sw=rotated?sh0:sw0, sh=rotated?sw0:sh0, T=camType();
  let [W,H]=(kind==="video"?T.vres:T.res);
  const long=Math.max(W,H), pick={"4:3":4/3,"16:9":16/9,"1:1":1,"orig":Math.max(sw,sh)/Math.min(sw,sh)}[C.crop];
  if(pick){ W=long; H=Math.max(2,Math.round(long/pick/2)*2); }
  if(sh>sw) [W,H]=[H,W];
  const Ar=W/H; let cw=sw, ch=sh; if(sw/sh>Ar) cw=sh*Ar; else ch=sw/Ar;
  return {sw0,sh0,sw,sh,cw,ch,W,H};
}
function prepCam(source, reuse){
  const g=camGeom(source), {sw0,sh0,sw,sh,cw,ch,W,H}=g, R=reuse||{}, T=camType();
  const o=R.o||document.createElement("canvas"); if(o.width!==sw||o.height!==sh){ o.width=sw; o.height=sh; }
  const ox=o.getContext("2d"); ox.setTransform(1,0,0,1,0,0); ox.clearRect(0,0,sw,sh);
  ox.translate(sw/2,sh/2); ox.rotate(P.rot*Math.PI/180); if(P.flip) ox.scale(-1,1); ox.drawImage(source,-sw0/2,-sh0/2);
  const c=R.c||document.createElement("canvas"); if(c.width!==W||c.height!==H){ c.width=W; c.height=H; }
  const x=c.getContext("2d",{willReadFrequently:true}); x.imageSmoothingEnabled=true; x.imageSmoothingQuality="low";
  if(T.soft){ const t=R.t||document.createElement("canvas"); t.width=Math.max(2,Math.round(W*0.7)); t.height=Math.max(2,Math.round(H*0.7));
    t.getContext("2d").drawImage(o,(sw-cw)/2,(sh-ch)/2,cw,ch,0,0,t.width,t.height); x.drawImage(t,0,0,W,H); R.t=t; }
  else x.drawImage(o,(sw-cw)/2,(sh-ch)/2,cw,ch,0,0,W,H);
  if(P.bright!==0||P.contrast!==1||P.sat!==1||P.warmth!==0){
    const id=x.getImageData(0,0,W,H), d=id.data, b=P.bright*255, k=P.contrast, s=P.sat, w=P.warmth*28;
    for(let i=0;i<d.length;i+=4){ let r=d[i], gg=d[i+1], bl=d[i+2];
      r=(r-128)*k+128+b+w; gg=(gg-128)*k+128+b+w*0.15; bl=(bl-128)*k+128+b-w;
      const l=0.299*r+0.587*gg+0.114*bl; d[i]=l+(r-l)*s; d[i+1]=l+(gg-l)*s; d[i+2]=l+(bl-l)*s; }
    x.putImageData(id,0,0);
  }
  if(reuse){ reuse.o=o; reuse.c=c; }
  return {W,H,data:x.getImageData(0,0,W,H).data, orig:c};
}

/* ================= camera overlays: date stamps and frames ================= */
const SEGS={"0":"abcdef","1":"bc","2":"abged","3":"abgcd","4":"fgbc","5":"afgcd","6":"afgedc","7":"abc","8":"abcdefg","9":"abcfgd","-":"g"};
function seg7(x,str,right,bottom,h,color,glow,alignLeft){
  const w=h*0.52, t=Math.max(1.5,h*0.12), gap=h*0.2, nar=h*0.24;
  const wid=ch=>/[0-9-]/.test(ch)?w+gap:ch===" "?w*0.55:nar+gap*0.3;
  let total=0; for(const ch of str) total+=wid(ch);
  let px=alignLeft?right:right-total; const top=bottom-h;
  x.save(); x.fillStyle=color; x.shadowColor=glow; x.shadowBlur=h*0.35;
  for(const ch of str){
    const x0=px, y0=top, sk=(yy)=>x0+(bottom-yy)*0.12; // slight italic
    const R=(a,b2,cw,chh)=>{ x.beginPath(); x.moveTo(sk(b2)+a,b2); x.lineTo(sk(b2)+a+cw,b2); x.lineTo(sk(b2+chh)+a+cw,b2+chh); x.lineTo(sk(b2+chh)+a,b2+chh); x.closePath(); x.fill(); };
    if(SEGS[ch]){ const sg=SEGS[ch], hh=h/2;
      if(sg.includes("a")) R(t*0.6,y0,w-t*1.2,t); if(sg.includes("d")) R(t*0.6,y0+h-t,w-t*1.2,t); if(sg.includes("g")) R(t*0.6,y0+hh-t/2,w-t*1.2,t);
      if(sg.includes("f")) R(0,y0+t*0.6,t,hh-t*0.9); if(sg.includes("b")) R(w-t,y0+t*0.6,t,hh-t*0.9);
      if(sg.includes("e")) R(0,y0+hh+t*0.3,t,hh-t*0.9); if(sg.includes("c")) R(w-t,y0+hh+t*0.3,t,hh-t*0.9); }
    else if(ch==="'"){ R(nar*0.3,y0,t,h*0.32); }
    else if(ch==="."){ R(nar*0.3,y0+h-t,t,t); }
    else if(ch===":"){ R(nar*0.3,y0+h*0.25,t,t); R(nar*0.3,y0+h*0.68,t,t); }
    else if(ch==="/"){ x.beginPath(); x.moveTo(x0+nar,y0); x.lineTo(x0+nar+t,y0); x.lineTo(x0+t,y0+h); x.lineTo(x0,y0+h); x.fill(); }
    px+=wid(ch);
  }
  x.restore();
}
function stampText(t){
  const yy=String(t.getFullYear()).slice(2), Y=t.getFullYear(), mm=String(t.getMonth()+1).padStart(2,"0"), dd=String(t.getDate()).padStart(2,"0");
  let s = C.stampFmt==="dmy" ? `${dd} ${mm} '${yy}` : C.stampFmt==="ymd" ? `${Y}.${mm}.${dd}` : C.stampFmt==="mdy" ? `${mm}/${dd}/${Y}` : `'${yy} ${mm} ${dd}`;
  if(C.stampTime) s+=`  ${String(t.getHours()).padStart(2,"0")}:${String(t.getMinutes()).padStart(2,"0")}`;
  return s;
}
function battery(x,px,py,h,color){ const w=h*1.8; x.save(); x.strokeStyle=color; x.fillStyle=color; x.lineWidth=Math.max(1,h*0.12);
  x.strokeRect(px,py,w,h); x.fillRect(px+w,py+h*0.3,h*0.18,h*0.4); for(let i=0;i<3;i++) x.fillRect(px+h*0.18+i*(w-h*0.2)/3,py+h*0.18,(w-h*0.2)/3-h*0.12,h-h*0.36); x.restore(); }
function drawCamOverlays(x,W,H,tMs,frame){
  const t=new Date(srcTime+(kind==="video"?tMs:0)), u=Math.min(W,H), mono=`"VT323", ui-monospace, monospace`;
  // frames first, the date stamp sits on top
  if(C.frame==="view"){
    x.save(); x.strokeStyle="rgba(255,255,255,.9)"; x.lineWidth=Math.max(1,u*0.008); const m=u*0.06, L=u*0.09;
    for(const [cx,cy,sx,sy] of [[m,m,1,1],[W-m,m,-1,1],[m,H-m,1,-1],[W-m,H-m,-1,-1]]){ x.beginPath(); x.moveTo(cx,cy+sy*L); x.lineTo(cx,cy); x.lineTo(cx+sx*L,cy); x.stroke(); }
    x.strokeStyle="rgba(124,255,107,.9)"; const f=u*0.07; x.strokeRect(W/2-f,H/2-f*0.75,f*2,f*1.5);
    const fs=Math.round(u*0.075); x.font=`${fs}px ${mono}`; x.textBaseline="top"; x.fillStyle="#fff"; x.shadowColor="rgba(0,0,0,.8)"; x.shadowBlur=2;
    if(kind==="video"){ const el=Math.max(0,tMs/1000-V.start), s=`${String(Math.floor(el/60)).padStart(2,"0")}:${String(Math.floor(el%60)).padStart(2,"0")}`;
      x.fillStyle="#ff4b3a"; x.fillText("● REC",m*1.4,m*1.3); x.fillStyle="#fff"; x.fillText(s,m*1.4+fs*3.2,m*1.3); }
    else { x.textAlign="left"; x.fillText(camType().label+(C.flash?"  ϟ":""),m*1.4,m*1.3); x.textBaseline="bottom"; x.fillText(`[ ${String(counterNum()).padStart(4,"0")} ]`,m*1.4,H-m*1.3); }
    battery(x,W-m*1.4-fs*1.2,m*1.4,fs*0.62,"#fff"); x.restore();
  } else if(C.frame==="phone"){
    const bh=Math.round(H*0.09), fs=Math.round(bh*0.72); x.save(); x.fillStyle="rgba(0,0,0,.55)"; x.fillRect(0,0,W,bh); x.fillRect(0,H-bh,W,bh);
    x.fillStyle="#fff"; for(let i=0;i<5;i++){ const bw=bh*0.13, hh=bh*(0.2+i*0.13); x.fillRect(bh*0.3+i*bw*1.6,bh*0.8-hh,bw,hh); }
    x.font=`${fs}px ${mono}`; x.textBaseline="middle"; x.textAlign="center"; x.fillText(kind==="video"?"Video":"Camera",W/2,bh/2);
    battery(x,W-bh*1.4,bh*0.3,bh*0.4,"#fff");
    x.textAlign="left"; x.fillText("Options",bh*0.35,H-bh/2); x.textAlign="right"; x.fillText("Back",W-bh*0.35,H-bh/2);
    x.textAlign="center"; x.beginPath(); x.arc(W/2,H-bh/2,bh*0.28,0,Math.PI*2); x.lineWidth=Math.max(1,bh*0.08); x.strokeStyle="#fff"; x.stroke(); x.restore();
  } else if(C.frame==="info"){
    const bh=Math.round(H*0.085), fs=Math.round(bh*0.7), T=camType(); x.save(); x.fillStyle="rgba(0,0,0,.5)"; x.fillRect(0,H-bh,W,bh);
    x.fillStyle="#fff"; x.font=`${fs}px ${mono}`; x.textBaseline="middle"; x.textAlign="left";
    const [rw,rh]=kind==="video"?T.vres:T.res; x.fillText(`F2.8  1/${C.flash?60:125}  ISO100  ${rw}×${rh}${C.flash?"  ϟ":""}`,bh*0.35,H-bh/2);
    x.textAlign="right"; x.fillText(`100-${String(counterNum()).padStart(4,"0")}`,W-bh*0.35,H-bh/2); x.restore();
  }
  if(C.frame==="custom") drawCustomFrame(x,W,H);
  if(C.stamp!=="none"){
    const txt=stampText(t), h=Math.round(H*0.065*(C.stampSize||1)), mx=Math.round(W*0.05), my=Math.round(H*(C.frame==="phone"?0.13:C.frame==="info"&&C.stampPos[0]==="b"?0.13:0.055));
    const left=C.stampPos[1]==="l", top=C.stampPos[0]==="t", px=left?mx:W-mx, by=top?my+h:H-my;
    if(C.stamp==="orange") seg7(x,txt,px,by,h,"#ffb060","rgba(255,110,20,.95)",left);
    else if(C.stamp==="yellow") seg7(x,txt,px,by,h,"#ffe27a","rgba(255,190,30,.9)",left);
    else { const fs=Math.round(h*1.35); x.save(); x.font=`${fs}px ${mono}`; x.textBaseline="alphabetic"; x.textAlign=left?"left":"right";
      if(C.stamp==="white"){ x.lineWidth=Math.max(2,fs*0.12); x.strokeStyle="rgba(0,0,0,.85)"; x.strokeText(txt,px,by); x.fillStyle="#fff"; x.fillText(txt,px,by); }
      else { x.shadowColor="rgba(255,40,30,.9)"; x.shadowBlur=fs*0.3; x.fillStyle="#ff5446"; x.fillText(txt,px,by); }
      x.restore(); }
  }
}
function counterNum(){ if(curItem && curItem.num) return curItem.num; return roll.filter(r=>r.mode==="camera"&&r.type==="photo").length+1; }

/* ================= engine calls (worker when available) ================= */
let worker=null, jobId=0; const waiters=new Map();
function runOp(m){ const px=new Uint8ClampedArray(m.buf);
  if(m.op==="crt"){ const r=self.CRT.apply(px,m.W,m.H,m.P); return {id:m.id,buf:r.buf,W:r.W,H:r.H}; }
  if(m.op==="cam") self.CAM.apply(px,m.W,m.H,m.P,m.frame); else self.NTSC.apply(px,m.W,m.H,m.P,m.scale,m.frame);
  return {id:m.id,buf:px.buffer,W:m.W,H:m.H}; }
try{
  const code=$("engine").textContent+"\nconst runOp="+runOp.toString()+";\nself.onmessage=e=>{const r=runOp(e.data);self.postMessage(r,[r.buf]);};";
  worker=new Worker(URL.createObjectURL(new Blob([code],{type:"text/javascript"})));
  worker.onmessage=e=>{ const w=waiters.get(e.data.id); if(w){ waiters.delete(e.data.id); w.res(e.data); } };
  worker.onerror=()=>{ worker=null; for(const [id,w] of waiters){ waiters.delete(id); w.res(runOp(w.m2)); } };
}catch(e){ worker=null; }
function engine(op,data,W,H,Px,frame){
  const id=++jobId, scale=H/480, copy=new Uint8ClampedArray(data), msg={op,id,buf:copy.buffer,W,H,P:Px,scale,frame:frame|0};
  if(!worker) return sleep(0).then(()=>runOp(msg));
  const keep=new Uint8ClampedArray(data);
  return new Promise(res=>{ waiters.set(id,{res,m2:Object.assign({},msg,{buf:keep.buffer})}); worker.postMessage(msg,[copy.buffer]); });
}

/* ================= pipeline ================= */
%%BORDER%%
function bufToCanvas(buf,W,H,c){ if(c.width!==W||c.height!==H){ c.width=W; c.height=H; } c.getContext("2d").putImageData(new ImageData(new Uint8ClampedArray(buf),W,H),0,0); return c; }
/* blurred, darkened copy of the picture behind a vertical frame: shrink a lot, then stretch back up (works in every browser) */
const blurC=document.createElement("canvas");
function verticalBlur(c,srcC,g){
  const W=srcC.width, H=srcC.height, s=Math.max(g.Wo/W,g.Ho/H), cw=W*s, ch=H*s;
  const bw=Math.max(4,Math.round(g.Wo/22)), bh=Math.max(4,Math.round(g.Ho/22)); blurC.width=bw; blurC.height=bh;
  const b=blurC.getContext("2d"); b.imageSmoothingEnabled=true; b.imageSmoothingQuality="high";
  b.drawImage(srcC,(bw-cw/22)/2,(bh-ch/22)/2,cw/22,ch/22);
  c.save(); c.imageSmoothingEnabled=true; c.imageSmoothingQuality="high"; c.drawImage(blurC,0,0,g.Wo,g.Ho);
  c.fillStyle="rgba(0,0,0,.38)"; c.fillRect(0,0,g.Wo,g.Ho); c.restore();
}
function frameCanvas(srcC,dst){ const W=srcC.width, H=srcC.height, g=borderGeom(W,H); if(dst.width!==g.Wo||dst.height!==g.Ho){ dst.width=g.Wo; dst.height=g.Ho; }
  const c=dst.getContext("2d");
  if(P.border==="vertical" && P.vBg==="blur") verticalBlur(c,srcC,g);
  else { c.fillStyle=P.border==="vertical"&&P.vBg==="black"?"#000":(P.borderColor||"#000"); c.fillRect(0,0,g.Wo,g.Ho); }
  c.drawImage(srcC,g.sx,g.sy,g.sw,g.sh,g.x,g.y,g.w,g.h);
  g.cx=g.sx/W; g.cy=g.sy/H; g.cw=g.sw/W; g.ch=g.sh/H; return g; }
/* closed captions: CEA-608 style boxes, one per line, in the VCR OSD Mono font */
const CC_COL={white:"#f4f4f4",yellow:"#ffe94a",cyan:"#3ff0ff",green:"#4dff4d",magenta:"#ff4dff",red:"#ff4545",blue:"#5a7dff"};
function drawCaptions(x,X,Y,W,H,tMs){
  const cc=P.cc; if(!cc.on||!cc.text.trim()) return;
  if(kind==="video"){ const t=tMs/1000; if(t<cc.from || (cc.to>0 && t>cc.to)) return; }
  const lines=cc.text.split("\n").slice(0,4).map(l=>l.replace(/\s+$/,"")).filter(l=>l.length);
  if(!lines.length) return;
  const fs=Math.max(8,Math.round(H*0.052*cc.size)), lh=Math.round(fs*1.22), padX=Math.round(fs*0.45), safeX=W*0.08;
  x.save(); x.font=`${fs}px "VCR OSD Mono", "VT323", ui-monospace, monospace`; x.textBaseline="middle"; x.textAlign="left";
  const total=lines.length*lh, y0 = cc.pos==="top" ? Y+H*cc.offset : Y+H-H*cc.offset-total;
  lines.forEach((ln,i)=>{ const tw=x.measureText(ln).width, bw=tw+padX*2, cy=y0+i*lh+lh/2;
    const bx = cc.align==="left" ? X+safeX : cc.align==="right" ? X+W-safeX-bw : X+(W-bw)/2;
    if(cc.bg!=="none"){ x.fillStyle=cc.bg==="half"?"rgba(0,0,0,.55)":"#000"; x.fillRect(Math.round(bx),Math.round(cy-lh/2),Math.round(bw),lh); }
    else { x.lineWidth=Math.max(2,fs*0.14); x.strokeStyle="rgba(0,0,0,.9)"; x.lineJoin="round"; x.strokeText(ln,bx+padX,cy+fs*0.04); }
    x.fillStyle=CC_COL[cc.color]||"#fff"; x.fillText(ln,bx+padX,cy+fs*0.04); });
  x.restore();
}
function bezel(screenC,R){
  const W=screenC.width, H=screenC.height, pad=Math.round(Math.min(W,H)*0.08), b=R.bz||(R.bz=document.createElement("canvas"));
  if(b.width!==W+pad*2||b.height!==H+pad*2){ b.width=W+pad*2; b.height=H+pad*2; }
  const x=b.getContext("2d"), BW=b.width, BH=b.height, rr=(x0,y0,w,h,r)=>{ x.beginPath(); x.moveTo(x0+r,y0); x.arcTo(x0+w,y0,x0+w,y0+h,r); x.arcTo(x0+w,y0+h,x0,y0+h,r); x.arcTo(x0,y0+h,x0,y0,r); x.arcTo(x0,y0,x0+w,y0,r); x.closePath(); };
  const gr=x.createLinearGradient(0,0,0,BH); gr.addColorStop(0,"#3a3b40"); gr.addColorStop(0.5,"#222327"); gr.addColorStop(1,"#141518");
  x.fillStyle="#000"; x.fillRect(0,0,BW,BH); rr(0,0,BW,BH,pad*0.9); x.fillStyle=gr; x.fill();
  const sr=Math.min(W,H)*0.06; x.save(); rr(pad,pad,W,H,sr); x.clip(); x.drawImage(screenC,pad,pad);
  const gl=x.createLinearGradient(pad,pad,pad+W*0.7,pad+H); gl.addColorStop(0,"rgba(255,255,255,.07)"); gl.addColorStop(0.45,"rgba(255,255,255,0)"); x.fillStyle=gl; x.fillRect(pad,pad,W,H);
  x.restore(); rr(pad,pad,W,H,sr); x.lineWidth=Math.max(2,pad*0.12); x.strokeStyle="rgba(0,0,0,.85)"; x.stroke();
  return {canvas:b,pad};
}
async function crunch(c,q1,q2){
  for(const q of [q1,q2]){ const b=await new Promise(r=>c.toBlob(r,"image/jpeg",q)); if(!b) return;
    let im=null; try{ im=await createImageBitmap(b); }catch(e){ try{ im=await loadImage(b); }catch(e2){ return; } }
    c.getContext("2d").drawImage(im,0,0); if(im.close) im.close(); }
}
/* One full frame: prep -> effect -> overlays -> borders -> screen. Returns the final canvas and where the picture sits in it. */
async function produce(source,tMs,frame,R,render){
  let pr;
  if(!render && !prepDirty && R.pr && R.prMode===M) pr=R.pr;
  else { await fontReady(); pr = M==="tape" ? prep(source,tMs,R) : prepCam(source,R); if(!render){ R.pr=pr; R.prMode=M; prepDirty=false; } }
  if(render && FADE_K<1){ const d=pr.data, k=Math.max(0,FADE_K); for(let i=0;i<d.length;i+=4){ d[i]*=k; d[i+1]*=k; d[i+2]*=k; } }
  let canvas, rect;
  if(M==="tape"){
    const out=await engine("ntsc",pr.data,pr.W,pr.H,R.S||clone(S),frame);
    const fc=R.fc||(R.fc=document.createElement("canvas")); const g=framed(out.buf,pr.W,pr.H,fc); canvas=fc; rect={x:g.x,y:g.y,w:g.w,h:g.h,cx:g.cx,cy:g.cy,cw:g.cw,ch:g.ch};
    if(P.frameOn && !P.fSoft) drawTapeFrame(fc.getContext("2d"),g.x,g.y,g.w,g.h);
    if(P.cc.on && !P.cc.soft) drawCaptions(fc.getContext("2d"),g.x,g.y,g.w,g.h,tMs);
    if(P.crt.on && !LIVE_LINES){ const d=fc.getContext("2d").getImageData(0,0,fc.width,fc.height).data;
      const cr=await engine("crt",d,fc.width,fc.height,clone(P.crt),frame), cc=R.cc||(R.cc=document.createElement("canvas")); bufToCanvas(cr.buf,cr.W,cr.H,cc);
      const s=cr.W/fc.width; rect=Object.assign({},rect,{x:rect.x*s,y:rect.y*s,w:rect.w*s,h:rect.h*s}); canvas=cc;
      if(P.crt.bezel){ const bz=bezel(cc,R); canvas=bz.canvas; rect.x+=bz.pad; rect.y+=bz.pad; } }
  } else {
    const out=await engine("cam",pr.data,pr.W,pr.H,camParams(),frame);
    const dc=R.dc||(R.dc=document.createElement("canvas")); bufToCanvas(out.buf,pr.W,pr.H,dc);
    drawCamOverlays(dc.getContext("2d"),pr.W,pr.H,tMs,frame);
    const T=camType(); await crunch(dc,T.jpeg[0],T.jpeg[1]);
    let sc=dc; if(C.scale>1){ const u=R.uc||(R.uc=document.createElement("canvas")); u.width=pr.W*C.scale; u.height=pr.H*C.scale; const ux=u.getContext("2d"); ux.imageSmoothingEnabled=false; ux.drawImage(dc,0,0,u.width,u.height); sc=u; }
    const fc=R.fc||(R.fc=document.createElement("canvas")); const g=frameCanvas(sc,fc); canvas=fc; rect={x:g.x,y:g.y,w:g.w,h:g.h,cx:g.cx,cy:g.cy,cw:g.cw,ch:g.ch};
  }
  return {canvas,rect,orig:pr.orig};
}

/* ================= live preview ================= */
let busy=false, pending=false, timer=null, rendering=false, prepDirty=true, last=null;
const PR={};
function schedule(){ if(rendering||liveOn) return; clearTimeout(timer); timer=setTimeout(run,90); markStale(); }
function previewFrame(){ return kind==="video" ? Math.round(video.currentTime*V.fps) : 0; }
async function run(){
  if(!src || rendering) return;
  if(busy){ pending=true; return; }
  busy=true; pending=false; $("vfdState").textContent=M==="tape"?"TRACKING":"DEVELOP";
  try{
    const res=await produce(src, kind==="video"?video.currentTime*1000:0, previewFrame(), PR, false);
    if(!rendering) await show(res,true);
  }catch(e){ $("note").textContent="Something went wrong while processing. Try another photo or setting."; }
  busy=false; if(!rendering) $("vfdState").textContent="READY";
  if(pending) run();
}
function toBlob(c,type,q){ return new Promise(r=>c.toBlob(r,type,q)); }
async function show(res,keep){
  const c=res.canvas; last=res;
  const b=await toBlob(c,"image/jpeg",M==="camera"?0.95:0.9); if(!b) return;
  if(keep) lastBlob=b;
  const u=URL.createObjectURL(b), old=view.dataset.url; view.src=u; view.dataset.url=u; if(old) setTimeout(()=>URL.revokeObjectURL(old),500);
  $("screen").style.aspectRatio=`${c.width} / ${c.height}`;
  if(cmpOn||holding) updateOrig();
  if(keep && M==="camera" && kind==="image" && !isSample && autoKeep) camAutoKeep(b,c);
  fitScreen();
}
function changed(pic){ syncVfd(); remember(); if(pic||(P.cc.on&&P.cc.soft)) prepDirty=true; schedule(); }

/* ================= compare: hold, or a draggable before/after slider ================= */
const screen=$("screen"), origImg=$("origImg"); let holding=false, cmpOn=false, cmpX=50, origUrl=null;
let origGen=0;
function clearOrig(){ origGen++; origImg.style.visibility="hidden"; origImg.removeAttribute("src"); if(origUrl){ URL.revokeObjectURL(origUrl); origUrl=null; } }
async function updateOrig(){
  if(!last) return; const gen=++origGen; origImg.style.visibility="hidden"; const c=last.canvas, o=document.createElement("canvas"); o.width=c.width; o.height=c.height; const x=o.getContext("2d");
  x.fillStyle=M==="tape"&&P.crt.on?"#000":(P.borderColor||"#000"); x.fillRect(0,0,o.width,o.height); x.imageSmoothingEnabled=M!=="camera"||C.scale===1;
  const r=last.rect, ow=last.orig.width, oh=last.orig.height;
  x.drawImage(last.orig,(r.cx||0)*ow,(r.cy||0)*oh,(r.cw||1)*ow,(r.ch||1)*oh,r.x,r.y,r.w,r.h);
  const b=await toBlob(o,"image/jpeg",0.9); if(!b||gen!==origGen) return; const u=URL.createObjectURL(b); if(origUrl) URL.revokeObjectURL(origUrl); origUrl=u;
  origImg.onload=()=>{ if(gen===origGen) origImg.style.visibility="visible"; }; origImg.src=u;
}
/* zoom: + / - buttons, pinch, mouse wheel, double-tap; drag to look around when zoomed in */
const zoomer=$("zoomer"); let Z=1, TX=0, TY=0;
function clampPan(){ const w=screen.clientWidth, h=screen.clientHeight; TX=Math.min(0,Math.max(w-w*Z,TX)); TY=Math.min(0,Math.max(h-h*Z,TY)); }
function applyZoom(){ clampPan(); zoomer.style.transform=`translate(${TX}px,${TY}px) scale(${Z})`; screen.classList.toggle("zoomed",Z>1.001);
  screen.classList.toggle("pixels",Z>=2.5); $("zLevel").textContent=Math.round(Z*100)+"%"; $("zFit").disabled=Z<=1.001; applyCmp(); }
function zoomAt(nz,px,py){ nz=Math.max(1,Math.min(8,nz)); if(px==null){ px=screen.clientWidth/2; py=screen.clientHeight/2; }
  TX=px-(px-TX)*(nz/Z); TY=py-(py-TY)*(nz/Z); Z=nz; applyZoom(); }
function resetZoom(){ Z=1; TX=0; TY=0; applyZoom(); }
$("zIn").onclick=e=>{ e.stopPropagation(); zoomAt(Z*1.5); };
$("zOut").onclick=e=>{ e.stopPropagation(); zoomAt(Z/1.5); };
$("zFit").onclick=e=>{ e.stopPropagation(); resetZoom(); };
["pointerdown","pointerup","dblclick"].forEach(ev=>$("zbtns").addEventListener(ev,e=>e.stopPropagation()));
screen.addEventListener("wheel",e=>{ e.preventDefault(); const r=screen.getBoundingClientRect(); zoomAt(Z*Math.exp(-e.deltaY*0.0022),e.clientX-r.left,e.clientY-r.top); },{passive:false});
screen.addEventListener("dblclick",e=>{ if(cmpOn) return; const r=screen.getBoundingClientRect(); if(Z>1.001) resetZoom(); else zoomAt(2.5,e.clientX-r.left,e.clientY-r.top); });
function applyCmp(){ origImg.hidden=!(cmpOn||holding); $("divider").hidden=!cmpOn; $("badgeL").hidden=!(cmpOn||holding);
  const w=screen.clientWidth||1, ex=((cmpX/100*w)-TX)/Z/w*100;
  origImg.style.clipPath = cmpOn ? `inset(0 ${Math.max(0,Math.min(100,100-ex))}% 0 0)` : "none"; $("divider").style.left=cmpX+"%"; $("cmpBtn").setAttribute("aria-pressed",String(cmpOn)); }
$("cmpBtn").onclick=()=>{ cmpOn=!cmpOn; if(cmpOn) updateOrig(); applyCmp(); };
let holdT=null, dragging=false;
function setX(e){ const r=screen.getBoundingClientRect(); cmpX=Math.max(0,Math.min(100,(e.clientX-r.left)/r.width*100)); applyCmp(); }
for(const im of [view,origImg]){ im.draggable=false; im.addEventListener("dragstart",e=>e.preventDefault()); }
const ptrs=new Map(); let pinch=null, pan=null;
const pdist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
screen.addEventListener("pointerdown",e=>{ if(rendering) return; ptrs.set(e.pointerId,{x:e.clientX,y:e.clientY}); try{ screen.setPointerCapture(e.pointerId); }catch(_){}
  if(ptrs.size===2){ clearTimeout(holdT); dragging=false; pan=null; const [a,b]=[...ptrs.values()], r=screen.getBoundingClientRect(); pinch={d:pdist(a,b)||1,z:Z,mx:(a.x+b.x)/2-r.left,my:(a.y+b.y)/2-r.top}; return; }
  if(cmpOn){ e.preventDefault(); dragging=true; setX(e); return; }
  if(Z>1.001){ pan={x:e.clientX,y:e.clientY,tx:TX,ty:TY}; return; }
  holdT=setTimeout(async()=>{ holding=true; await updateOrig(); applyCmp(); },140); });
screen.addEventListener("pointermove",e=>{ if(!ptrs.has(e.pointerId)) return; ptrs.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(pinch && ptrs.size>=2){ const [a,b]=[...ptrs.values()]; clearTimeout(holdT); zoomAt(pinch.z*pdist(a,b)/pinch.d,pinch.mx,pinch.my); return; }
  if(dragging){ setX(e); return; }
  if(pan){ TX=pan.tx+(e.clientX-pan.x); TY=pan.ty+(e.clientY-pan.y); applyZoom(); } });
screen.addEventListener("touchmove",e=>{ if(cmpOn||Z>1.001||e.touches.length>1) e.preventDefault(); },{passive:false});
["pointerup","pointercancel"].forEach(ev=>screen.addEventListener(ev,e=>{ ptrs.delete(e.pointerId); if(ptrs.size<2) pinch=null; if(!ptrs.size){ pan=null; dragging=false; }
  clearTimeout(holdT); if(holding){ holding=false; applyCmp(); } }));
screen.addEventListener("contextmenu",e=>{ if(holding||cmpOn) e.preventDefault(); });

/* ================= video + sound-only state ================= */
const V={fps:30,start:0,end:0,dur:0};
/* fades: sound and picture, separate or linked; kept in this browser */
const FDEF={aIn:0,aOut:0,vIn:0,vOut:0,shape:"smooth",link:false};
let F=Object.assign({},FDEF); try{ F=Object.assign({},FDEF,JSON.parse(localStorage.getItem("pretro-fades")||"{}")); }catch(e){}
function saveFades(){ try{ localStorage.setItem("pretro-fades",JSON.stringify(F)); }catch(e){} }
const fadeCurve=x=>{ x=Math.max(0,Math.min(1,x)); return F.shape==="straight"?x:0.5-0.5*Math.cos(Math.PI*x); };
function fadeGain(t,total,fin,fout){ let g=1; if(fin>0&&t<fin) g*=fadeCurve(t/fin); if(fout>0&&t>total-fout) g*=fadeCurve((total-t)/fout); return g; }
function soundFades(){ return kind==="image"?{in:0,out:0}:{in:F.aIn,out:F.aOut}; }
function pictureFades(){ if(kind==="audio") return {in:0,out:0}; return (F.link&&kind==="video")?{in:F.aIn,out:F.aOut}:{in:F.vIn,out:F.vOut}; }
let FADE_K=1;
let result=null, resultKey="", cancelReq=false;
const fmtT=t=>{ t=Math.max(0,t); const m=Math.floor(t/60), s=t-m*60; return `${m}:${s<10?"0":""}${s.toFixed(1)}`; };
const keyNow=()=>JSON.stringify([M,S,P,A,C,V.fps,V.start,V.end,F]);
function markStale(){ if(kind!=="video"&&kind!=="audio") return; if(result && keyNow()!==resultKey) setSaveLabel(); }
function setSaveLabel(){
  const fresh=result && keyNow()===resultKey;
  $("saveBtn").textContent = kind==="video" ? (fresh?"Save video":"Render video") : kind==="audio" ? (fresh?"Save sound":"Render sound") : isSample?"Save sample photo":"Save photo";
  $("keepBtn").hidden = kind!=="image";
  $("svBox").hidden = kind!=="image"; placeFades();
  $("liveBtns").hidden = kind!=="video";
  if(kind==="video") $("vInfo").textContent = `${Math.max(1,Math.round((V.end-V.start)*V.fps))} frames${M==="camera"?` at ${camType().vres.join("×")}`:""}. Each frame goes through the full effect, so expect roughly 2 to 5 frames a second.`;
  if(kind==="audio") $("vInfo").textContent = `Sound only · ${fmtT(V.end-V.start)} selected. The Audio tab controls how it sounds.`;
}
function seek(v,t){ return new Promise(res=>{ let done=false; const fin=()=>{ if(done) return; done=true; v.removeEventListener("seeked",fin); res(); };
  v.addEventListener("seeked",fin); try{ v.currentTime=Math.min(Math.max(0,t),Math.max(0,v.duration-0.001)); }catch(e){ fin(); } setTimeout(fin,4000); }); }
function curPos(){ return kind==="video" ? video.currentTime : +$("vPos").value||0; }
function syncVideoUi(){
  for(const [id,val] of [["vPos",curPos()],["vStart",V.start],["vEnd",V.end]]){ $(id).max=V.dur; $(id).value=val; $(id+"V").textContent=fmtT(val); }
  $("vFpsRow").hidden=kind!=="video";
  $("vFps").querySelectorAll("button").forEach(b=>b.setAttribute("aria-pressed",String(+b.dataset.f===V.fps)));
  setSaveLabel();
}
let scrubT=null;
$("vPos").addEventListener("input",e=>{ const t=+e.target.value; $("vPosV").textContent=fmtT(t); if(kind!=="video") return; clearTimeout(scrubT); scrubT=setTimeout(async()=>{ await seek(video,t); prepDirty=true; schedule(); },60); });
$("vStart").addEventListener("input",e=>{ V.start=Math.min(+e.target.value, V.end-0.1); e.target.value=V.start; $("vStartV").textContent=fmtT(V.start); $("vPos").value=V.start; $("vPosV").textContent=fmtT(V.start);
  if(kind==="video"){ clearTimeout(scrubT); scrubT=setTimeout(async()=>{ await seek(video,V.start); prepDirty=true; schedule(); },80); } setSaveLabel(); markStale(); });
$("vEnd").addEventListener("input",e=>{ V.end=Math.max(+e.target.value, V.start+0.1); e.target.value=V.end; $("vEndV").textContent=fmtT(V.end); setSaveLabel(); markStale(); });
$("vFps").addEventListener("click",e=>{ const b=e.target.closest("button"); if(!b) return; V.fps=+b.dataset.f; syncVideoUi(); schedule(); });

function clearResult(){ if(result&&result.url) URL.revokeObjectURL(result.url); result=null; resultKey=""; $("result").hidden=true; $("resultAudio").hidden=true; }
/* open a video so its frames can be drawn. iOS (especially the home-screen app) often won't load anything until playback
   is asked for, and play() itself can hang, so: keep the element in the page, nudge it with a muted play(), and never wait forever */
async function openVideo(blob,label){
  const v=document.createElement("video"); v.muted=true; v.defaultMuted=true; v.playsInline=true;
  v.setAttribute("playsinline",""); v.setAttribute("webkit-playsinline",""); v.setAttribute("muted",""); v.preload="auto";
  v.style.cssText="position:fixed;left:0;top:0;width:2px;height:2px;opacity:0.01;pointer-events:none;z-index:-1";
  document.body.appendChild(v);
  const u=URL.createObjectURL(blob); v.src=u;
  try{
    await new Promise((res,rej)=>{ let done=false; const fin=e=>{ if(done) return; done=true; clearInterval(tick); e?rej(e):res(); };
      v.addEventListener("loadeddata",()=>fin(),{once:true}); v.addEventListener("canplay",()=>fin(),{once:true});
      v.addEventListener("error",()=>fin(new Error("video")),{once:true});
      const t0=Date.now(), tick=setInterval(()=>{ if(v.readyState>=2) fin(); else if(Date.now()-t0>30000) fin(new Error("timeout")); },250);
      try{ v.load(); }catch(e){}
      try{ const p=v.play(); if(p&&p.then) p.then(()=>{ v.pause(); }).catch(()=>{}); }catch(e){} });
    await Promise.race([(async()=>{ try{ await v.play(); }catch(e){} })(), sleep(2500)]); try{ v.pause(); }catch(e){}
    if(!v.videoWidth) await seek(v,0.05);
    if(!v.videoWidth) throw new Error("no frames");
    return v;
  }catch(e){ try{ v.remove(); }catch(_){} URL.revokeObjectURL(u); throw e; }
}
async function loadVideo(f){
  $("note").textContent="Opening the video…";
  const v=await openVideo(f);
  $("note").textContent="";
  if(video && video!==v){ try{ video.pause(); video.remove(); }catch(e){} }
  if(video && video.src) URL.revokeObjectURL(video.src);
  video=v; mediaFile=f; src=v; kind="video"; isSample=false;
  V.dur=isFinite(v.duration)?v.duration:0; V.start=0; V.end=V.dur; clearResult();
  if(M==="camera") V.fps=camType().vfps;
  await seek(v,0);
  $("vbox").hidden=false; $("badgeR").hidden=false; $("badgeR").textContent="VIDEO";
  syncVideoUi();
}
async function loadAudio(f){
  mediaFile=f; const buf=await getDecoded(); if(!buf) throw new Error("audio");
  kind="audio"; isSample=false; V.dur=buf.duration; V.start=0; V.end=buf.duration; clearResult();
  src=cassetteArt(f.name, buf);
  $("vbox").hidden=false; $("badgeR").hidden=false; $("badgeR").textContent="SOUND"; syncVideoUi();
}
/* a cassette card with the track name and its waveform, shown (and processed) on screen for sound-only files */
function cassetteArt(name,buf){
  const c=document.createElement("canvas"); c.width=1280; c.height=960; const x=c.getContext("2d");
  const bg=x.createLinearGradient(0,0,0,960); bg.addColorStop(0,"#1b2a6b"); bg.addColorStop(1,"#0a0f2a"); x.fillStyle=bg; x.fillRect(0,0,1280,960);
  x.fillStyle="#26272c"; x.beginPath(); x.roundRect?x.roundRect(140,170,1000,620,40):x.rect(140,170,1000,620); x.fill();
  x.fillStyle="#f1e6c8"; x.fillRect(200,220,880,330); x.fillStyle="#e2453c"; x.fillRect(200,220,880,46); x.fillStyle="#2f6fd6"; x.fillRect(200,266,880,18);
  x.fillStyle="#1a1a1a"; x.font="bold 54px Arial, sans-serif"; x.textAlign="left"; x.fillText((name||"Sound").replace(/\.[^.]+$/,"").slice(0,26),230,350);
  x.font="34px Arial, sans-serif"; x.fillText(`SIDE A · ${fmtT(buf.duration)}`,230,405);
  const ch=buf.getChannelData(0), N=760, step=Math.max(1,Math.floor(ch.length/N)); x.fillStyle="#2b2b2b";
  for(let i=0;i<N;i++){ let mn=0,mx=0; for(let k=i*step;k<Math.min(ch.length,(i+1)*step);k+=8){ const v=ch[k]; if(v<mn) mn=v; if(v>mx) mx=v; } x.fillRect(260+i,490-mx*55,1,Math.max(1,(mx-mn)*55)); }
  x.fillStyle="#111"; x.fillRect(380,600,520,130); for(const cx of [480,800]){ x.fillStyle="#d9d9d9"; x.beginPath(); x.arc(cx,665,52,0,Math.PI*2); x.fill(); x.fillStyle="#111"; x.beginPath(); x.arc(cx,665,22,0,Math.PI*2); x.fill(); }
  return c;
}

%%VIDEOCFG%%

/* ================= render a video ================= */
async function renderVideo(){
  stopLive();
  if(typeof VideoEncoder!=="function" || typeof VideoFrame!=="function"){ $("note").textContent="Video export needs a newer browser: iOS 16.4 or later, or a recent Chrome, Edge or Safari."; return; }
  if(typeof Mp4Muxer==="undefined"){ $("note").textContent="The video file writer didn't load. Check your connection and reload the page."; return; }
  const fps=V.fps, n=Math.max(1,Math.round((V.end-V.start)*fps));
  let outFile=null;
  if(canStreamSave() && (V.end-V.start)>=STREAM_SAVE_MIN){
    try{ const h=await window.showSaveFilePicker({suggestedName:`pocket-retro_${stamp()}.mp4`,types:[{description:"MP4 video",accept:{"video/mp4":[".mp4"]}}]}); outFile={h,w:await h.createWritable()}; }
    catch(e){ if(e&&e.name==="AbortError"){ $("note").textContent="Render cancelled. Long videos are saved straight to your computer, so choose where to save first."; return; } outFile=null; }
  }
  rendering=true; cancelReq=false; $("prog").hidden=false; clearResult(); $("note").textContent="";
  $("progTxt").textContent="Getting ready…"; $("progBar").style.width="0%";
  let lock=null; try{ lock=await navigator.wakeLock?.request("screen"); }catch(e){}
  const R={S:clone(S)}, firstT=V.start;
  await seek(video,firstT); let first=await produce(video,firstT*1000,0,R,true);
  const Wo=first.canvas.width+(first.canvas.width&1), Ho=first.canvas.height+(first.canvas.height&1);
  const vpick=await pickVideoConfig(Wo,Ho,fps), vcfg=vpick&&vpick.cfg;
  if(!vcfg){ $("note").textContent=`This device can't encode ${Wo}×${Ho} video. Try fewer scan lines, turn off the CRT look or the border, or use a smaller export size.`; endRender(lock); return; }
  $("progTxt").textContent="Reading the audio…"; if($("soundInfo")) $("soundInfo").hidden=true;
  const fx = M==="tape" ? (A.on?A:null) : (C.mic?micParams():null);
  const aud=await pickAudioStream();
  let err=null, thumb=null;
  try{
    const muxer=new Mp4Muxer.Muxer({ target: outFile?new Mp4Muxer.FileSystemWritableFileStreamTarget(outFile.w):new Mp4Muxer.ArrayBufferTarget(), video:{codec:vpick.mux,width:Wo,height:Ho,frameRate:fps},
      audio: aud.reader ? {codec:aud.mux,sampleRate:aud.sr,numberOfChannels:aud.ch} : undefined, fastStart: outFile?false:"in-memory", firstTimestampBehavior:"offset" });
    const venc=new VideoEncoder({output:(c,m)=>muxer.addVideoChunk(c,m), error:e=>{err=e;}}); venc.configure(vcfg);
    const fc=document.createElement("canvas"); fc.width=Wo; fc.height=Ho; const fx2=fc.getContext("2d"), t0=performance.now();
    thumb=await thumbOf(first.canvas);
    const pf=pictureFades(), total=n/fps;
    for(let k=0;k<n;k++){
      if(cancelReq||err) break;
      const t=V.start+k/fps; let res=first;
      FADE_K=Math.min(fadeGain(k/fps,total,pf.in,0),fadeGain((k+1)/fps,total,0,pf.out));
      if(k>0 || FADE_K<1){ await seek(video,t); res=await produce(video,t*1000,k,R,true); }
      fx2.fillStyle="#000"; fx2.fillRect(0,0,Wo,Ho); fx2.drawImage(res.canvas,0,0);
      const frame=new VideoFrame(fc,{timestamp:Math.round(k*1e6/fps),duration:Math.round(1e6/fps)});
      venc.encode(frame,{keyFrame:k%(fps*2)===0}); frame.close();
      while(venc.encodeQueueSize>3) await sleep(4);
      progress(k+1,n,t0); if(k%12===0) await show(res,false);
    }
    if(err) throw err;
    await venc.flush(); venc.close();
    if(cancelReq){ $("note").textContent="Render cancelled."; if(outFile){ try{ await outFile.w.abort(); }catch(e){} outFile=null; } }
    else {
      let audioNote="";
      if(aud.reader){ $("progTxt").textContent="Adding the sound…"; aud.fade=soundFades();
        await encodeAudioInto(muxer,aud,V.start,n/fps,fx,p=>{ $("progTxt").textContent=`Adding the sound… ${Math.round(p*100)}%`; $("progBar").style.width=(p*100).toFixed(1)+"%"; });
        if(aud.mux==="opus") audioNote=" The sound is saved as Opus, which plays in Chrome and VLC but not in QuickTime or Photos. Rendering in Safari gives sound that plays everywhere."; }
      else audioNote=audioWhyNote(aud);
      soundReport(aud);
      muxer.finalize();
      if(outFile){ await outFile.w.close(); const file=await outFile.h.getFile(); outFile=null;
        result={blob:file,url:URL.createObjectURL(file),ext:"mp4",onDisk:true}; resultKey=keyNow();
        $("result").src=result.url; $("result").hidden=false;
        $("note").textContent=`Video saved as ${file.name}: ${n} frames, ${(file.size/1048576).toFixed(1)} MB.${audioNote} Long videos go straight to your computer, so this one isn't added to the roll.`;
      } else {
      const blob=new Blob([muxer.target.buffer],{type:"video/mp4"});
      result={blob,url:URL.createObjectURL(blob),ext:"mp4"}; resultKey=keyNow();
      $("result").src=result.url; $("result").hidden=false;
      await addToRoll({type:"video",blob,thumb,ext:"mp4"});
      $("note").textContent=`Video ready: ${n} frames, ${(blob.size/1048576).toFixed(1)} MB, and added to your roll.${audioNote} Tap Save video to keep it on your phone.`;
      }
    }
  }catch(e){ if(outFile){ try{ outFile.w.abort(); }catch(_){} } $("note").textContent="The video couldn't be rendered on this device. Try fewer scan lines, a shorter clip, a lower frame rate or no CRT look."; }
  endRender(lock);
}
function endRender(lock){ FADE_K=1; titleDone(cancelReq?"Cancelled":"Video ready"); try{ lock&&lock.release(); }catch(e){} rendering=false; $("prog").hidden=true; $("vfdState").textContent="READY";
  setSaveLabel(); if(kind==="video") seek(video,+$("vPos").value).then(()=>{ prepDirty=true; schedule(); }); }
/* AAC setup bytes (AudioSpecificConfig). Safari's AudioEncoder hands back broken ones (WebKit bug 302253), which makes the
   sound track silent on iPhone, so we always write our own: AAC-LC, the real sample rate and channel count. */
function aacConfig(sr,ch){
  const FI=[96000,88200,64000,48000,44100,32000,24000,22050,16000,12000,11025,8000,7350].indexOf(sr), bits=[];
  const put=(v,n)=>{ for(let i=n-1;i>=0;i--) bits.push((v>>>i)&1); };
  put(2,5); if(FI>=0) put(FI,4); else { put(15,4); put(sr,24); } put(ch,4);
  while(bits.length%8) bits.push(0);
  const out=new Uint8Array(bits.length/8); bits.forEach((b,i)=>{ out[i>>3]|=b<<(7-(i&7)); }); return out;
}
function aacChunk(c){ /* drop an ADTS header if an encoder adds one; MP4 wants raw AAC frames */
  const d=new Uint8Array(c.byteLength); c.copyTo(d);
  if(d.length>7 && d[0]===0xFF && (d[1]&0xF6)===0xF0){ const h=(d[1]&1)?7:9;
    return new EncodedAudioChunk({type:c.type,timestamp:c.timestamp,duration:c.duration??undefined,data:d.subarray(h)}); }
  return c;
}
async function encodeAudioInto(muxer,aud,start,dur,fx,prog){
  const isAac=aud.mux==="aac", asc=isAac?aacConfig(aud.cfg.sampleRate,aud.cfg.numberOfChannels):null;
  const out=(c,m)=>{ if(isAac){ c=aacChunk(c); if(m&&m.decoderConfig) m={...m,decoderConfig:{...m.decoderConfig,description:asc}}; } muxer.addAudioChunk(c,m); };
  let err=null; const aenc=new AudioEncoder({output:out, error:e=>{err=e;}}); aenc.configure(isAac?{...aud.cfg,aac:{format:"aac"}}:aud.cfg);
  const reader=aud.reader||bufReader(aud.buf,aud.ch), CH=aud.ch, sr=reader.sr, fd=aud.fade; let sent=0, peak=0;
  const emit=async(chans,L)=>{ for(let pos=0;pos<L;pos+=4096){ const len=Math.min(4096,L-pos), data=new Float32Array(len*CH);
      for(let c=0;c<CH;c++) data.set(chans[Math.min(c,chans.length-1)].subarray(pos,pos+len), c*len);
      if(fd && (fd.in>0||fd.out>0)){ const t0=sent/sr, t1=(sent+len)/sr;
        if((fd.in>0&&t0<fd.in)||(fd.out>0&&t1>dur-fd.out)) for(let j=0;j<len;j++){ const g=fadeGain((sent+j)/sr,dur,fd.in,fd.out); if(g!==1) for(let c=0;c<CH;c++) data[c*len+j]*=g; } }
      const ad=new AudioData({format:"f32-planar",sampleRate:sr,numberOfFrames:len,numberOfChannels:CH,timestamp:Math.round(sent/sr*1e6),data});
      for(let j=0;j<data.length;j+=3){ const q=data[j]<0?-data[j]:data[j]; if(q>peak) peak=q; }
      sent+=len; aenc.encode(ad); ad.close(); while(aenc.encodeQueueSize>8) await sleep(2); if(err) throw err; } };
  if(fx) await processChunked(reader,start,dur,fx,CH,emit,prog);
  else { const total=Math.round(dur*sr), step=30*sr;
    for(let s0=0;s0<total;s0+=step){ const L=Math.min(step,total-s0); await emit(await reader.read(start+s0/sr,start+(s0+L)/sr),L); if(prog) prog((s0+L)/total); } }
  await aenc.flush(); aenc.close(); if(err) throw err;
  aud.peak=peak;
}

/* ================= 1.5.1: streamed sound for long and large clips =================
   A "reader" hands out the clip's sound a piece at a time: read(a,b) gives exactly round((b-a)*sr) samples per channel
   for source seconds a..b (silence outside the clip). MP4/MOV files are read straight from disk with only the sound
   samples fetched and decoded, so a multi-gigabyte 4K file never has to fit in memory. Other files fall back to the
   browser's whole-file decoder when they are small enough. */
const DECODE_ALL_LIMIT=700*1048576;
function bufReader(ab,CH){
  const sr=ab.sampleRate, n=ab.numberOfChannels, ch=CH||Math.min(2,n);
  return { sr, ch, async read(a,b){ const L=Math.max(0,Math.round((b-a)*sr)), s=Math.round(a*sr), out=[];
    for(let c=0;c<ch;c++){ const o=new Float32Array(L), src=ab.getChannelData(Math.min(c,n-1)), i0=Math.max(0,-s), i1=Math.min(L,src.length-s);
      if(i1>i0) o.set(src.subarray(s+i0,s+i1),i0); out.push(o); } return out; } };
}
async function fileBytes(f,a,b){ return new Uint8Array(await f.slice(a,b).arrayBuffer()); }
function mp4Kids(u8,s,e){ const dv=new DataView(u8.buffer,u8.byteOffset,u8.byteLength), out=[]; let p=s;
  while(p+8<=e){ let sz=dv.getUint32(p), hl=8; const type=String.fromCharCode(u8[p+4],u8[p+5],u8[p+6],u8[p+7]);
    if(sz===1){ sz=Number(dv.getBigUint64(p+8)); hl=16; } else if(sz===0) sz=e-p;
    if(sz<hl||p+sz>e) break; out.push({type,s:p+hl,e:p+sz}); p+=sz; }
  return out; }
const mp4Kid=(u8,b,t)=>b&&mp4Kids(u8,b.s,b.e).find(k=>k.type===t);
async function mp4AudioReader(file){
  // 1. find the moov box at the top level (it can be at the start or the end of the file)
  let off=0, moov=null; const size=file.size;
  for(let guard=0; off+8<=size && guard<4000; guard++){
    const h=await fileBytes(file,off,Math.min(size,off+16)), dv=new DataView(h.buffer);
    let sz=dv.getUint32(0), hl=8; const type=String.fromCharCode(h[4],h[5],h[6],h[7]);
    if(guard===0 && type!=="ftyp" && type!=="wide" && type!=="mdat" && type!=="moov" && type!=="free" && type!=="skip") return {why:"not-mp4"};
    if(sz===1){ sz=Number(dv.getBigUint64(8)); hl=16; } else if(sz===0) sz=size-off;
    if(sz<hl) break;
    if(type==="moov"){ if(sz>256*1048576) return {why:"not-mp4"}; moov=await fileBytes(file,off,off+sz); moov={u8:moov,box:{s:hl,e:sz}}; break; }
    off+=sz;
  }
  if(!moov) return {why:"not-mp4"};
  const u8=moov.u8, dv=new DataView(u8.buffer,u8.byteOffset,u8.byteLength);
  const mvhd=mp4Kid(u8,moov.box,"mvhd"); const movieTs=mvhd?(u8[mvhd.s]===1?dv.getUint32(mvhd.s+20):dv.getUint32(mvhd.s+12)):1000;
  const isSoun=trak=>{ const h=mp4Kid(u8,mp4Kid(u8,trak,"mdia"),"hdlr"); return !!h && String.fromCharCode(u8[h.s+8],u8[h.s+9],u8[h.s+10],u8[h.s+11])==="soun"; };
  const souns=mp4Kids(u8,moov.box.s,moov.box.e).filter(k=>k.type==="trak"&&isSoun(k));
  let last={why:"no-audio"};
  for(const trak of souns){ const r=await (async()=>{
    const mdia=mp4Kid(u8,trak,"mdia");
    const mdhd=mp4Kid(u8,mdia,"mdhd"), ts=u8[mdhd.s]===1?dv.getUint32(mdhd.s+20):dv.getUint32(mdhd.s+12);
    const stbl=mp4Kid(u8,mp4Kid(u8,mdia,"minf"),"stbl"), stsd=mp4Kid(u8,stbl,"stsd"); if(!stsd) return {why:"codec",fmt:"?"};
    // sample description: AAC ("mp4a") with its esds, possibly inside a QuickTime "wave" box
    const E=stsd.s+8, fmt=String.fromCharCode(u8[E+4],u8[E+5],u8[E+6],u8[E+7]);
    if(fmt!=="mp4a") return {why:"codec",fmt};
    const ver=dv.getUint16(E+16), entCh=dv.getUint16(E+24), entSr=dv.getUint16(E+32), entEnd=E+dv.getUint32(E);
    let kidsAt=E+36+(ver===1?16:ver===2?36:0), esds=null;
    const look=(s,e,d)=>{ for(const k of mp4Kids(u8,s,e)){ if(k.type==="esds") return k; if(k.type==="wave"&&d<3){ const r=look(k.s,k.e,d+1); if(r) return r; } } return null; };
    esds=look(kidsAt,entEnd,0);
    if(!esds){ for(let p=E+8;p<entEnd-4;p++) if(u8[p]===0x65&&u8[p+1]===0x73&&u8[p+2]===0x64&&u8[p+3]===0x73){ esds={s:p+4,e:p-4+dv.getUint32(p-4)}; break; } }
    if(!esds) return {why:"codec",fmt};
    let q=esds.s+4, oti=0, asc=null;
    const desc=()=>{ const tag=u8[q++]; let len=0; for(let i=0;i<4;i++){ const b=u8[q++]; len=(len<<7)|(b&0x7f); if(!(b&0x80)) break; } return {tag,len}; };
    let d=desc(); if(d.tag===3){ q+=2; const f=u8[q++]; if(f&0x80) q+=2; if(f&0x40) q+=1+u8[q]; if(f&0x20) q+=2; d=desc(); }
    if(d.tag===4){ oti=u8[q]; q+=13; d=desc(); if(d.tag===5) asc=u8.slice(q,q+d.len); }
    let codec;
    if(oti===0x6B||oti===0x69) codec="mp3";
    else if(oti===0x40||oti===0x66||oti===0x67||oti===0x68){ if(!asc) return {why:"codec",fmt}; let aot=asc[0]>>3; if(aot===31) aot=32+(((asc[0]&7)<<3)|(asc[1]>>5)); codec="mp4a.40."+aot; }
    else return {why:"codec",fmt};
    // sample tables -> per-sample file offset, size and presentation time
    const tbl=t=>mp4Kid(u8,stbl,t);
    const stts=tbl("stts"), stsc=tbl("stsc"), stsz=tbl("stsz"), stco=tbl("stco"), co64=tbl("co64");
    if(!stts||!stsc||!stsz||!(stco||co64)) return {why:"codec",fmt};
    const fixed=dv.getUint32(stsz.s+4), count=dv.getUint32(stsz.s+8);
    const sizes=new Uint32Array(count); for(let i=0;i<count;i++) sizes[i]=fixed||dv.getUint32(stsz.s+12+i*4);
    const nChunks=stco?dv.getUint32(stco.s+4):dv.getUint32(co64.s+4), chunkOff=new Float64Array(nChunks);
    for(let i=0;i<nChunks;i++) chunkOff[i]=stco?dv.getUint32(stco.s+8+i*4):Number(dv.getBigUint64(co64.s+8+i*8));
    const offs=new Float64Array(count), nsc=dv.getUint32(stsc.s+4); let si=0;
    for(let k=0;k<nsc;k++){ const first=dv.getUint32(stsc.s+8+k*12)-1, per=dv.getUint32(stsc.s+12+k*12), last=k+1<nsc?dv.getUint32(stsc.s+8+(k+1)*12)-1:nChunks;
      for(let c=first;c<last&&si<count;c++){ let o=chunkOff[c]; for(let j=0;j<per&&si<count;j++){ offs[si]=o; o+=sizes[si]; si++; } } }
    // edit list: an empty edit delays the track; a media_time skips encoder priming
    let shift=0, mediaStart=0; const elst=mp4Kid(u8,mp4Kid(u8,trak,"edts"),"elst");
    if(elst){ const v=u8[elst.s], n=dv.getUint32(elst.s+4); let p=elst.s+8;
      for(let k=0;k<n;k++){ const segDur=v===1?Number(dv.getBigUint64(p)):dv.getUint32(p), mt=v===1?Number(dv.getBigInt64(p+8)):dv.getInt32(p+4); p+=v===1?20:12;
        if(mt===-1) shift+=segDur/movieTs; else { mediaStart=mt/ts; break; } } }
    const pts=new Float64Array(count), durs=new Float64Array(count), ne=dv.getUint32(stts.s+4); let t=0, k2=0;
    for(let k=0;k<ne;k++){ const cnt=dv.getUint32(stts.s+8+k*8), dl=dv.getUint32(stts.s+12+k*8); for(let j=0;j<cnt&&k2<count;j++){ pts[k2]=t/ts-mediaStart+shift; durs[k2]=dl/ts; t+=dl; k2++; } }
    if(!count) return {why:"no-audio"};
    // find the decoded sample rate and channel count (HE-AAC doubles the rate) by decoding the first few frames
    if(typeof AudioDecoder!=="function") return {why:"no-decoder"};
    const ai=ascInfo(asc);
    const cfg={codec,sampleRate:(ai&&ai.sr)||(ver===0&&entSr)||48000,numberOfChannels:(ai&&ai.ch)||(ver===0&&entCh)||2}; if(asc&&codec.startsWith("mp4a")) cfg.description=asc;
    try{ const ok=await AudioDecoder.isConfigSupported(cfg); if(!ok.supported) return {why:"codec",fmt:codec}; }catch(e){ return {why:"codec",fmt:codec}; }
    const decodeRange=async(i0,i1,onData)=>{
      let err=null; const dec=new AudioDecoder({output:ad=>{ try{ onData(ad); }finally{ ad.close(); } }, error:e=>{err=e;}}); dec.configure(cfg);
      // fetch contiguous runs of sound samples (they sit in chunks between the video data)
      const runs=[]; for(let i=i0;i<=i1;i++){ const r=runs[runs.length-1]; if(r&&offs[i]===r.end){ r.end+=sizes[i]; r.last=i; } else runs.push({start:offs[i],end:offs[i]+sizes[i],first:i,last:i}); }
      for(let g=0; g<runs.length; g+=16){ const grp=runs.slice(g,g+16), datas=await Promise.all(grp.map(r=>fileBytes(file,r.start,r.end)));
        grp.forEach((r,gi)=>{ const b=datas[gi]; for(let i=r.first;i<=r.last;i++){ const o=offs[i]-r.start;
          dec.decode(new EncodedAudioChunk({type:"key",timestamp:Math.round(pts[i]*1e6),duration:Math.round(durs[i]*1e6),data:b.subarray(o,o+sizes[i])})); } });
        while(dec.decodeQueueSize>64) await sleep(2); if(err) break; }
      await dec.flush().catch(e=>{ err=err||e; }); try{ dec.close(); }catch(e){}
      if(err) throw err;
    };
    let sr=0, srcCh=0; await decodeRange(0,Math.min(count-1,3),ad=>{ if(!sr){ sr=ad.sampleRate; srcCh=ad.numberOfChannels; } });
    if(!sr) return {why:"codec",fmt:codec};
    const ch=Math.min(2,srcCh);
    const findFirst=x=>{ let lo=0, hi=count-1; while(lo<hi){ const m=(lo+hi)>>1; if(pts[m]+durs[m]<x) lo=m+1; else hi=m; } return lo; };
    return { reader:{ sr, ch, srcCh, codec:codec.startsWith("mp4a")?"AAC":"MP3", duration:pts[count-1]+durs[count-1], async read(a,b){
      const L=Math.max(0,Math.round((b-a)*sr)), out=[]; for(let c=0;c<ch;c++) out.push(new Float32Array(L));
      if(L===0 || b<=0 || a>=pts[count-1]+durs[count-1]) return out;
      const i0=Math.max(0,findFirst(a)-3), i1=Math.min(count-1,findFirst(b)+1), tmp={};
      await decodeRange(i0,i1,ad=>{
        const at=Math.round((ad.timestamp/1e6-a)*sr), nf=ad.numberOfFrames; if(at>=L||at+nf<=0) return;
        for(let c=0;c<ch;c++){ const pl=Math.min(c,ad.numberOfChannels-1); let buf=tmp[nf]; if(!buf) buf=tmp[nf]=new Float32Array(nf);
          ad.copyTo(buf,{planeIndex:pl,format:"f32-planar"});
          const j0=Math.max(0,-at), j1=Math.min(nf,L-at); out[c].set(buf.subarray(j0,j1),at+j0); } });
      return out; } } };
  })(); if(r.reader) return r; last=r; }
  return last;
}
/* AudioSpecificConfig -> object type, sample rate, channels */
function ascInfo(a){ if(!a||a.length<2) return null; let bit=0;
  const rd=n=>{ let v=0; for(let i=0;i<n;i++){ v=(v<<1)|((a[bit>>3]>>(7-(bit&7)))&1); bit++; } return v; };
  try{ let aot=rd(5); if(aot===31) aot=32+rd(6); const fi=rd(4);
    const sr=fi===15?rd(24):([96000,88200,64000,48000,44100,32000,24000,22050,16000,12000,11025,8000,7350][fi]||0), cc=rd(4);
    return {aot,sr,ch:cc===7?8:cc}; }catch(e){ return null; } }
/* pick the best way to read this clip's sound */
async function openAudioReader(file){
  if(!file) return {why:"no-audio"};
  let r={why:"not-mp4"};
  try{ r=await mp4AudioReader(file); }catch(e){ r={why:"not-mp4"}; }
  if(r.reader) return r;
  if(r.why==="no-audio") return r;
  if(file.size>DECODE_ALL_LIMIT) return {why:r.why==="codec"?"codec":"too-big",fmt:r.fmt};
  const buf=await getDecoded(); if(buf) return {reader:bufReader(buf,Math.min(2,buf.numberOfChannels))};
  return {why:r.why==="codec"?"codec":"no-audio",fmt:r.fmt};
}
async function pickAudioStream(){
  if(typeof AudioEncoder!=="function" || typeof AudioData!=="function") return {why:"no-encoder"};
  const o=await openAudioReader(mediaFile); if(!o.reader) return {why:o.why||"no-audio",fmt:o.fmt};
  const rd=o.reader;
  for(const [mux,codec] of [["aac","mp4a.40.2"],["opus","opus"]]){
    const cfg={codec,sampleRate:rd.sr,numberOfChannels:rd.ch,bitrate:160000};
    try{ const r=await AudioEncoder.isConfigSupported(cfg); if(r.supported){
      const how=rd.codec?`${rd.codec} sound read from the file a piece at a time`:"sound decoded from the whole file";
      const chs=(rd.srcCh||rd.ch)>2?`${rd.srcCh} channels (using the front two)`:rd.ch===1?"mono":"stereo";
      return {reader:rd,cfg,mux,ch:rd.ch,sr:rd.sr,desc:`${how}, ${(rd.sr/1000).toFixed(rd.sr%1000?1:0)} kHz ${chs}`}; } }catch(e){}
  }
  return {why:"no-encoder"};
}
function soundReport(aud){ const el=$("soundInfo"); if(!el) return;
  if(aud.reader){ const pk=aud.peak||0, db=pk>0?20*Math.log10(pk):-Infinity;
    el.textContent=`Sound: ${aud.desc}, saved as ${aud.mux==="aac"?"AAC":"Opus"}. Loudest point ${pk>0?db.toFixed(1)+" dB":"silent"}.`+(pk<=0.0005?" The sound came out silent even though it was read. Please report this with the clip's details.":"")+(aud.mux==="opus"?" Opus plays in Chrome and VLC, not QuickTime or Photos.":""); }
  else el.textContent="Sound: none."+audioWhyNote(aud)+(aud.fmt&&aud.fmt!=="?"?` (Format found: ${aud.fmt}.)`:"");
  el.hidden=false; }
function audioWhyNote(aud){
  if(aud.why==="no-encoder") return " This browser can't encode sound, so the video is silent.";
  if(aud.why==="too-big") return " This clip is too big to read its sound in its format, so the video is silent. Save it as an MP4 or MOV and try again.";
  if(aud.why==="codec") return " This clip's sound format can't be read by this browser (it may be Dolby or another special format), so the video is silent.";
  if(aud.why==="no-decoder") return " This browser can't read the sound from a clip this big, so the video is silent. Try Chrome or Safari.";
  if(aud.why==="no-audio") return " The clip has no sound, or its sound couldn't be read, so the video is silent.";
  return "";
}

/* ---- the VHS sound chain, run in 60-second chunks with seamless joins ---- */
function hash11(seed,k){ let t=(Math.imul(k|0,0x9E3779B1)^Math.imul(seed|0,0x85EBCA6B))>>>0; t=Math.imul(t^(t>>>15),t|1); t^=t+Math.imul(t^(t>>>7),t|61); return (((t^(t>>>14))>>>0)/4294967296)*2-1; }
function noiseAt(seed,x){ const k=Math.floor(x), f=x-k, s=f*f*(3-2*f), a=hash11(seed,k), b=hash11(seed,k+1); return a+(b-a)*s; }
function audioPlan(A,dur,seed){
  const rng=mulberry(1234+seed), ph1=rng()*6.28, ph2=rng()*6.28, drops=[], clicks=[];
  if(A.dropouts>0){ const rate=A.dropouts*0.7; let t=rng()*2/Math.max(rate,0.01);
    while(t<dur){ const l=0.03+rng()*0.14, depth=0.5+rng()*0.45; drops.push([t,l,depth]); t+=l+(-Math.log(1-rng()))/Math.max(rate,0.01); } }
  if(A.clicks>0){ const rate=A.clicks*2.5, cr=mulberry(99+seed); let t=cr()/rate;
    while(t<dur){ const amp=(0.05+cr()*0.2)*(cr()<0.5?-1:1), l=0.0006+cr()*0.002; clicks.push([t,amp,l]); t+=(-Math.log(1-cr()))/rate; } }
  return {ph1,ph2,drops,clicks,seed};
}
/* render one stretch: output samples [sA, sA+L) of the trimmed clip (sample 0 = the Start point), warmed up on 1 s of earlier sound */
async function renderChunk(reader,t0,sA,L,A,CH,plan){
  const sr=reader.sr, P=Math.round(1.0*sr), D=Math.round(0.01*sr), total=P+L+D, cdur=total/sr, base=(sA-P)/sr;
  const inp=await reader.read(t0+base, t0+base+(P+L)/sr);
  const oc=new OfflineAudioContext(CH,total,sr);
  const ib=oc.createBuffer(CH,P+L,sr); for(let c=0;c<CH;c++) ib.copyToChannel(inp[Math.min(c,inp.length-1)].subarray(0,P+L),c);
  const srcN=oc.createBufferSource(); srcN.buffer=ib;
  const out=oc.createGain(); out.gain.value=1;
  const limiter=oc.createDynamicsCompressor(); limiter.threshold.value=-1; limiter.knee.value=0; limiter.ratio.value=20; limiter.attack.value=0.002; limiter.release.value=0.08;
  out.connect(limiter).connect(oc.destination);
  const dryD=oc.createDelay(1); dryD.delayTime.value=D/sr; const dry=oc.createGain(); dry.gain.value=1-A.mix; srcN.connect(dryD).connect(dry).connect(out);
  // wow & flutter follow the clip's own clock, so neighbouring chunks line up exactly
  const d=oc.createDelay(1), cr=200, N=Math.max(2,Math.ceil(cdur*cr)), curve=new Float32Array(N);
  for(let i=0;i<N;i++){ const t=base+i/cr;
    const wow=A.wow*0.0042*(0.6*Math.sin(2*Math.PI*0.5*t+plan.ph1)+0.4*noiseAt(plan.seed+11,t*0.35));
    const flut=A.flutter*0.00055*(Math.sin(2*Math.PI*7.3*t+plan.ph2)*0.7+noiseAt(plan.seed+22,t*3)*0.3);
    curve[i]=D/sr+wow+flut; }
  d.delayTime.setValueCurveAtTime(curve,0,cdur);
  const hp=oc.createBiquadFilter(); hp.type="highpass"; hp.frequency.value=A.lowCut; hp.Q.value=0.707;
  const warm=oc.createBiquadFilter(); warm.type="lowshelf"; warm.frequency.value=220; warm.gain.value=A.warmth*7;
  const lp1=oc.createBiquadFilter(); lp1.type="lowpass"; lp1.frequency.value=A.highCut; lp1.Q.value=0.6;
  const lp2=oc.createBiquadFilter(); lp2.type="lowpass"; lp2.frequency.value=A.highCut*1.15; lp2.Q.value=0.9;
  const sh=oc.createWaveShaper(), drv=1+A.drive*4, sc=new Float32Array(4096);
  for(let i=0;i<4096;i++){ const x=(i/2047.5-1)*4; sc[i]=Math.tanh(x); } sh.curve=sc; sh.oversample="2x";
  const pre_g=oc.createGain(); pre_g.gain.value=drv/4;
  const post_g=oc.createGain(); post_g.gain.value=1/drv;
  const comp=oc.createDynamicsCompressor(); comp.threshold.value=-8-A.comp*30; comp.ratio.value=1+A.comp*7; comp.knee.value=12; comp.attack.value=0.006; comp.release.value=0.18;
  const makeup=oc.createGain(); makeup.gain.value=1+A.comp*0.5;
  const drop=oc.createGain(), DR=500, DN=Math.max(2,Math.ceil(cdur*DR)), dc=new Float32Array(DN).fill(1);
  for(const [ts,l,depth] of plan.drops){ if(ts+l<base||ts>base+cdur) continue;
    const a=Math.floor((ts-base)*DR), b=Math.min(DN,Math.floor((ts+l-base)*DR));
    for(let i=Math.max(0,a);i<b;i++){ const x=(i-a)/Math.max(1,b-a), env=Math.sin(Math.PI*x); dc[i]=Math.min(dc[i],1-depth*env); } }
  drop.gain.setValueCurveAtTime(dc,0,cdur);
  const wet=oc.createGain(); wet.gain.value=A.mix;
  srcN.connect(d).connect(hp).connect(warm).connect(lp1).connect(lp2).connect(pre_g).connect(sh).connect(post_g).connect(comp).connect(makeup);
  let tail=makeup;
  if(CH===2){
    const sp=oc.createChannelSplitter(2), mg=oc.createChannelMerger(2), w=A.width, a1=0.5+0.5*w, a2=0.5-0.5*w;
    const g=[a1,a2,a2,a1].map(v=>{ const n=oc.createGain(); n.gain.value=v; return n; });
    tail.connect(sp); sp.connect(g[0],0); sp.connect(g[1],1); sp.connect(g[2],0); sp.connect(g[3],1);
    g[0].connect(mg,0,0); g[1].connect(mg,0,0); g[2].connect(mg,0,1); g[3].connect(mg,0,1); tail=mg;
    if(A.drift>0 && oc.createStereoPanner){ const pn=oc.createStereoPanner(), PN=Math.max(2,Math.ceil(cdur*50)), pc=new Float32Array(PN);
      for(let i=0;i<PN;i++) pc[i]=noiseAt(plan.seed+33,(base+i/50)*0.15)*A.drift*0.6;
      pn.pan.setValueCurveAtTime(pc,0,cdur); tail.connect(pn); tail=pn; }
  }
  tail.connect(drop).connect(wet).connect(out);
  srcN.start(0);
  const res=await oc.startRendering(), outs=[], ins=[];
  for(let c=0;c<CH;c++){ outs.push(res.getChannelData(c).subarray(P+D,P+D+L)); ins.push(inp[Math.min(c,inp.length-1)].subarray(P,P+L)); }
  return {out:outs,inp:ins};
}
async function processChunked(reader,t0,dur,A,CH,emit,prog){
  const sr=reader.sr, total=Math.round(dur*sr), CS=60*sr, XF=Math.round(0.03*sr), seed=(S.seed>>>0), plan=audioPlan(A,dur,seed);
  if(total<=0) return;
  // loudness: measured on the whole clip when short, or on six spread-out samples when long
  const wins = dur<=150 ? [[0,total]] : Array.from({length:6},(_,k)=>{ const len=Math.min(total,15*sr); return [Math.round((total-len)*k/5),len]; });
  let si=0, so=0, n=0;
  for(const [s,len] of wins){ const r=await renderChunk(reader,t0,s,len,A,CH,plan);
    for(let c=0;c<CH;c++){ const a=r.inp[c], b=r.out[c]; for(let i=0;i<len;i+=4){ si+=a[i]*a[i]; so+=b[i]*b[i]; n++; } } }
  const inR=Math.sqrt(si/Math.max(1,n)), outR=Math.sqrt(so/Math.max(1,n));
  const gain=(inR>1e-5 && outR>1e-5 ? Math.max(0.25,Math.min(4,inR/outR)) : 1)*A.vol;
  const hissAmp=A.hiss*0.035*Math.max(0.12,Math.min(1.2,inR/0.1))*A.vol, clickK=Math.max(0.3,Math.min(1.5,inR/0.1));
  const hpA=Math.exp(-2*Math.PI*900/sr), lpA=Math.exp(-2*Math.PI*Math.min(16000,A.highCut*1.2)/sr);
  const hs=[]; for(let c=0;c<CH;c++) hs.push({b0:0,b1:0,b2:0,hpX:0,hpY:0,lpY:0,rng:mulberry(4321+seed+c*7919)});
  const hums=A.hum>0?[[1,1],[2,0.5],[3,0.3]].map(([h,amp])=>[2*Math.PI*A.humHz*h/sr, A.hum*0.025*amp*gain]):[];
  let prev=null;
  for(let sA=0; sA<total; sA+=CS){
    if(typeof cancelReq!=="undefined" && cancelReq) return;
    const L=Math.min(CS,total-sA), post=sA+L>=total?0:XF;
    const r=await renderChunk(reader,t0,sA,L+post,A,CH,plan);
    const outs=r.out.map(a=>{ const o=new Float32Array(L+post); for(let i=0;i<L+post;i++) o[i]=a[i]*gain; return o; });
    if(prev) for(let c=0;c<CH;c++) for(let i=0;i<XF;i++){ const w=(i+0.5)/XF; outs[c][i]=prev[c][i]*(1-w)+outs[c][i]*w; }
    prev=post?outs.map(o=>o.slice(L,L+post)):null;
    for(let c=0;c<CH;c++){ const o=outs[c], H=hs[c];
      for(const [wv,amp] of hums) for(let i=0;i<L;i++) o[i]+=amp*Math.sin(wv*(sA+i));
      if(hissAmp>0) for(let i=0;i<L;i++){ const wv=H.rng()*2-1; H.b0=0.99765*H.b0+wv*0.099046; H.b1=0.963*H.b1+wv*0.2965164; H.b2=0.57*H.b2+wv*1.0526913;
        const pink=(H.b0+H.b1+H.b2+wv*0.1848)*0.2; H.hpY=hpA*(H.hpY+pink-H.hpX); H.hpX=pink; H.lpY=(1-lpA)*H.hpY+lpA*H.lpY; o[i]+=H.lpY*hissAmp*4; }
      for(const [ts,amp,l] of plan.clicks){ const i0=Math.round(ts*sr)-sA, Lc=Math.floor(sr*l); if(i0>=L||i0+Lc<0) continue;
        for(let k=Math.max(0,-i0);k<Lc&&i0+k<L;k++) o[i0+k]+=amp*clickK*Math.exp(-k/(Lc*0.25))*(c===0?1:0.85); }
      for(let i=0;i<L;i++){ const v=o[i]; o[i]=v>0.9?0.9+0.1*Math.tanh((v-0.9)/0.1):v<-0.9?-0.9-0.1*Math.tanh((-v-0.9)/0.1):v; }
    }
    await emit(outs.map(o=>o.subarray(0,L)),L);
    if(prog) prog(Math.min(1,(sA+L)/total));
  }
}

/* ---- 1.5.1: long renders on a computer can be written straight to a file as they go ---- */
const STREAM_SAVE_MIN=90; // seconds
function canStreamSave(){ try{ return typeof window.showSaveFilePicker==="function" && !window.claude && window.self===window.top; }catch(e){ return false; } }

if(/[?&]test\b/.test(location.search)) window.__pr={openAudioReader,processChunked,bufReader,addToRoll,get roll(){ return roll; },get A(){ return A; },get mediaFile(){ return mediaFile; },set(k,v){ if(k==="V") Object.assign(V,v); if(k==="P") Object.assign(P,v); if(k==="A") Object.assign(A,v); }};

/* ================= render sound only ================= */
function applyBufFades(ab){ const fd=soundFades(); if(!(fd.in>0||fd.out>0)) return; const sr=ab.sampleRate, dur=ab.length/sr;
  for(let c=0;c<ab.numberOfChannels;c++){ const d=ab.getChannelData(c); for(let i=0;i<d.length;i++){ const t=i/sr; if(t>=fd.in && t<=dur-fd.out) continue; d[i]*=fadeGain(t,dur,fd.in,fd.out); } } }
function wavBlob(ab){
  const ch=ab.numberOfChannels, len=ab.length, sr=ab.sampleRate, buf=new ArrayBuffer(44+len*ch*2), v=new DataView(buf);
  const w=(o,s)=>{ for(let i=0;i<s.length;i++) v.setUint8(o+i,s.charCodeAt(i)); };
  w(0,"RIFF"); v.setUint32(4,36+len*ch*2,true); w(8,"WAVE"); w(12,"fmt "); v.setUint32(16,16,true); v.setUint16(20,1,true); v.setUint16(22,ch,true);
  v.setUint32(24,sr,true); v.setUint32(28,sr*ch*2,true); v.setUint16(32,ch*2,true); v.setUint16(34,16,true); w(36,"data"); v.setUint32(40,len*ch*2,true);
  const cd=[]; for(let c=0;c<ch;c++) cd.push(ab.getChannelData(c)); let o=44;
  for(let i=0;i<len;i++) for(let c=0;c<ch;c++){ const s=Math.max(-1,Math.min(1,cd[c][i])); v.setInt16(o,s<0?s*0x8000:s*0x7fff,true); o+=2; }
  return new Blob([buf],{type:"audio/wav"});
}
async function renderAudio(){
  const buf=await getDecoded(); if(!buf){ $("note").textContent="This file's sound couldn't be read."; return; }
  rendering=true; cancelReq=false; $("prog").hidden=false; clearResult(); $("note").textContent=""; $("progBar").style.width="30%"; $("progTxt").textContent="Processing the sound…"; $("vfdState").textContent="REC";
  let lock=null; try{ lock=await navigator.wakeLock?.request("screen"); }catch(e){}
  try{
    const sr=buf.sampleRate, CH=Math.min(2,buf.numberOfChannels), s0=Math.floor(V.start*sr), s1=Math.min(buf.length,Math.floor(V.end*sr));
    let ab;
    if(A.on) ab=await processAudio(buf,s0,s1,A,CH);
    else { ab=new AudioBuffer({length:s1-s0,numberOfChannels:CH,sampleRate:sr}); for(let c=0;c<CH;c++) ab.copyToChannel(buf.getChannelData(c).subarray(s0,s1),c); }
    $("progBar").style.width="70%"; $("progTxt").textContent="Writing the file…";
    const base=(mediaFile.name||"sound").replace(/\.[^.]+$/,"").replace(/[^\w\- ]+/g,"").slice(0,40)||"sound";
    const aud=await pickAudioFor(ab); let blob, ext, playBlob, note="";
    if(aud && typeof Mp4Muxer!=="undefined"){
      const muxer=new Mp4Muxer.Muxer({target:new Mp4Muxer.ArrayBufferTarget(), audio:{codec:aud.mux,sampleRate:sr,numberOfChannels:CH}, fastStart:"in-memory", firstTimestampBehavior:"offset"});
      await encodeAudioInto(muxer,Object.assign({},aud,{buf:ab,ch:CH,fade:soundFades()}),0,ab.duration,null); muxer.finalize();
      blob=new Blob([muxer.target.buffer],{type:"audio/mp4"}); ext="mp4"; playBlob=blob;
    } else { applyBufFades(ab); const wav=wavBlob(ab); playBlob=wav; blob=await makeZip([{name:base+"-vhs.wav",blob:wav}]); ext="zip"; note=" This browser can't make an MP4 sound file, so it's saved as a WAV inside a ZIP."; }
    result={blob,url:URL.createObjectURL(playBlob),ext,name:base}; resultKey=keyNow();
    $("resultAudio").src=result.url; $("resultAudio").hidden=false;
    await addToRoll({type:"audio",blob,thumb:await thumbOf(src),ext,name:base});
    $("note").textContent=`Sound ready (${fmtT(ab.duration)}) and added to your roll.${note} Tap Save sound to keep it.`;
  }catch(e){ $("note").textContent="The sound couldn't be processed on this device. Try a shorter selection."; }
  titleDone("Sound ready"); try{ lock&&lock.release(); }catch(e){} rendering=false; $("prog").hidden=true; $("vfdState").textContent="READY"; setSaveLabel();
}
async function pickAudioFor(ab){
  if(typeof AudioEncoder!=="function"||typeof AudioData!=="function") return null;
  for(const [mux,codec] of [["aac","mp4a.40.2"],["opus","opus"]]){ const cfg={codec,sampleRate:ab.sampleRate,numberOfChannels:Math.min(2,ab.numberOfChannels),bitrate:160000};
    try{ const r=await AudioEncoder.isConfigSupported(cfg); if(r.supported) return {cfg,mux}; }catch(e){} }
  return null;
}
$("cancelBtn").onclick=()=>{ cancelReq=true; $("progTxt").textContent="Stopping…"; };

%%AUDIOENG%%

/* ================= ZIP (stored, no compression) ================= */
const CRC=(()=>{ const t=new Uint32Array(256); for(let n=0;n<256;n++){ let c=n; for(let k=0;k<8;k++) c=c&1?0xEDB88320^(c>>>1):c>>>1; t[n]=c>>>0; } return t; })();
function crc32(u8){ let c=0xFFFFFFFF; for(let i=0;i<u8.length;i++) c=CRC[(c^u8[i])&255]^(c>>>8); return (c^0xFFFFFFFF)>>>0; }
async function makeZip(files){
  const parts=[], cent=[]; let off=0; const enc=new TextEncoder(), now=new Date();
  const dt=((now.getHours()<<11)|(now.getMinutes()<<5)|(now.getSeconds()>>1))&0xffff, dd=(((now.getFullYear()-1980)<<9)|((now.getMonth()+1)<<5)|now.getDate())&0xffff;
  for(const f of files){
    const data=new Uint8Array(await f.blob.arrayBuffer()), nm=enc.encode(f.name), crc=crc32(data);
    const h=new DataView(new ArrayBuffer(30)); h.setUint32(0,0x04034b50,true); h.setUint16(4,20,true); h.setUint16(6,0x0800,true); h.setUint16(8,0,true);
    h.setUint16(10,dt,true); h.setUint16(12,dd,true); h.setUint32(14,crc,true); h.setUint32(18,data.length,true); h.setUint32(22,data.length,true); h.setUint16(26,nm.length,true); h.setUint16(28,0,true);
    parts.push(h.buffer,nm,data);
    const c=new DataView(new ArrayBuffer(46)); c.setUint32(0,0x02014b50,true); c.setUint16(4,20,true); c.setUint16(6,20,true); c.setUint16(8,0x0800,true); c.setUint16(10,0,true);
    c.setUint16(12,dt,true); c.setUint16(14,dd,true); c.setUint32(16,crc,true); c.setUint32(20,data.length,true); c.setUint32(24,data.length,true); c.setUint16(28,nm.length,true); c.setUint32(42,off,true);
    cent.push(c.buffer,nm); off+=30+nm.length+data.length;
  }
  let csz=0; for(const p of cent) csz+=p.byteLength;
  const e=new DataView(new ArrayBuffer(22)); e.setUint32(0,0x06054b50,true); e.setUint16(8,files.length,true); e.setUint16(10,files.length,true); e.setUint32(12,csz,true); e.setUint32(16,off,true);
  return new Blob([...parts,...cent,e.buffer],{type:"application/zip"});
}

/* ================= roll (kept in this browser) ================= */
let roll=[], curItem=null, selecting=false; const sel=new Set();
let dbp=null;
function idb(){ if(dbp) return dbp; dbp=new Promise(res=>{ try{ const r=indexedDB.open("pocket-retro",2); r.onupgradeneeded=()=>{ const db=r.result; if(!db.objectStoreNames.contains("roll")) db.createObjectStore("roll",{keyPath:"id"}); if(!db.objectStoreNames.contains("frames")) db.createObjectStore("frames",{keyPath:"id"}); }; r.onsuccess=()=>res(r.result); r.onerror=()=>res(null); }catch(e){ res(null); } }); return dbp; }
async function dbPut(it){ try{ const db=await idb(); if(!db) return; const {url,thumbUrl,...rest}=it; db.transaction("roll","readwrite").objectStore("roll").put(rest); }catch(e){} }
async function dbDel(id){ try{ const db=await idb(); if(!db) return; db.transaction("roll","readwrite").objectStore("roll").delete(id); }catch(e){} }
async function dbAll(){ try{ const db=await idb(); if(!db) return []; return await new Promise(res=>{ const q=db.transaction("roll").objectStore("roll").getAll(); q.onsuccess=()=>res(q.result||[]); q.onerror=()=>res([]); }); }catch(e){ return []; } }
async function thumbOf(c){ const t=document.createElement("canvas"), s=200/Math.max(c.width,c.height); t.width=Math.max(1,Math.round(c.width*s)); t.height=Math.max(1,Math.round(c.height*s)); t.getContext("2d").drawImage(c,0,0,t.width,t.height); return await toBlob(t,"image/jpeg",0.8); }
function hydrate(it){ it.thumbUrl=URL.createObjectURL(it.thumb||it.blob); return it; }
async function addToRoll(o){
  const it=hydrate(Object.assign({id:Date.now().toString(36)+Math.random().toString(36).slice(2,6), mode:M, time:Date.now()},o));
  roll.unshift(it); renderRoll(); dbPut(it); return it;
}
let keepT=null;
let autoKeep=false;
async function camAutoKeep(blob,c){ /* a shot taken with the camera goes to the roll once, as it was taken; later edits never rewrite it */
  autoKeep=false; const thumb=await thumbOf(c);
  curItem=await addToRoll({type:"photo",blob,thumb,ext:"jpg",src:mediaFile,srcFile:srcKey,num:roll.filter(r=>r.mode==="camera"&&r.type==="photo").length+1});
  $("note").textContent="Shot added to your roll. Changes you make now won't alter it; tap Add to roll to keep another version.";
}
let srcKey="";
function renderRoll(){
  const g=$("rollGrid"); g.textContent="";
  const vidOrder=[...sel].filter(id=>{ const r=roll.find(x=>x.id===id); return r&&r.type==="video"; });
  for(const it of roll){ const b=document.createElement("button"); b.className="rthumb"; b.setAttribute("aria-label",(it.type==="photo"?"Photo":it.type==="video"?"Video":"Sound")+" from "+new Date(it.time).toLocaleString());
    if(sel.has(it.id)) b.setAttribute("aria-pressed","true");
    const im=document.createElement("img"); im.src=it.thumbUrl; im.alt=""; b.appendChild(im);
    if(it.type!=="photo"){ const t=document.createElement("span"); t.className="rtag"; t.textContent=it.type==="video"?"▶":"♪"; b.appendChild(t); }
    if(selecting){ const ck=document.createElement("span"); ck.className="rck"; const vi=vidOrder.indexOf(it.id); if(vi>=0) ck.textContent=vi+1; b.appendChild(ck); }
    b.onclick=()=>{ if(selecting){ sel.has(it.id)?sel.delete(it.id):sel.add(it.id); renderRoll(); } else openViewer(it); };
    g.appendChild(b); }
  $("rollCount").textContent=roll.length; $("rollEmpty").hidden=roll.length>0;
  $("rollSelect").textContent=selecting?"Done":"Select"; $("rollSelect").hidden=roll.length===0;
  $("rollBar").hidden=!selecting; $("selCount").textContent=`${sel.size} selected`;
  ["selSave","selZip","selDel"].forEach(id=>$(id).disabled=sel.size===0); if(!selecting) $("lookPick").hidden=true;
  $("selJoin").disabled=roll.filter(r=>sel.has(r.id)&&r.type==="video").length<2;
  $("selLook").disabled=!roll.some(r=>sel.has(r.id)&&r.type==="photo");
}
$("rollSelect").onclick=()=>{ selecting=!selecting; if(!selecting) sel.clear(); $("delConfirm").hidden=true; closeViewer(); renderRoll(); };
$("selAll").onclick=()=>{ if(sel.size===roll.length) sel.clear(); else roll.forEach(r=>sel.add(r.id)); renderRoll(); };
$("selDel").onclick=()=>{ $("delN").textContent=`${sel.size} item${sel.size>1?"s":""}`; $("delConfirm").hidden=false; };
$("delNo").onclick=()=>{ $("delConfirm").hidden=true; };
$("delYes").onclick=()=>{ for(const id of sel){ const it=roll.find(r=>r.id===id); if(it){ URL.revokeObjectURL(it.thumbUrl); dbDel(id); if(curItem===it) curItem=null; } } roll=roll.filter(r=>!sel.has(r.id)); sel.clear(); $("delConfirm").hidden=true; selecting=false; renderRoll(); };
const fname=it=>`pocket-retro_${stamp(new Date(it.time))}${it.type==="audio"&&it.name?"_"+it.name:""}.${it.ext||"jpg"}`;
$("selSave").onclick=async()=>{ const d=await getDownloads(); if(!d){ $("note").textContent="Saving isn't available here."; return; }
  const items=roll.filter(r=>sel.has(r.id)); let n=0;
  for(const it of items){ try{ await d.save({filename:fname(it),data:it.blob}); n++; }catch(e){ if(e&&e.code==="declined") break; await sleep(400); try{ await d.save({filename:fname(it),data:it.blob}); n++; }catch(e2){ break; } } }
  $("note").textContent= n===items.length ? `Saved ${n} item${n>1?"s":""}.` : `Saved ${n} of ${items.length}. Tap Save again to carry on.`; };
$("selZip").onclick=async()=>{ const d=await getDownloads(); if(!d){ $("note").textContent="Saving isn't available here."; return; }
  const items=roll.filter(r=>sel.has(r.id)); $("note").textContent="Packing the ZIP…";
  const used=new Set(), files=items.map(it=>{ let n=fname(it), k=1; while(used.has(n)) n=n.replace(/(\.\w+)$/,`_${k++}$1`); used.add(n); return {name:n,blob:it.blob}; });
  const z=await makeZip(files);
  try{ await d.save({filename:`pocket-retro_roll_${stamp(new Date())}.zip`,data:z}); $("note").textContent=`Saved ${items.length} item${items.length>1?"s":""} in one ZIP. On iPhone it goes to the Files app.`; }
  catch(e){ $("note").textContent= e&&e.code==="declined"?"Not saved.":e&&e.code==="too_large"?"That ZIP is too big. Select fewer items.":"Saving isn't available here right now."; } };
let viewing=null;
function openViewer(it){
  viewing=it; const box=$("viewerMedia"); box.textContent="";
  const u=URL.createObjectURL(it.type==="audio"&&it.ext==="zip"?(it.thumb):it.blob); box.dataset.url=u;
  if(it.type==="photo"){ const im=document.createElement("img"); im.src=u; im.alt="Photo from your roll"; box.appendChild(im); }
  else if(it.type==="video"){ const v=document.createElement("video"); v.src=u; v.controls=true; v.playsInline=true; box.appendChild(v); }
  else { const im=document.createElement("img"); im.src=it.thumbUrl; im.alt=""; box.appendChild(im); if(it.ext!=="zip"){ const a=document.createElement("audio"); a.src=u; a.controls=true; box.appendChild(a); } }
  $("vwEdit").hidden=!(it.type==="photo" && it.src); $("vwFrame").hidden=it.type!=="video"; $("vwConfirm").hidden=true; $("viewer").hidden=false;
  $("vwInfo").textContent=`${it.mode==="camera"?"Camera":"Tape"} · ${new Date(it.time).toLocaleString()}`;
  $("viewer").scrollIntoView({block:"nearest",behavior:"smooth"});
}
function closeViewer(){ const box=$("viewerMedia"); if(box.dataset.url) URL.revokeObjectURL(box.dataset.url); box.textContent=""; $("viewer").hidden=true; viewing=null; }
$("vwClose").onclick=closeViewer;
$("vwSave").onclick=async()=>{ if(!viewing) return; const d=await getDownloads(); if(!d){ $("note").textContent="Saving isn't available here. Press and hold the picture to save it."; return; }
  try{ await d.save({filename:fname(viewing),data:viewing.blob}); $("note").textContent="Saved."; }catch(e){ $("note").textContent=e&&e.code==="declined"?"Not saved.":"Saving isn't available here right now."; } };
$("vwEdit").onclick=async()=>{ if(!viewing||!viewing.src) return; const it=viewing; closeViewer(); if(it.mode!==M) setMode(it.mode,true); await takeFile(it.src,it); window.scrollTo({top:0,behavior:"smooth"}); };
$("vwDel").onclick=()=>{ $("vwConfirm").hidden=false; };
$("vwNo").onclick=()=>{ $("vwConfirm").hidden=true; };
$("vwYes").onclick=()=>{ const it=viewing; if(!it) return; URL.revokeObjectURL(it.thumbUrl); dbDel(it.id); roll=roll.filter(r=>r!==it); if(curItem===it) curItem=null; closeViewer(); renderRoll(); };


/* ================= custom frames (Camera mode), kept in IndexedDB "frames" ================= */
let FRAMES=[];
function frameHydrate(f){ f.url=URL.createObjectURL(f.blob); const im=new Image(); im.onload=()=>{ prepDirty=true; schedule(); }; im.src=f.url; f.img=im; return f; }
async function framesLoad(){
  let list=[]; try{ const db=await idb(); if(db) list=await new Promise(res=>{ try{ const q=db.transaction("frames").objectStore("frames").getAll(); q.onsuccess=()=>res(q.result||[]); q.onerror=()=>res([]); }catch(e){ res([]); } }); }catch(e){}
  list.sort((a,b)=>a.time-b.time); FRAMES=list.map(frameHydrate);
  buildPanel(); prepDirty=true; schedule();
}
function curFrameId(){ return M==="tape"?P.fId:C.cfId; }
function setFrameId(id){ if(M==="tape") P.fId=id; else C.cfId=id; }
function curFrame(){ const id=curFrameId(); return FRAMES.find(f=>f.id===id)||null; }
async function addFrameFile(file){
  try{ const u=URL.createObjectURL(file);
    const im=await new Promise((res,rej)=>{ const i=new Image(); i.onload=()=>res(i); i.onerror=rej; i.src=u; });
    let w=im.naturalWidth||1200, h=im.naturalHeight||900; const s=Math.min(1,1600/Math.max(w,h)); w=Math.max(1,Math.round(w*s)); h=Math.max(1,Math.round(h*s));
    const cv=document.createElement("canvas"); cv.width=w; cv.height=h; cv.getContext("2d").drawImage(im,0,0,w,h); URL.revokeObjectURL(u);
    const blob=await toBlob(cv,"image/png");
    const f={id:"f"+Date.now().toString(36)+Math.random().toString(36).slice(2,5), name:((file.name||"Frame").replace(/\.[^.]+$/,"")||"Frame").slice(0,30), time:Date.now(), blob};
    const db=await idb(); if(db) await new Promise(res=>{ try{ const tx=db.transaction("frames","readwrite"); tx.objectStore("frames").put(f); tx.oncomplete=res; tx.onerror=res; tx.onabort=res; }catch(e){ res(); } });
    FRAMES.push(frameHydrate(f)); if(M==="tape"){ P.frameOn=true; P.fId=f.id; } else { C.frame="custom"; C.cfId=f.id; } buildPanel(); changed(true);
    $("note").textContent="Frame added. Use the controls below it to fit and place it.";
  }catch(e){ $("note").textContent="That image couldn't be opened. Try a PNG file."; }
}
async function removeFrame(id){
  const f=FRAMES.find(x=>x.id===id); if(!f) return;
  try{ const db=await idb(); if(db) db.transaction("frames","readwrite").objectStore("frames").delete(id); }catch(e){}
  URL.revokeObjectURL(f.url); FRAMES=FRAMES.filter(x=>x!==f);
  const next=FRAMES.length?FRAMES[FRAMES.length-1].id:""; if(C.cfId===id) C.cfId=next; if(P.fId===id) P.fId=next;
  buildPanel(); changed(true);
}
function drawFrameImg(x,ox,oy,W,H,o){
  const f=FRAMES.find(fr=>fr.id===o.id), im=f&&f.img; if(!im||!im.complete||!im.naturalWidth) return;
  const iw=im.naturalWidth, ih=im.naturalHeight; let w=W, h=H;
  if(o.fit==="fit"){ const s=Math.min(W/iw,H/ih); w=iw*s; h=ih*s; } else if(o.fit==="fill"){ const s=Math.max(W/iw,H/ih); w=iw*s; h=ih*s; }
  w*=o.scale; h*=o.scale; const px=ox+(W-w)/2+o.x*W, py=oy+(H-h)/2-o.y*H;
  x.save(); x.beginPath(); x.rect(ox,oy,W,H); x.clip();
  x.globalAlpha=o.opacity; x.globalCompositeOperation=o.blend==="screen"?"screen":o.blend==="multiply"?"multiply":"source-over";
  x.imageSmoothingEnabled=true; x.imageSmoothingQuality="high"; x.drawImage(im,px,py,w,h); x.restore();
}
function drawCustomFrame(x,W,H){ drawFrameImg(x,0,0,W,H,{id:C.cfId,fit:C.cfFit,scale:C.cfScale,x:C.cfX,y:C.cfY,opacity:C.cfOpacity,blend:C.cfBlend}); }
function drawTapeFrame(x,ox,oy,W,H){ drawFrameImg(x,ox,oy,W,H,{id:P.fId,fit:P.fFit,scale:P.fScale,x:P.fX,y:P.fY,opacity:P.fOpacity,blend:P.fBlend}); }
framesLoad();

/* ================= backup and restore (one ZIP: backup.json + the roll's files) ================= */
function bkNote(t){ $("bkNote").textContent=t; }
const MIME_EXT={"image/jpeg":"jpg","image/png":"png","image/webp":"webp","image/heic":"heic","image/gif":"gif","video/mp4":"mp4","video/quicktime":"mov","video/webm":"webm","audio/mp4":"m4a","audio/mpeg":"mp3","audio/wav":"wav","audio/x-wav":"wav","application/zip":"zip"};
const extOf=(b,def)=>MIME_EXT[(b&&b.type)||""]||def||"bin";
async function makeBackup(){
  const d=await getDownloads(); if(!d){ bkNote("Saving isn't available here."); return; }
  try{ localStorage.setItem("pretro",JSON.stringify({M,S,P,A,C,preset:presetId,tabT,tabC,lookId})); }catch(e){}
  $("bkSave").disabled=true; bkNote("Packing your backup…");
  try{
    const files=[], items=[], srcMap=new Map();
    for(const it of roll){
      const e={id:it.id,mode:it.mode,time:it.time,type:it.type,ext:it.ext,num:it.num,name:it.name,srcFile:it.srcFile};
      if(it.blob){ e.blob={path:`roll/${it.id}.${it.ext||extOf(it.blob)}`,type:it.blob.type||""}; files.push({name:e.blob.path,blob:it.blob}); }
      if(it.thumb){ e.thumb={path:`roll/${it.id}-thumb.jpg`,type:it.thumb.type||"image/jpeg"}; files.push({name:e.thumb.path,blob:it.thumb}); }
      if(it.src){ let p=srcMap.get(it.src);
        if(!p){ p=`originals/${srcMap.size+1}.${extOf(it.src,((it.src.name||"").split(".").pop()||"bin").toLowerCase())}`; srcMap.set(it.src,p); files.push({name:p,blob:it.src}); }
        e.src={path:p,type:it.src.type||"",name:it.src.name||""}; }
      items.push(e);
    }
    const frames=[]; for(const f of FRAMES){ const p=`frames/${f.id}.png`; files.push({name:p,blob:f.blob}); frames.push({id:f.id,name:f.name,time:f.time,path:p}); }
    let settings=null; try{ settings=localStorage.getItem("pretro"); }catch(e){}
    const man={app:"pocket-retro",backup:1,made:new Date().toISOString(),settings,looks:LOOKS,imports:IMPORTED,logo:LOGO.url,frames,roll:items};
    files.unshift({name:"backup.json",blob:new Blob([JSON.stringify(man)],{type:"application/json"})});
    const z=await makeZip(files);
    await d.save({filename:`pocket-retro_backup_${stamp(new Date())}.retrobackup`,data:new Blob([z],{type:"application/octet-stream"})});
    const n=roll.length, l=LOOKS.length;
    const fr=FRAMES.length;
    bkNote(`Backup saved (${(z.size/1048576).toFixed(1)} MB): ${n} roll item${n===1?"":"s"}, ${l} look${l===1?"":"s"}${fr?`, ${fr} frame${fr===1?"":"s"}`:""}, your settings${LOGO.url?" and your logo":""}. On iPhone, choose Save to Files.`);
  }catch(e){ bkNote(e&&e.code==="declined"?"Backup not saved.":e&&e.code==="too_large"?"Your roll is too big for one backup here. Save your videos, delete some from the roll, then try again.":"The backup couldn't be saved on this device."); }
  $("bkSave").disabled=false;
}
function readZip(buf){
  const u8=new Uint8Array(buf), v=new DataView(buf); let e=-1;
  for(let i=u8.length-22;i>=Math.max(0,u8.length-65557);i--) if(v.getUint32(i,true)===0x06054b50){ e=i; break; }
  if(e<0) throw new Error("not a zip");
  const n=v.getUint16(e+10,true), out=new Map(), dec=new TextDecoder(); let p=v.getUint32(e+16,true);
  for(let k=0;k<n;k++){
    if(v.getUint32(p,true)!==0x02014b50) throw new Error("bad zip");
    const meth=v.getUint16(p+10,true), csz=v.getUint32(p+20,true), nl=v.getUint16(p+28,true), xl=v.getUint16(p+30,true), cl=v.getUint16(p+32,true), lo=v.getUint32(p+42,true);
    const name=dec.decode(u8.subarray(p+46,p+46+nl)); p+=46+nl+xl+cl;
    const ds=lo+30+v.getUint16(lo+26,true)+v.getUint16(lo+28,true);
    out.set(name,{meth,data:u8.subarray(ds,ds+csz)});
  }
  return out;
}
async function zipEntry(z,name,type){ const e=z.get(name); if(!e) return null;
  if(e.meth===0) return new Blob([e.data],{type:type||""});
  if(e.meth===8 && typeof DecompressionStream==="function"){ const ab=await new Response(new Blob([e.data]).stream().pipeThrough(new DecompressionStream("deflate-raw"))).arrayBuffer(); return new Blob([ab],{type:type||""}); }
  throw new Error("unsupported zip"); }
let bkFile=null;
async function restoreBackup(f){
  bkNote("Reading the backup…"); $("bkLoad").disabled=true;
  try{
    const z=readZip(await f.arrayBuffer());
    const key=[...z.keys()].find(k=>/(^|\/)backup\.json$/.test(k)&&!k.startsWith("__MACOSX")); if(!key) throw new Error("no manifest");
    const pre=key.slice(0,key.length-"backup.json".length);
    const man=JSON.parse(await (await zipEntry(z,key,"application/json")).text()); if(!man||man.app!=="pocket-retro") throw new Error("not ours");
    const have=new Set(roll.map(r=>r.id)), srcCache=new Map(), db=await idb(); let added=0, skipped=0;
    for(const e of man.roll||[]){
      if(have.has(e.id)){ skipped++; continue; }
      const it={id:e.id,mode:e.mode,time:e.time,type:e.type,ext:e.ext,num:e.num,name:e.name,srcFile:e.srcFile};
      if(e.blob) it.blob=await zipEntry(z,pre+e.blob.path,e.blob.type);
      if(e.thumb) it.thumb=await zipEntry(z,pre+e.thumb.path,e.thumb.type);
      if(e.src){ let s=srcCache.get(e.src.path);
        if(s===undefined){ const b=await zipEntry(z,pre+e.src.path,e.src.type); s=b?new File([b],e.src.name||("original."+e.src.path.split(".").pop()),{type:e.src.type||""}):null; srcCache.set(e.src.path,s); }
        if(s) it.src=s; }
      if(!it.blob) continue;
      for(const k of Object.keys(it)) if(it[k]===undefined||it[k]===null) delete it[k];
      if(db) await new Promise(res=>{ try{ const tx=db.transaction("roll","readwrite"); tx.objectStore("roll").put(it); tx.oncomplete=res; tx.onerror=res; tx.onabort=res; }catch(err){ res(); } });
      added++;
    }
    const fids=new Set(FRAMES.map(f=>f.id));
    for(const f of man.frames||[]){ if(!f||!f.id||fids.has(f.id)) continue; const blob=await zipEntry(z,pre+f.path,"image/png"); if(!blob||!db) continue;
      await new Promise(res=>{ try{ const tx=db.transaction("frames","readwrite"); tx.objectStore("frames").put({id:f.id,name:f.name||"Frame",time:f.time||Date.now(),blob}); tx.oncomplete=res; tx.onerror=res; tx.onabort=res; }catch(e){ res(); } }); }
    const lids=new Set(LOOKS.map(l=>l.id)); let looks=0;
    for(const l of man.looks||[]) if(l&&l.id&&l.data&&!lids.has(l.id)){ LOOKS.push(l); looks++; }
    saveLooks();
    const pids=new Set(IMPORTED.map(p=>p.id)); for(const p of man.imports||[]) if(p&&p.id&&p.j&&!pids.has(p.id)) IMPORTED.push(p);
    saveImports();
    try{ if(man.settings) localStorage.setItem("pretro",man.settings); }catch(e){}
    try{ if(man.logo) localStorage.setItem("pretro-logo",man.logo); else localStorage.removeItem("pretro-logo"); }catch(e){}
    bkNote(`Restored ${added} roll item${added===1?"":"s"}${skipped?` (${skipped} already here)`:""} and ${looks} look${looks===1?"":"s"}. Reloading…`);
    setTimeout(()=>location.reload(),1200);
  }catch(e){ bkNote("That file isn't a Pocket Retro backup, or it couldn't be read."); $("bkLoad").disabled=false; }
}
$("bkSave").onclick=makeBackup;
$("bkLoad").onclick=()=>{ $("bkConfirm").hidden=true; $("inBackup").click(); };
$("inBackup").onchange=()=>{ const f=$("inBackup").files&&$("inBackup").files[0]; $("inBackup").value=""; if(!f) return; bkFile=f; $("bkName").textContent=f.name; $("bkConfirm").hidden=false; bkNote(""); };
$("bkNo").onclick=()=>{ bkFile=null; $("bkConfirm").hidden=true; };
$("bkYes").onclick=()=>{ $("bkConfirm").hidden=true; if(bkFile) restoreBackup(bkFile); bkFile=null; };

/* ================= light / dark ================= */
const ICON_SUN='<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4.2"/><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M5.3 18.7l1.6-1.6M17.1 6.9l1.6-1.6"/></svg>';
const ICON_MOON='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/></svg>';
function syncTheme(){ const light=document.documentElement.dataset.theme==="light", b=$("themeBtn"), t=light?"Switch to dark mode":"Switch to light mode";
  b.innerHTML=light?ICON_MOON:ICON_SUN; b.setAttribute("aria-label",t); b.title=t; b.setAttribute("aria-pressed",String(light)); }
$("themeBtn").onclick=()=>{ const light=document.documentElement.dataset.theme!=="light";
  if(light) document.documentElement.dataset.theme="light"; else delete document.documentElement.dataset.theme;
  try{ localStorage.setItem("pretro-theme",light?"light":"dark"); }catch(e){} syncTheme(); };
syncTheme();

/* ================= My looks (complete presets) ================= */
let LOOKS=[]; try{ LOOKS=JSON.parse(localStorage.getItem("pretro-looks")||"[]").filter(l=>l&&l.id&&l.data); }catch(e){}
function saveLooks(){ try{ localStorage.setItem("pretro-looks",JSON.stringify(LOOKS)); }catch(e){} }
function buildLooks(){
  const el=$("looks"); el.textContent="";
  for(const l of LOOKS){ const b=document.createElement("button"); b.className="tape"; b.dataset.look=l.id; b.innerHTML="<b></b><small></small>";
    b.querySelector("b").textContent=l.name; b.querySelector("small").textContent=l.mode==="camera"?"Camera look":"Tape look";
    b.setAttribute("aria-pressed",String(l.id===lookId)); b.onclick=()=>applyLook(l); el.appendChild(b); }
  const add=document.createElement("button"); add.className="tape add"; add.id="lookAdd"; add.innerHTML="<b>+ Save look</b><small>Everything you've set</small>";
  add.onclick=()=>{ $("lookForm").hidden=false; $("lookName").value=""; $("lookName").focus(); }; el.appendChild(add);
  const cur=LOOKS.find(l=>l.id===lookId); $("lookRemoveWrap").hidden=!cur; if(cur) $("lookRemoveName").textContent=cur.name;
}
$("lookForm").addEventListener("submit",e=>{ e.preventDefault(); const name=$("lookName").value.trim().slice(0,40); if(!name){ $("lookName").focus(); return; }
  const l={id:"look-"+Date.now().toString(36), name, mode:M, data:clone({S,P,A,C,presetId})}; LOOKS.push(l); lookId=l.id; saveLooks(); remember(); $("lookForm").hidden=true; buildLooks();
  $("note").textContent=`Saved “${name}”. It keeps your ${M==="tape"?"signal, VHS, picture, overlay, screen and sound":"camera, stamp and picture"} settings together.`; });
$("lookCancel").onclick=()=>{ $("lookForm").hidden=true; };
function applyLook(l){ const d=clone(l.data); S=merge(defaults(),d.S||{}); P=Object.assign(clone(PDEF),d.P||{}); P.crt=Object.assign(clone(PDEF.crt),(d.P||{}).crt||{}); P.cc=Object.assign(clone(PDEF.cc),(d.P||{}).cc||{});
  A=Object.assign(adefaults(),d.A||{}); C=Object.assign(cdefaults(),d.C||{}); presetId=d.presetId||presetId; lookId=l.id;
  if(l.mode!==M) setMode(l.mode,true); else { buildShelves(); buildPanel(); }
  buildLooks(); prepDirty=true; changed(true); }
$("lookRemove").onclick=()=>{ $("lookRemoveConfirm").hidden=false; $("lookRemove").hidden=true; };
$("lookRemoveNo").onclick=()=>{ $("lookRemoveConfirm").hidden=true; $("lookRemove").hidden=false; };
$("lookRemoveYes").onclick=()=>{ LOOKS=LOOKS.filter(l=>l.id!==lookId); lookId=""; saveLooks(); remember(); $("lookRemoveConfirm").hidden=true; $("lookRemove").hidden=false; buildLooks(); };

/* ================= modes ================= */
function buildTabs(){
  const el=$("tabs"); el.textContent="";
  for(const [id,label] of TABS[M]){ const b=document.createElement("button"); b.setAttribute("role","tab"); b.id="tab-"+id; b.textContent=label; b.setAttribute("aria-controls","panel");
    b.setAttribute("aria-selected",String(id===tab)); b.onclick=()=>{ tab=id; if(M==="tape") tabT=id; else tabC=id; buildTabs(); buildPanel(); remember(); }; el.appendChild(b); }
}
function setMode(m,quiet){
  stopLive();
  M=m; tab=M==="tape"?tabT:tabC; if(!TABS[M].some(t=>t[0]===tab)) tab=TABS[M][0][0];
  document.body.dataset.mode=M;
  $("mTape").setAttribute("aria-pressed",String(M==="tape")); $("mCamera").setAttribute("aria-pressed",String(M==="camera"));
  $("tl1").textContent=M==="tape"?"Eject":"Library"; $("tl2").textContent=M==="tape"?"Rec":"Snap"; $("tl3").textContent=M==="tape"?"Tracking":"Shuffle";
  $("inLib").accept=M==="tape"?"image/*,video/*,audio/*":"image/*,video/*";
  $("hintTxt").textContent=M==="tape"?"Eject opens photos, videos or sound files. Rec uses the camera.":"Snap takes a photo or short clip. Library opens one you already have.";
  if(kind==="audio" && M==="camera"){ $("note").textContent="Sound-only files work in Tape mode, so Camera mode is showing a sample."; useSample(); }
  else if(isSample) useSample();
  if(kind==="video" && M==="camera") V.fps=camType().vfps;
  if(kind==="video"||kind==="audio") syncVideoUi();
  buildTabs(); buildShelves(); buildLooks(); buildPanel(); syncVfd(); setSaveLabel(); clearResultIfStale(); resetLabel(); $("resetConfirm").hidden=true; $("resetAll").setAttribute("aria-pressed","false"); prepDirty=true; remember(); schedule();
}
function clearResultIfStale(){ if(result && keyNow()!==resultKey){ $("result").hidden=true; $("resultAudio").hidden=true; } }
$("mTape").onclick=()=>{ if(!rendering && M!=="tape"){ lookId=""; setMode("tape"); } };
$("mCamera").onclick=()=>{ if(!rendering && M!=="camera"){ lookId=""; setMode("camera"); } };

/* ================= inputs ================= */
$("bEject").onclick=()=>{ if(rendering) return; $("inLib").value=""; $("inLib").click(); };
$("bRec").onclick=()=>{ if(rendering) return; $("inCam").value=""; $("inCam").click(); };
$("bTrack").onclick=()=>{ if(M==="tape") S.seed=(Math.random()*0xffffffff)>>>0; else C.seed=(Math.random()*0xffffffff)>>>0; remember(); schedule(); };
async function takeFile(f,fromItem,opts){ if(!f||rendering) return;
  const isVideo=(f.type||"").startsWith("video/") || /\.(mp4|mov|m4v|webm)$/i.test(f.name||"");
  const isAudio=!isVideo && ((f.type||"").startsWith("audio/") || /\.(mp3|m4a|wav|aac|ogg|flac|aif|aiff|caf)$/i.test(f.name||""));
  stopLive(); $("note").textContent=""; closeViewer(); clearOrig(); last=null; resetZoom(); clearStill(); autoKeep=!!(opts&&opts.snap);
  try{
    srcTime=f.lastModified||Date.now(); srcKey=(f.name||"")+":"+(f.size||0)+":"+(f.lastModified||0);
    curItem = fromItem || null;
    if(isAudio){ if(M!=="tape") setMode("tape",true); $("vfdState").textContent="LOADING"; await loadAudio(f); }
    else if(isVideo){ $("vfdState").textContent="LOADING"; await loadVideo(f); }
    else { const im=await loadImage(f); src=im; kind="image"; mediaFile=f; isSample=false; $("vbox").hidden=true; $("badgeR").hidden=true; clearResult(); }
    if(fromItem) srcKey=fromItem.srcFile||srcKey;
    prepDirty=true; setSaveLabel(); schedule();
  }catch(e){ $("vfdState").textContent="READY";
    $("note").textContent = isAudio ? "That sound file couldn't be opened here. Try an MP3, M4A or WAV." : isVideo ? "That video couldn't be opened here. Try an MP4 or MOV from your camera roll." : "That file couldn't be opened as a photo. Try a JPEG, PNG or HEIC."; } }
$("inCam").addEventListener("change",e=>takeFile(e.target.files[0],null,{snap:M==="camera"}));
$("inLib").addEventListener("change",e=>takeFile(e.target.files[0]));

/* ================= live video preview ================= */
const liveC=$("liveCanvas"), LR={};
function stopLive(){ if(!liveOn) return; liveOn=false; }
async function startLive(){
  if(kind!=="video"||rendering||liveOn) return;
  liveOn=true; $("liveBtn").textContent="■ Stop preview"; $("liveBtn").setAttribute("aria-pressed","true");
  const wasMuted=video.muted; video.muted=!$("liveSound").checked; video.loop=false;
  await seek(video,Math.max(V.start,Math.min(+$("vPos").value||V.start,V.end-0.05)));
  try{ await video.play(); }catch(e){ video.muted=true; try{ await video.play(); }catch(e2){} }
  LIVE_LINES = M==="tape" ? Math.min(P.lines,240) : 0;
  liveC.hidden=false; $("badgeR").textContent="LIVE";
  let f=0, t0=performance.now(), shown=0;
  while(liveOn && kind==="video"){
    if(video.currentTime>=V.end-0.02 || video.ended){ video.pause(); await seek(video,V.start); try{ await video.play(); }catch(e){} }
    const t=video.currentTime;
    let res; try{ res=await produce(video,t*1000,Math.round(t*V.fps)+(f++),LR,true); }catch(e){ break; }
    if(!liveOn) break;
    const c=res.canvas; if(liveC.width!==c.width||liveC.height!==c.height){ liveC.width=c.width; liveC.height=c.height; $("screen").style.aspectRatio=`${c.width} / ${c.height}`; fitScreen(); }
    liveC.getContext("2d").drawImage(c,0,0); shown++;
    $("vPos").value=t; $("vPosV").textContent=fmtT(t);
    const el=(performance.now()-t0)/1000; if(el>0.5) $("vfdState").textContent=`LIVE ${Math.round(shown/el)}fps`;
    await new Promise(r=>requestAnimationFrame(r));
  }
  liveOn=false; LIVE_LINES=0; video.pause(); video.muted=wasMuted||true;
  $("liveBtn").textContent="▶ Play preview"; $("liveBtn").setAttribute("aria-pressed","false"); $("badgeR").textContent=kind==="video"?"VIDEO":$("badgeR").textContent;
  $("vfdState").textContent="READY";
  if(kind==="video"){ prepDirty=true; schedule(); setTimeout(()=>{ liveC.hidden=true; },250); } else liveC.hidden=true;
}
$("liveBtn").onclick=()=>{ if(liveOn) stopLive(); else startLive(); };
$("liveSound").onchange=()=>{ if(liveOn) video.muted=!$("liveSound").checked; };

/* ================= save a single frame ================= */
async function frameBlob(src){
  let c=src;
  if(src instanceof HTMLVideoElement){ c=document.createElement("canvas"); c.width=src.videoWidth; c.height=src.videoHeight; c.getContext("2d").drawImage(src,0,0); }
  return { blob: await toBlob(c,"image/jpeg",0.95), canvas:c };
}
async function saveFrame(src){
  const {blob}=await frameBlob(src); if(!blob) return;
  const d=await getDownloads(); if(!d){ $("note").textContent="Saving isn't available here. Use Frame to roll instead."; return; }
  try{ await d.save({filename:`pocket-retro_frame_${stamp()}.jpg`,data:blob}); $("note").textContent="Frame saved."; }
  catch(e){ $("note").textContent= e&&e.code==="declined" ? "Not saved." : "Saving isn't available here right now."; }
}
async function frameToRoll(src){
  const {blob,canvas}=await frameBlob(src); if(!blob) return;
  await addToRoll({type:"photo",blob,thumb:await thumbOf(canvas),ext:"jpg"}); $("note").textContent="Frame added to your roll.";
}
const currentFrame=()=> liveOn||!liveC.hidden ? liveC : (last&&last.canvas);
$("frameSave").onclick=()=>{ const c=currentFrame(); if(c) saveFrame(c); };
$("frameKeep").onclick=()=>{ const c=currentFrame(); if(c) frameToRoll(c); };
$("vwFrame").onclick=()=>{ const v=document.querySelector("#viewerMedia video"); if(v&&v.videoWidth){ v.pause(); saveFrame(v); } };

/* ================= tab title: progress and "done" while the tab is in the background ================= */
const BASE_TITLE=document.title||"Pocket Retro"; let titleT=null;
function titleProgress(p){ if(document.hidden) document.title=`${Math.round(Math.max(0,Math.min(1,p))*100)}% · ${BASE_TITLE}`; }
function titleDone(msg){ clearTimeout(titleT); if(document.hidden) document.title=`✓ ${msg||"Done"} · ${BASE_TITLE}`; else document.title=BASE_TITLE; }
document.addEventListener("visibilitychange",()=>{ if(document.hidden) return; clearTimeout(titleT);
  if(rendering) document.title=BASE_TITLE; else titleT=setTimeout(()=>{ document.title=BASE_TITLE; },4000); });
{ const _progress=progress; progress=function(done,total,t0){ _progress(done,total,t0); titleProgress(total?done/total:0); }; }

/* ================= fades UI (moves into the video panel or the photo-video panel) ================= */
const fmtFade=v=>v>0?v.toFixed(1)+" s":"Off";
function syncFades(){
  for(const [id,k] of [["fAIn","aIn"],["fAOut","aOut"],["fVIn","vIn"],["fVOut","vOut"]]){ $(id).value=F[k]; $(id+"V").textContent=fmtFade(F[k]); }
  $("fLink").setAttribute("aria-pressed",String(!!F.link));
  $("fShape").querySelectorAll("button").forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.v===F.shape)));
  const box=$("fadeBox"), img=kind==="image", aud=kind==="audio";
  box.querySelectorAll(".fsound").forEach(e=>e.hidden=img);
  box.querySelector(".flink").hidden=kind!=="video";
  box.querySelectorAll(".fpic").forEach(e=>e.hidden=aud||(kind==="video"&&F.link));
  $("fDesc").hidden=aud;
}
function placeFades(){ const box=$("fadeBox");
  if(kind==="image"){ const sv=$("svBox"), at=$("svInfo"); if(box.parentNode!==sv||box.nextSibling!==at) sv.insertBefore(box,at); }
  else { const vb=$("vbox"), at=$("liveBtns"); if(box.parentNode!==vb||box.nextSibling!==at) vb.insertBefore(box,at); }
  syncFades(); }
for(const [id,k] of [["fAIn","aIn"],["fAOut","aOut"],["fVIn","vIn"],["fVOut","vOut"]]) $(id).addEventListener("input",e=>{ F[k]=+e.target.value; $(id+"V").textContent=fmtFade(F[k]); saveFades(); markStale(); });
$("fLink").onclick=()=>{ F.link=!F.link; saveFades(); syncFades(); markStale(); };
$("fShape").addEventListener("click",e=>{ const b=e.target.closest("button"); if(!b) return; F.shape=b.dataset.v; saveFades(); syncFades(); markStale(); });

/* ================= make a video from a photo ================= */
const SV={len:5,fps:30}; let still=null;
function clearStill(){ if(still&&still.url) URL.revokeObjectURL(still.url); still=null; $("svResult").hidden=true; $("svResult").removeAttribute("src"); $("svSave").hidden=true; }
$("svLen").addEventListener("input",e=>{ SV.len=+e.target.value; $("svLenV").textContent=SV.len.toFixed(1)+" s"; svInfo(); });
$("svFps").addEventListener("click",e=>{ const b=e.target.closest("button"); if(!b) return; SV.fps=+b.dataset.f; $("svFps").querySelectorAll("button").forEach(x=>x.setAttribute("aria-pressed",String(x===b))); svInfo(); });
function svInfo(){ $("svInfo").textContent=`${Math.round(SV.len*SV.fps)} frames. The noise, snow and tape wobble change every frame, so the photo comes to life. The video is silent.`; }
svInfo();
let svCancel=false;
$("svCancel").onclick=()=>{ svCancel=true; $("svTxt").textContent="Stopping…"; };
$("svRender").onclick=async()=>{
  if(rendering||kind!=="image") return;
  if(typeof VideoEncoder!=="function"||typeof Mp4Muxer==="undefined"){ $("note").textContent="Video export needs a newer browser: iOS 16.4 or later, or a recent Chrome, Edge or Safari."; return; }
  const fps=SV.fps, n=Math.max(1,Math.round(SV.len*fps));
  rendering=true; svCancel=false; clearStill(); $("svProg").hidden=false; $("svBar").style.width="0%"; $("svTxt").textContent="Getting ready…";
  let lock=null; try{ lock=await navigator.wakeLock?.request("screen"); }catch(e){}
  try{
    const Rr={S:clone(S)}, first=await produce(src,0,0,Rr,true);
    const Wo=first.canvas.width+(first.canvas.width&1), Ho=first.canvas.height+(first.canvas.height&1);
    const vp=await pickVideoConfig(Wo,Ho,fps); if(!vp) throw new Error("size");
    const muxer=new Mp4Muxer.Muxer({target:new Mp4Muxer.ArrayBufferTarget(),video:{codec:vp.mux,width:Wo,height:Ho,frameRate:fps},fastStart:"in-memory",firstTimestampBehavior:"offset"});
    let err=null; const venc=new VideoEncoder({output:(c,m)=>muxer.addVideoChunk(c,m),error:e=>{err=e;}}); venc.configure(vp.cfg);
    const fc=document.createElement("canvas"); fc.width=Wo; fc.height=Ho; const fx=fc.getContext("2d"), t0=performance.now(), thumb=await thumbOf(first.canvas);
    const pf=pictureFades(), total=n/fps;
    for(let k=0;k<n;k++){
      if(svCancel||err) break;
      FADE_K=Math.min(fadeGain(k/fps,total,pf.in,0),fadeGain((k+1)/fps,total,0,pf.out));
      const res = (k===0 && FADE_K>=1) ? first : await produce(src,k*1000/fps,k,Rr,true);
      fx.fillStyle="#000"; fx.fillRect(0,0,Wo,Ho); fx.drawImage(res.canvas,0,0);
      const fr=new VideoFrame(fc,{timestamp:Math.round(k*1e6/fps),duration:Math.round(1e6/fps)}); venc.encode(fr,{keyFrame:k%(fps*2)===0}); fr.close();
      while(venc.encodeQueueSize>3) await sleep(4);
      const el=(performance.now()-t0)/1000, left=(n-k-1)/((k+1)/Math.max(el,0.001));
      $("svBar").style.width=((k+1)/n*100).toFixed(1)+"%"; $("svTxt").textContent=`Frame ${k+1} of ${n}`+(k>3?` · about ${left<60?Math.ceil(left)+" s":Math.ceil(left/60)+" min"} left`:"");
      $("vfdState").textContent=`REC ${Math.round((k+1)/n*100)}%`; titleProgress((k+1)/n);
      if(k%12===0) await show(res,false);
    }
    if(err) throw err;
    await venc.flush(); venc.close();
    if(svCancel){ $("note").textContent="Render cancelled."; }
    else { muxer.finalize(); const blob=new Blob([muxer.target.buffer],{type:"video/mp4"});
      still={blob,url:URL.createObjectURL(blob)}; $("svResult").src=still.url; $("svResult").hidden=false; $("svSave").hidden=false;
      await addToRoll({type:"video",blob,thumb,ext:"mp4"});
      $("note").textContent=`Video ready: ${SV.len.toFixed(1)} seconds, ${(blob.size/1048576).toFixed(1)} MB, and added to your roll.`; }
  }catch(e){ $("note").textContent = e&&e.message==="size" ? "This device can't encode a video that size. Try fewer scan lines, no CRT look or a smaller export size." : "The video couldn't be made on this device. Try a shorter length or a lower frame rate."; }
  FADE_K=1; titleDone(svCancel?"Cancelled":"Video ready"); try{ lock&&lock.release(); }catch(e){} rendering=false; $("svProg").hidden=true; $("vfdState").textContent="READY"; prepDirty=true; schedule();
};
$("svSave").onclick=async()=>{ if(!still) return; const d=await getDownloads(); if(!d){ $("note").textContent="Saving isn't available here. You can find it in your roll."; return; }
  try{ await d.save({filename:`pocket-retro_${stamp()}.mp4`,data:still.blob}); $("note").textContent="Tap Save Video in the share sheet to add it to Photos."; }
  catch(e){ $("note").textContent= e&&e.code==="declined" ? "Not saved." : "Saving isn't available here right now."; } };

/* ================= save ================= */
let downloads=null;
async function getDownloads(){ if(window.claude && !downloads){ try{ downloads=await window.claude.use("downloads"); }catch(e){} } return downloads; }
function stamp(t){ t=t||new Date(); const p=n=>String(n).padStart(2,"0"); return `${t.getFullYear()}${p(t.getMonth()+1)}${p(t.getDate())}_${p(t.getHours())}${p(t.getMinutes())}${p(t.getSeconds())}`; }
async function save(){
  if(rendering) return;
  if(kind==="video"||kind==="audio"){
    if(!(result && keyNow()===resultKey)) return kind==="video"?renderVideo():renderAudio();
    const d=await getDownloads(); if(!d){ $("note").textContent="Saving isn't available here. You can find it in your roll."; return; }
    const name = kind==="video" ? `pocket-retro_${stamp()}.mp4` : `pocket-retro_${result.name||"sound"}_${stamp()}.${result.ext}`;
    try{ await d.save({filename:name,data:result.blob}); $("note").textContent = kind==="video" ? "Saved. On iPhone, tap Save Video in the share sheet to add it to Photos." : "Saved. On iPhone, choose Save to Files in the share sheet."; }
    catch(err){ const c=err&&err.code; $("note").textContent = c==="declined"?"Not saved.":c==="rate_limited"?"A save prompt is already open. Finish that one first.":c==="too_large"?"The file is too large to save here. Try a shorter clip.":"Saving isn't available here right now."; }
    return;
  }
  if(!lastBlob) return;
  const d=await getDownloads();
  if(!d){ $("note").textContent="Press and hold the picture, then tap Save to Photos."; return; }
  try{ await d.save({filename:`pocket-retro_${stamp()}.jpg`,data:lastBlob}); $("note").textContent="Saved. On iPhone, tap Save Image in the share sheet to add it to Photos."; }
  catch(err){ const c=err&&err.code; $("note").textContent = c==="declined" ? "Not saved." : c==="rate_limited" ? "A save prompt is already open. Finish that one first." : "Saving isn't available here. Press and hold the picture, then tap Save to Photos."; }
}
$("saveBtn").onclick=save; $("bSave").onclick=save;
$("keepBtn").onclick=async()=>{ if(!lastBlob||!last) return; await addToRoll({type:"photo",blob:lastBlob,thumb:await thumbOf(last.canvas),ext:"jpg",src:isSample?null:mediaFile,srcFile:srcKey}); $("note").textContent="Added to your roll."; };

/* ================= join videos from the roll ================= */
$("selLook").onclick=()=>{ const n=roll.filter(r=>sel.has(r.id)&&r.type==="photo").length; if(!n) return;
  const s=$("lookSel"); s.textContent="";
  const add=(v,t)=>{ const o=document.createElement("option"); o.value=v; o.textContent=t; s.appendChild(o); };
  add("","The current settings ("+(M==="tape"?"Tape":"Camera")+")"); for(const l of LOOKS) add(l.id,`${l.name} (${l.mode==="camera"?"Camera":"Tape"})`);
  $("lookN").textContent=`${n} photo${n>1?"s":""}`; $("delConfirm").hidden=true; $("lookPick").hidden=false; };
$("lookNo").onclick=()=>{ $("lookPick").hidden=true; };
$("lookGo").onclick=()=>{ $("lookPick").hidden=true; const l=LOOKS.find(x=>x.id===$("lookSel").value)||null;
  applyLookToItems(roll.filter(r=>sel.has(r.id)&&r.type==="photo").reverse(), l); };
async function applyLookToItems(items,l){
  if(rendering||!items.length) return; rendering=true; const note=$("note"), keep={S,P,A,C,M,presetId,kind,srcTime,lookId}; let done=0, failed=0;
  $("vfdState").textContent="DEVELOP";
  try{
    if(l){ const d=clone(l.data); S=merge(defaults(),d.S||{}); P=Object.assign(clone(PDEF),d.P||{}); P.crt=Object.assign(clone(PDEF.crt),(d.P||{}).crt||{}); P.cc=Object.assign(clone(PDEF.cc),(d.P||{}).cc||{});
      A=Object.assign(adefaults(),d.A||{}); C=Object.assign(cdefaults(),d.C||{}); M=l.mode==="camera"?"camera":"tape"; }
    else { S=clone(S); P=clone(P); C=clone(C); }
    kind="image";
    for(const it of items){
      note.textContent=`Applying ${l?"“"+l.name+"”":"the current settings"}… ${done+failed+1} of ${items.length}`; titleProgress((done+failed)/items.length);
      try{ const im=await loadImage(it.src||it.blob); srcTime=(it.src&&it.src.lastModified)||it.time;
        const res=await produce(im,0,0,{S:clone(S)},true); const blob=await toBlob(res.canvas,"image/jpeg",M==="camera"?0.95:0.9), thumb=await thumbOf(res.canvas);
        try{ URL.revokeObjectURL(im.src); }catch(e){}
        await addToRoll(Object.assign({type:"photo",blob,thumb,ext:"jpg",mode:M},it.src?{src:it.src,srcFile:it.srcFile}:{})); done++;
      }catch(e){ failed++; }
    }
  } finally { ({S,P,A,C,M,presetId,kind,srcTime,lookId}=keep); rendering=false; $("vfdState").textContent="READY"; prepDirty=true; schedule(); }
  selecting=false; sel.clear(); renderRoll();
  note.textContent=`Done: ${done} new photo${done===1?"":"s"} at the front of your roll${failed?`; ${failed} couldn't be redone`:""}.`+(items.some(i=>!i.src)?" Photos without an original were redone from the saved photo, so effects stack.":"");
  titleDone("Looks applied");
}
$("selJoin").onclick=()=>joinVideos([...sel].map(id=>roll.find(r=>r.id===id)).filter(r=>r&&r.type==="video"));
function loadClip(blob){ return openVideo(blob); }
async function joinVideos(items){
  if(items.length<2||rendering) return;
  if(typeof VideoEncoder!=="function"||typeof Mp4Muxer==="undefined"){ $("note").textContent="Joining videos needs a newer browser (iOS 16.4 or later)."; return; }
  rendering=true; const note=$("note"); note.textContent="Getting the clips ready…"; $("vfdState").textContent="EDIT";
  let lock=null; try{ lock=await navigator.wakeLock?.request("screen"); }catch(e){}
  try{
    const clips=[]; for(const it of items){ const v=await loadClip(it.blob); clips.push({it,v,dur:isFinite(v.duration)?v.duration:0}); }
    const W0=clips[0].v.videoWidth, H0=clips[0].v.videoHeight, W=W0+(W0&1), H=H0+(H0&1), fps=30;
    const vp=await pickVideoConfig(W,H,fps); if(!vp) throw new Error("size");
    let ab=null, aud=null;
    try{ const AC=window.AudioContext||window.webkitAudioContext, ac=new AC(), parts=[]; const sr=ac.sampleRate; let total=0;
      for(const c of clips){ let b=null; try{ b=await ac.decodeAudioData(await c.it.blob.arrayBuffer()); }catch(e){} parts.push(b); total+=Math.round(c.dur*sr); }
      try{ ac.close(); }catch(e){}
      if(parts.some(Boolean)){ ab=new AudioBuffer({length:Math.max(1,total),numberOfChannels:2,sampleRate:sr}); let off=0;
        clips.forEach((c,i)=>{ const b=parts[i], n=Math.round(c.dur*sr); if(b) for(let ch=0;ch<2;ch++){ const d=b.getChannelData(Math.min(ch,b.numberOfChannels-1)).subarray(0,Math.min(n,b.length,ab.length-off)); ab.copyToChannel(d,ch,off); } off+=n; });
        { const N=Math.round(0.012*sr); let o=0; for(let i=0;i<clips.length-1;i++){ o+=Math.round(clips[i].dur*sr); for(let ch=0;ch<2;ch++){ const d=ab.getChannelData(ch); for(let j=0;j<N;j++){ const g=j/N; if(o-1-j>=0) d[o-1-j]*=g; if(o+j<d.length) d[o+j]*=g; } } } }
        const pk=await pickAudioFor(ab); if(pk) aud={cfg:pk.cfg,mux:pk.mux,buf:ab,ch:2,fade:{in:F.aIn,out:F.aOut}}; } }catch(e){ ab=null; aud=null; }
    const muxer=new Mp4Muxer.Muxer({target:new Mp4Muxer.ArrayBufferTarget(),video:{codec:vp.mux,width:W,height:H,frameRate:fps},
      audio:aud?{codec:aud.mux,sampleRate:ab.sampleRate,numberOfChannels:2}:undefined,fastStart:"in-memory",firstTimestampBehavior:"offset"});
    let err=null; const venc=new VideoEncoder({output:(c,m)=>muxer.addVideoChunk(c,m),error:e=>{err=e;}}); venc.configure(vp.cfg);
    const fc=document.createElement("canvas"); fc.width=W; fc.height=H; const fx=fc.getContext("2d");
    const totalFrames=clips.reduce((s,c)=>s+Math.max(1,Math.round(c.dur*fps)),0); let k=0, thumb=null;
    for(const c of clips){ const n=Math.max(1,Math.round(c.dur*fps)), vw=c.v.videoWidth, vh=c.v.videoHeight, s=Math.min(W/vw,H/vh), dw=vw*s, dh=vh*s;
      for(let i=0;i<n;i++){ if(err) throw err; await seek(c.v,Math.min(c.dur-0.001,i/fps));
        fx.fillStyle="#000"; fx.fillRect(0,0,W,H); fx.drawImage(c.v,(W-dw)/2,(H-dh)/2,dw,dh);
        { const jf=F.link?{in:F.aIn,out:F.aOut}:{in:F.vIn,out:F.vOut}, T=totalFrames/fps, g=Math.min(fadeGain(k/fps,T,jf.in,0),fadeGain((k+1)/fps,T,0,jf.out)); if(g<1){ fx.fillStyle=`rgba(0,0,0,${(1-g).toFixed(3)})`; fx.fillRect(0,0,W,H); } }
        if(!thumb) thumb=await thumbOf(fc);
        const fr=new VideoFrame(fc,{timestamp:Math.round(k*1e6/fps),duration:Math.round(1e6/fps)}); venc.encode(fr,{keyFrame:k%(fps*2)===0}); fr.close(); k++;
        while(venc.encodeQueueSize>3) await sleep(4);
        if(k%15===0){ titleProgress(k/totalFrames); note.textContent=`Joining ${clips.length} videos… frame ${k} of ${totalFrames}`; $("vfdState").textContent=`EDIT ${Math.round(k/totalFrames*100)}%`; } }
      URL.revokeObjectURL(c.v.src); try{ c.v.remove(); }catch(e){} }
    await venc.flush(); venc.close();
    if(aud){ note.textContent="Adding the sound…"; await encodeAudioInto(muxer,aud,0,ab.duration,null); }
    muxer.finalize();
    const blob=new Blob([muxer.target.buffer],{type:"video/mp4"});
    await addToRoll({type:"video",blob,thumb,ext:"mp4"});
    sel.clear(); selecting=false; renderRoll();
    note.textContent=`Joined ${clips.length} videos into one (${(blob.size/1048576).toFixed(1)} MB). It's at the front of your roll; tap it to play or save.`;
  }catch(e){ note.textContent = e&&e.message==="size" ? "This device can't encode a video that size. Try joining smaller clips." : "The videos couldn't be joined on this device. Try fewer or shorter clips."; }
  try{ lock&&lock.release(); }catch(e){} rendering=false; $("vfdState").textContent="READY";
}

/* ================= desktop: make the preview fill the space it has ================= */
const mqDesk=window.matchMedia("(min-width:980px) and (min-height:560px)");
function fitScreen(){
  const sc=$("screen"), st=document.querySelector(".stage"); if(!st) return;
  if(!mqDesk.matches){ sc.style.height=""; sc.style.width=""; return; }
  let used=0, n=0; for(const el of st.children){ if(el.hidden||el.id==="finder"||getComputedStyle(el).display==="none") continue; n++;
    used += el.classList.contains("bezel") ? el.offsetHeight-sc.offsetHeight : el.offsetHeight; }
  used+=Math.max(0,n-1)*16+6;
  const ar=(sc.style.aspectRatio||"4 / 3").split("/").map(Number), ratio=(ar[0]||4)/(ar[1]||3);
  const bez=st.querySelector(".bezel"), maxW=(bez?bez.clientWidth:st.clientWidth)-24;
  let h=Math.max(240,Math.round(st.clientHeight*0.58),st.clientHeight-used); if(h*ratio>maxW) h=maxW/ratio;
  sc.style.height=Math.floor(h)+"px"; sc.style.width=Math.floor(h*ratio)+"px";
}
window.addEventListener("resize",()=>{ fitScreen(); applyZoom(); });
if(window.ResizeObserver){ const ro=new ResizeObserver(()=>fitScreen()); document.querySelectorAll(".stage > *").forEach(el=>{ if(el.id!=="finder") ro.observe(el); }); }

/* ================= samples ================= */
%%SAMPLE%%
function rngS(seed){ let s=seed>>>0||1; return ()=>{ s^=s<<13; s^=s>>>17; s^=s<<5; return (s>>>0)/4294967296; }; }
function camSample(){
  const c=document.createElement("canvas"); c.width=1600; c.height=1200; const x=c.getContext("2d");
  const sky=x.createLinearGradient(0,0,0,820); sky.addColorStop(0,"#3a6fb0"); sky.addColorStop(0.55,"#f2a65a"); sky.addColorStop(1,"#ffd9a0");
  x.fillStyle=sky; x.fillRect(0,0,1600,1200);
  x.fillStyle="#fff2c4"; x.beginPath(); x.arc(1120,640,120,0,Math.PI*2); x.fill();
  const r=rngS(42);
  for(let i=0;i<14;i++){ const w=90+r()*120, h=150+r()*300, bx=i*118-40;
    x.fillStyle=`rgb(${40+r()*30},${36+r()*25},${60+r()*30})`; x.fillRect(bx,820-h,w,h+400);
    x.fillStyle="rgba(255,214,120,.85)";
    for(let wy=820-h+24; wy<820; wy+=38) for(let wx=bx+14; wx<bx+w-20; wx+=30) if(r()>0.55) x.fillRect(wx,wy,14,20); }
  x.fillStyle="#2b2730"; x.fillRect(0,820,1600,380);
  x.strokeStyle="#f4d27a"; x.lineWidth=10; x.setLineDash([60,50]); x.beginPath(); x.moveTo(0,1010); x.lineTo(1600,1010); x.stroke(); x.setLineDash([]);
  x.fillStyle="#1d1a20"; x.beginPath(); x.ellipse(420,830,95,110,0,0,Math.PI*2); x.fill();
  x.fillStyle="#d84a5f"; x.beginPath(); x.moveTo(250,1200); x.quadraticCurveTo(260,940,420,930); x.quadraticCurveTo(580,940,590,1200); x.fill();
  x.fillStyle="#e7b48f"; x.beginPath(); x.ellipse(420,850,72,88,0,0,Math.PI*2); x.fill();
  x.fillStyle="#1d1a20"; x.beginPath(); x.ellipse(420,790,80,50,0,Math.PI,0); x.fill();
  return c;
}
function useSample(){ clearOrig(); last=null; src = M==="tape" ? sample() : camSample(); kind="image"; isSample=true; mediaFile=null; srcTime=Date.now(); curItem=null; srcKey="";
  $("vbox").hidden=true; $("badgeR").hidden=false; $("badgeR").textContent="SAMPLE"; clearResult(); prepDirty=true; }

/* ================= reset (current mode) ================= */
function resetLabel(){ const l=M==="tape"?"Reset Tape settings":"Reset Camera settings"; $("resetAll").setAttribute("aria-label",l); $("resetAll").title=l; }
$("resetAll").onclick=()=>{ if(rendering) return;
  $("resetMsg").textContent = M==="tape"
    ? "Reset all Tape mode settings (preset, signal, VHS, picture, border, overlay, screen and sound) back to the defaults? Your photo stays on screen, and Camera mode isn't changed."
    : "Reset all Camera mode settings (camera type, look, flash, noise, stamp, frame, and the Picture tab) back to the defaults? Your photo stays on screen, and Tape mode's signal and sound aren't changed.";
  $("resetConfirm").hidden=false; $("resetAll").setAttribute("aria-pressed","true"); $("resetWipe").checked=false; $("resetMedia").checked=false; fitScreen(); };
$("resetNo").onclick=()=>{ $("resetConfirm").hidden=true; $("resetAll").setAttribute("aria-pressed","false"); fitScreen(); };
$("resetYes").onclick=()=>{
  const wipe=$("resetWipe").checked, media=$("resetMedia").checked;
  if(M==="tape"){ S=presetSettings(PRESETS[0]); P=clone(PDEF); A=adefaults(); presetId="lp"; tabT="signal"; stopPreview(); }
  else { C=cdefaults(); const keep={osd:P.osd,rating:P.rating,ratingPos:P.ratingPos,ratingOpacity:P.ratingOpacity,ratingSize:P.ratingSize,ratingTime:P.ratingTime,logoOn:P.logoOn,logoPos:P.logoPos,logoX:P.logoX,logoY:P.logoY,logoSize:P.logoSize,logoOpacity:P.logoOpacity,logoWhite:P.logoWhite,logoTime:P.logoTime,crt:P.crt,aspect:P.aspect,lines:P.lines};
    P=Object.assign(clone(PDEF),keep,{cc:P.cc}); tabC="camera"; }
  lookId="";
  if(kind==="video" && M==="camera") V.fps=camType().vfps;
  if(media && !isSample) useSample();
  if(wipe){ for(const it of roll){ URL.revokeObjectURL(it.thumbUrl); dbDel(it.id); } roll=[]; curItem=null; sel.clear(); selecting=false; closeViewer(); renderRoll();
    LOOKS=[]; saveLooks(); IMPORTED=[]; saveImports(); }
  $("resetConfirm").hidden=true; $("resetAll").setAttribute("aria-pressed","false"); resetZoom();
  setMode(M,true);
  const what = M==="tape"?"Tape":"Camera";
  $("note").textContent = `${what} settings are back to the defaults.` + (media?" The photo was removed, so the sample is showing.":" Your photo is still loaded.") + (wipe?" Your roll and saved looks are cleared.":"");
};

$("undoBtn").onclick=()=>histApply(hIdx-1);
$("redoBtn").onclick=()=>histApply(hIdx+1);
document.addEventListener("keydown",e=>{ if(!(e.metaKey||e.ctrlKey)||e.key.toLowerCase()!=="z") return; const t=e.target; if(t&&(t.tagName==="INPUT"&&t.type==="text")) return;
  e.preventDefault(); if(e.shiftKey) histApply(hIdx+1); else histApply(hIdx-1); });

/* ================= boot ================= */
(async()=>{
  useSample(); setMode(M,true); histCommit(true); applyZoom(); fitScreen(); setTimeout(fitScreen,300);
  const items=await dbAll(); items.sort((a,b)=>b.time-a.time); roll=items.map(hydrate); renderRoll();
})();
})();
</script>
