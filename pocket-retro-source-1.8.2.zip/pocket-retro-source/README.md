# Pocket Retro: source

The source for [Pocket Retro](https://aismbx.github.io/Pocket-Retro/), a personal web app that makes photos, videos and sound look like 2000s digicams and VHS tapes.

- **Build:** `python3 build.py` (needs Python 3 and Pillow)
- **Release:** bump `VERSION` in `retro/build_site.py`, build, then upload the files inside `site/pocket-retro/` to the repository
- **Read [HANDOVER.md](HANDOVER.md)** for how everything fits together, where data is kept, and the known quirks.
