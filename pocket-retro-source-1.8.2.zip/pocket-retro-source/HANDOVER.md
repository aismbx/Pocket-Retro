# Pocket Retro: handover note

Version 1.8.2, 21 October 2026. This folder is everything needed to change and rebuild Pocket Retro. Read this first if you're picking the project up, whether that's you later, a new Claude chat, or another person.

## Where things live

| What | Where |
| --- | --- |
| The website (what people use) | https://aismbx.github.io/Pocket-Retro/ |
| The GitHub repository | https://github.com/aismbx/Pocket-Retro. The site files sit at the top level; this source folder goes in `source/` |
| Changelog, bug tracker, ideas, iPhone app roadmap | The "Pocket Retro Changelog" doc in Claude |
| Claude version (single-file artifact) | "Pocket Retro" in Claude artifacts (the pinned one). An older unpinned duplicate can be deleted |

## Build it

You need Python 3 and Pillow (`pip install pillow`). Nothing else: the fonts and the MP4 library are included.

```
python3 build.py
```

This makes:

- `pocket-retro.html`: the Claude version, which loads mp4-muxer from a CDN and saves through Claude's downloads feature.
- `site/pocket-retro/`: the website, 17 files. These get uploaded.

A fresh build of this folder is byte-for-byte identical to the released 1.8.2.

## Release a new version

1. Make your changes (see "Where to change what").
2. In `retro/build_site.py`, change `VERSION="1.8.2"` to the new number (patch for fixes, minor for new features). This also updates `sw.js`, which makes phones pick up the new files.
3. Run `python3 build.py`.
4. On GitHub, use **Add file → Upload files**. Drag in the files *inside* `site/pocket-retro/`, not the folder, and commit.
5. Wait about a minute, reload the site normally, and check that **Credits** shows the new version.
6. Add the release to the changelog doc.

## Folder map

| File | What it is |
| --- | --- |
| `build.py` | One-command build (runs the two scripts below) |
| `pocket-ntsc.html` | The original Pocket NTSC app. It's the base: the ntsc-rs effect engine (a JavaScript port running in a Web Worker), the effect settings and controls, the VHS sound engine and the video export code are all sliced out of it |
| `retro/build.py` | Slices `pocket-ntsc.html`, patches the slices, fills them into `main.js`, and writes `pocket-retro.html` |
| `retro/build_extra.py`, `build_extra150/160/170/180.py` | More patches to the slices, added version by version (captions, logo, frames, vertical and so on) |
| `retro/main.js` | The Pocket Retro app itself: modes, roll, looks, rendering, fades, backup, frames, streamed sound and so on. Has `%%SETTINGS%%`-style placeholders that the build fills in |
| `retro/body.html` | The page's HTML |
| `retro/extra.css` | Pocket Retro's styles, including the desktop layout and light mode |
| `retro/engine_extra.js` | The Camera (digicam) and CRT TV engines, added to the worker |
| `retro/build_site.py` | Turns the Claude version into the website: local fonts, share-sheet saving, the live camera viewfinder, offline support (`sw.js`), the icons and the manifest. **VERSION lives here** |
| `retro/VCR_OSD_MONO.ttf` | The caption font |
| `fonts/`, `mp4-muxer.js` | Bundled fonts (VT323, Barlow) and mp4-muxer 5.2.1 |
| `extras/pocket-vga.html` | The earlier Pocket VGA app, kept for safekeeping. It isn't used by the build |

## Where to change what

- **App behaviour, new features:** `retro/main.js`, `retro/body.html` and `retro/extra.css`. These are plain files you edit directly.
- **Settings and the tab controls:** these come from `pocket-ntsc.html` and are changed by `rep(...)` calls in `retro/build.py` and the `build_extra*.py` files. A `rep` replaces one exact piece of text, and it stops the build with an error if that text isn't found exactly once. That's deliberate, so a typo can't silently break something. To change a control, add another `rep` in a new `build_extra` file, or edit an existing one.
- **Website-only behaviour** (sharing, viewfinder, offline): `retro/build_site.py`.

## How it works (short version)

- **Picture pipeline:** `produce()` → `prep()` or `prepCam()` (crop, rotate, colour, and anything drawn *before* the effect: OSD, age rating, logo, soft captions, soft frames, picture fades) → the engine in a worker (Tape = ntsc-rs port, Camera = digicam) → borders (`frameCanvas`, including vertical 9:16) → crisp captions and frames → CRT TV. Live preview uses the same path at 240 lines, without the CRT look.
- **Video export:** WebCodecs encoders plus mp4-muxer. The video codec is H.264 when available, otherwise VP9 or AV1. Sound is AAC when available, otherwise Opus.
- **Sound:** a Web Audio VHS chain. Since 1.5.1, the sound of MP4 and MOV files is read straight from the file, only for the trimmed part (`mp4AudioReader`), and processed in 60-second chunks with seamless joins (`processChunked`). Every sound track is tried in turn, and the AAC sample rate and channels come from the AAC setup bytes (QuickTime sample entries can be misleading). Other formats fall back to decoding the whole file, up to 700 MB. After each render, a line under the video reports what sound was read and how loud it was, which makes silent-sound bugs easy to diagnose.
- **Long renders:** in Chrome or Edge on a computer, clips of 90 seconds or longer are written straight to a file the user picks (File System Access API). Those aren't added to the roll.

## Where data is kept (all in the user's browser)

| Key | What |
| --- | --- |
| localStorage `pretro` | All settings (mode, tape, picture, audio, camera) |
| `pretro-looks` | My looks |
| `pntsc-imports` | Imported ntsc-rs presets |
| `pretro-logo` | Channel logo (PNG data URL) |
| `pretro-fades`, `pretro-theme` | Fade settings, and light or dark mode |
| IndexedDB `pocket-retro` (version 2) | The `roll` store (photos, videos, sounds and originals) and the `frames` store (custom frames) |

**Backup and restore** packs all of this into one `.retrobackup` file. It's a ZIP inside (`backup.json` plus the media files), but the different name stops iPhone from unzipping it into a folder. Older `.zip` backups still restore. Safari can clear website data, so backups matter.

## Known quirks (and why the code does odd-looking things)

- **Safari's AAC encoder writes broken setup bytes** ([WebKit bug 302253](https://bugs.webkit.org/show_bug.cgi?id=302253)), which leaves the sound silent. `aacConfig()` writes correct ones. Don't remove it.
- **Chrome on a Mac may only encode Opus sound.** It plays in Chrome and VLC, not in QuickTime or Photos. The app says so after rendering. Safari gives AAC.
- **Streamed sound covers MP4 and MOV with AAC or MP3.** Dolby (AC-3) and similar formats can't be read, and the app shows a message.
- **The service worker** loads the page network-first with `no-store`, and reloads once when an update arrives. Always bump VERSION when releasing.
- **The Claude version can't use the camera** or save straight to a file. Those are website-only.
- **Opening videos on iPhone:** `openVideo()` keeps the video element in the page and nudges it with a muted `play()`, and it never waits forever. The iOS home-screen app often won't load a video otherwise.
- **Test hook:** add `?test` to the address to expose `window.__pr` (the sound reader, the roll and so on) for automated tests. It does nothing otherwise.

## Testing

- Open `pocket-retro.html` straight from disk for quick checks.
- To test the website properly, serve it locally: `cd site/pocket-retro && python3 -m http.server 8000`, then open http://localhost:8000.
- The real-device checklist is in the changelog chat history and the doc. The things that most need a real device are iPhone video sound, AAC from big clips on a Mac, and saving straight to a file.

## Credits and licence

The Tape effect is a JavaScript port of the core of [ntsc-rs](https://github.com/valadaptive/ntsc-rs) by valadaptive (MIT licence; the notice is in the app's Credits and in `LICENSE-ntsc-rs.txt`). mp4-muxer is by Vanilagy (MIT). The fonts are VT323 and Barlow (SIL Open Font License) and VCR OSD Mono (supplied by the owner). The TV rating icons were supplied by the owner.
